import React, { useState, useEffect, useRef } from 'react';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, Check, X } from "lucide-react";
import { format, parseISO, isValid } from 'date-fns';

export default function InlineTaskEditor({ task, field, onSave, onCancel, resources, projects, durationUnit, hoursPerDay }) {
  const [value, setValue] = useState(task[field]);
  const [dayValue, setDayValue] = useState(0);
  const [hourValue, setHourValue] = useState(0);
  const inputRef = useRef(null);

  useEffect(() => {
    if (field === 'duration_mixed') {
      setDayValue(task.duration_days || 0);
      setHourValue(task.duration_hours || 0);
    } else if (field === 'estimated_effort_mixed') {
      setDayValue(task.effort_days || 0);
      setHourValue(task.effort_hours || 0);
    } else {
      setValue(task[field]);
    }

    const timer = setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.focus();
        if (typeof inputRef.current.select === 'function') {
          inputRef.current.select();
        }
      }
    }, 50);

    return () => clearTimeout(timer);
  }, [task, field]);

  const handleSave = () => {
    let updatedTask;
    if (field === 'duration_mixed') {
      updatedTask = { ...task, duration_days: dayValue, duration_hours: hourValue, __editedField: 'duration_days' };
    } else if (field === 'estimated_effort_mixed') {
      updatedTask = { ...task, effort_days: dayValue, effort_hours: hourValue, __editedField: 'effort' };
    } else if (field === 'start_date' || field === 'end_date') {
      updatedTask = { ...task, [field]: value, __editedField: field };
    } else {
      updatedTask = { ...task, [field]: value };
    }
    onSave(updatedTask);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter') handleSave();
    if (e.key === 'Escape') onCancel();
  };

  const renderEditor = () => {
    switch (field) {
      case 'title':
        return (
          <Input
            ref={inputRef}
            type="text"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={handleKeyDown}
            onBlur={handleSave}
            className="h-7 text-sm"
          />
        );
      case 'start_date':
      case 'end_date':
        return (
          <Popover open={true} onOpenChange={onCancel}>
            <PopoverTrigger asChild>
              <Button variant="outline" className="h-7 text-sm w-full justify-start">
                <CalendarIcon className="mr-2 h-4 w-4" />
                {value ? format(parseISO(value), 'PPP') : 'Select date'}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0">
              <Calendar
                mode="single"
                selected={value ? parseISO(value) : null}
                onSelect={(date) => {
                  setValue(format(date, 'yyyy-MM-dd'));
                  // Auto-save on date selection
                  onSave({ ...task, [field]: format(date, 'yyyy-MM-dd'), __editedField: field });
                }}
                initialFocus
              />
            </PopoverContent>
          </Popover>
        );
      case 'duration_mixed':
      case 'estimated_effort_mixed':
        return (
          <div className="flex items-center gap-1 bg-white p-1 rounded-md border shadow-sm">
            <Input
              ref={inputRef}
              type="number"
              value={dayValue}
              onChange={(e) => setDayValue(parseFloat(e.target.value) || 0)}
              onKeyDown={handleKeyDown}
              className="h-6 w-14 text-xs"
              min="0"
              step="0.1"
              title="Days"
            />
            <span className="text-xs text-gray-500">d</span>
            <Input
              type="number"
              value={hourValue}
              onChange={(e) => setHourValue(parseFloat(e.target.value) || 0)}
              onKeyDown={handleKeyDown}
              className="h-6 w-14 text-xs"
              min="0"
              step="0.1"
              title="Hours"
            />
            <span className="text-xs text-gray-500">h</span>
            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={handleSave}><Check className="w-3 h-3 text-green-600" /></Button>
            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={onCancel}><X className="w-3 h-3 text-red-600" /></Button>
          </div>
        );
      case 'priority':
        return (
          <Select value={value} onValueChange={(val) => onSave({ ...task, priority: parseInt(val) })}>
            <SelectTrigger className="h-7 text-sm">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {[...Array(10)].map((_, i) => (
                <SelectItem key={i + 1} value={i + 1}>Priority {i + 1}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      case 'assigned_to':
        return (
          <Select value={value || ""} onValueChange={(val) => onSave({ ...task, assigned_to: val })}>
            <SelectTrigger className="h-7 text-sm">
              <SelectValue placeholder="Unassigned" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Unassigned</SelectItem>
              {resources.map((res) => (
                <SelectItem key={res.id} value={res.id}>{res.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        );
      default:
        return null;
    }
  };

  return <div className="inline-block w-full">{renderEditor()}</div>;
}