
import React, { useState, useEffect, useCallback, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, AlertCircle } from "lucide-react";
import { format, parseISO, isValid, addDays, differenceInDays } from "date-fns";

export default function TaskForm({
  task,
  onSubmit,
  onCancel,
  onDelete,
  projects,
  resources,
  allTasks,
  isSubmitting,
  onAutoSave, // Prop from outline, not used in original component logic but kept for completeness
  hoursPerDay = 9 // Default to 9 hours per day
}) {
  console.log('🔄 TaskForm: Component rendered', { 
    task: task ? { id: task.id, title: task.title } : null, 
    isSubmitting,
    onSubmit: typeof onSubmit,
    onCancel: typeof onCancel
  });

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    project_id: "",
    parent_task_id: "",
    start_date: "",
    end_date: "",
    duration_days: 1,
    duration_hours: 0,
    effort_days: 0,
    effort_hours: 0,
    estimated_effort: 0, // New field from outline
    sort_order: 0,       // New field from outline
    is_ongoing: false,
    predecessor_links: [], // New field from outline
    successor_links: [],   // New field from outline
    approved_planning_start_date: "", // New field
    approved_planning_end_date: "",   // New field
    actual_start_date: "",          // New field
    actual_end_date: "",            // New field
    status: "not_started",
    priority: 5,
    assigned_to: "",
    ...task,
  });

  const [formErrors, setFormErrors] = useState({});

  // Helper function to calculate end date based on start date and duration
  const calculateEndDate = useCallback((startDate, durationDays, durationHours, projectId) => {
    if (!startDate) return ""; // If no start date, can't calculate end date.
    
    try {
      const start = parseISO(startDate);
      if (!isValid(start)) return ""; // If start date is invalid, can't calculate end date.
      
      const project = projects.find(p => p.id === projectId);
      const effectiveHoursPerDay = project?.hours_per_day || hoursPerDay;
      
      // Convert duration to total hours
      const totalHours = (durationDays || 0) * effectiveHoursPerDay + (durationHours || 0);
      
      if (totalHours <= 0) {
        return format(start, "yyyy-MM-dd"); // If no duration, ends on start date
      }
      
      // For now, use simple calculation (can be enhanced with working days later)
      // If totalHours is less than or equal to hours per day, it's a single-day task
      if (totalHours <= effectiveHoursPerDay) {
        return format(start, "yyyy-MM-dd");
      } else {
        // Multi-day task
        // totalDays = ceil(totalHours / effectiveHoursPerDay)
        // Since addDays adds n days, and the start day is day 1, we add (totalDays - 1)
        const totalDays = Math.ceil(totalHours / effectiveHoursPerDay);
        const endDate = addDays(start, totalDays - 1);
        return format(endDate, "yyyy-MM-dd");
      }
    } catch (error) {
      console.error('Error calculating end date:', error);
      return "";
    }
  }, [projects, hoursPerDay]);

  // Effect to recalculate end date when start date or duration changes
  useEffect(() => {
    const hasChildren = allTasks.some(t => t.parent_task_id === formData.id);
    
    // Only auto-calculate end date if it's not a parent task
    // and if there's a start date and some duration
    if (!hasChildren && formData.start_date && (formData.duration_days > 0 || formData.duration_hours > 0)) {
      const calculatedEndDate = calculateEndDate(
        formData.start_date, 
        formData.duration_days, 
        formData.duration_hours,
        formData.project_id
      );
      
      if (calculatedEndDate !== formData.end_date) {
        console.log('📅 TaskForm: Auto-calculating end date', {
          startDate: formData.start_date,
          durationDays: formData.duration_days,
          durationHours: formData.duration_hours,
          calculatedEndDate,
          oldEndDate: formData.end_date
        });
        
        setFormData(prev => ({
          ...prev,
          end_date: calculatedEndDate
        }));
      }
    } else if (!hasChildren && formData.start_date && formData.duration_days === 0 && formData.duration_hours === 0) {
      // If start date exists but duration is 0, end date is the start date
      const calculatedEndDate = format(parseISO(formData.start_date), "yyyy-MM-dd");
      if (calculatedEndDate !== formData.end_date) {
        console.log('📅 TaskForm: Auto-calculating end date (zero duration)', {
          startDate: formData.start_date,
          calculatedEndDate,
          oldEndDate: formData.end_date
        });
        setFormData(prev => ({
          ...prev,
          end_date: calculatedEndDate
        }));
      }
    } else if (!formData.start_date && formData.end_date) {
      // If start date is cleared, clear end date too
      setFormData(prev => ({
        ...prev,
        end_date: ""
      }));
    }
  }, [formData.start_date, formData.duration_days, formData.duration_hours, formData.project_id, formData.id, allTasks, hoursPerDay, projects, formData.end_date, calculateEndDate]);


  useEffect(() => {
    console.log('🔄 TaskForm: useEffect triggered - task changed', { 
      newTask: task ? { id: task.id, title: task.title } : null 
    });
    
    // When the task prop changes, update the form data
    if (task) {
      const newFormData = {
        title: "",
        description: "",
        project_id: "",
        parent_task_id: "",
        start_date: "",
        end_date: "",
        duration_days: 1,
        duration_hours: 0,
        effort_days: 0,
        effort_hours: 0,
        estimated_effort: 0,
        sort_order: 0,
        is_ongoing: false,
        predecessor_links: [],
        successor_links: [],
        approved_planning_start_date: "",
        approved_planning_end_date: "",
        actual_start_date: "",
        actual_end_date: "",
        status: "not_started",
        priority: 5,
        assigned_to: "",
        ...task,
      };
      
      console.log('🔄 TaskForm: Setting form data', { newFormData });
      setFormData(newFormData);
    }
  }, [task]);

  const handleChange = (field, value) => {
    console.log('📝 TaskForm: Field changed', { field, value, oldValue: formData[field] });
    setFormData((prev) => {
      const newData = { ...prev, [field]: value };
      console.log('📝 TaskForm: New form data after change', { newData });
      return newData;
    });
  };

  const handleDateChange = (field, date) => {
    const dateString = date ? format(date, "yyyy-MM-dd") : "";
    console.log('📅 TaskForm: Date changed', { field, date, dateString });
    handleChange(field, dateString);
  };

  // New: Calculate actual duration based on actual start and end dates
  const actualDuration = useMemo(() => {
    if (formData.actual_start_date && formData.actual_end_date) {
      const start = parseISO(formData.actual_start_date);
      const end = parseISO(formData.actual_end_date);
      if (isValid(start) && isValid(end) && end >= start) {
        // differenceInDays returns full days difference, add 1 for inclusive count
        return differenceInDays(end, start) + 1; 
      }
    }
    return 0;
  }, [formData.actual_start_date, formData.actual_end_date]);

  // New: DatePicker helper component for reusability
  const DatePicker = ({ label, value, onChange }) => {
    const date = value ? parseISO(value) : null;
    return (
      <div>
        <label className="block text-sm font-medium text-slate-600 mb-1">{label}</label>
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" className="w-full justify-start text-left font-normal">
              <CalendarIcon className="mr-2 h-4 w-4" />
              {value && isValid(date) ? format(date, "PPP") : <span>No date set</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <Calendar 
              mode="single" 
              selected={date && isValid(date) ? date : undefined} // Use undefined for no selection
              onSelect={onChange} 
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>
    );
  };

  const handleSubmit = (e) => {
    console.log('🚀 TaskForm: handleSubmit called - START', { 
      event: e.type,
      formData: { ...formData },
      isSubmitting,
      onSubmitType: typeof onSubmit
    });
    
    e.preventDefault();
    e.stopPropagation();
    
    if (isSubmitting) {
      console.log('⏳ TaskForm: Already submitting, ignoring duplicate submit');
      return;
    }
    
    console.log('✅ TaskForm: Starting form validation');
    
    if (validateForm()) {
      console.log('✅ TaskForm: Form is valid, calling onSubmit with data:', { formData });
      
      try {
        const result = onSubmit(formData);
        console.log('✅ TaskForm: onSubmit called successfully, result:', { result, type: typeof result });
        
        if (result && typeof result.then === 'function') {
          console.log('⏳ TaskForm: onSubmit returned a promise, waiting...');
          result
            .then((res) => {
              console.log('✅ TaskForm: onSubmit promise resolved successfully:', { res });
            })
            .catch((err) => {
              console.error('❌ TaskForm: onSubmit promise rejected with error:', err);
              console.error('❌ TaskForm: Error details:', {
                message: err?.message || 'No message',
                stack: err?.stack || 'No stack',
                name: err?.name || 'No name',
                fullError: JSON.stringify(err, Object.getOwnPropertyNames(err))
              });
              
              // Show user-friendly error message
              if (err?.message) {
                alert(`Error saving task: ${err.message}`);
              } else {
                alert('An unexpected error occurred while saving the task. Please try again.');
              }
            });
        }
      } catch (error) {
        console.error('❌ TaskForm: Synchronous error calling onSubmit:', {
          error,
          message: error?.message || 'No message',
          stack: error?.stack || 'No stack',
          fullError: JSON.stringify(error, Object.getOwnPropertyNames(error))
        });
        
        // Show user-friendly error message
        if (error?.message) {
          alert(`Error saving task: ${error.message}`);
        } else {
          alert('An unexpected error occurred while saving the task. Please try again.');
        }
      }
    } else {
      console.log('❌ TaskForm: Form validation failed', { formErrors });
      alert('Please fix the form errors before saving.');
    }
    
    console.log('🚀 TaskForm: handleSubmit - END');
  };

  const handleCancel = () => {
    console.log('❌ TaskForm: Cancel button clicked');
    try {
      onCancel();
      console.log('✅ TaskForm: onCancel called successfully');
    } catch (error) {
      console.error('❌ TaskForm: Error calling onCancel:', { error });
    }
  };

  const handleDelete = () => {
    console.log('🗑️ TaskForm: Delete button clicked', { taskId: task?.id });
    try {
      onDelete(task.id);
      console.log('✅ TaskForm: onDelete called successfully');
    } catch (error) {
      console.error('❌ TaskForm: Error calling onDelete:', { error });
    }
  };

  const validateForm = () => {
    console.log('🔍 TaskForm: Validating form', { formData });
    
    const errors = {};
    if (!formData.title?.trim()) {
      errors.title = "Title is required.";
    }
    
    // Validate planned dates
    if (formData.start_date && formData.end_date) {
      const startDate = parseISO(formData.start_date);
      const endDate = parseISO(formData.end_date);
      
      if (isValid(startDate) && isValid(endDate) && endDate < startDate) {
        errors.end_date = "Planned End date must be after planned Start date.";
      }
    }

    // Validate approved planning dates
    if (formData.approved_planning_start_date && formData.approved_planning_end_date) {
      const startDate = parseISO(formData.approved_planning_start_date);
      const endDate = parseISO(formData.approved_planning_end_date);
      if (isValid(startDate) && isValid(endDate) && endDate < startDate) {
        errors.approved_planning_end_date = "Approved Planning End date must be after Approved Planning Start date.";
      }
    }

    // Validate actual dates
    if (formData.actual_start_date && formData.actual_end_date) {
      const startDate = parseISO(formData.actual_start_date);
      const endDate = parseISO(formData.actual_end_date);
      if (isValid(startDate) && isValid(endDate) && endDate < startDate) {
        errors.actual_end_date = "Actual End date must be after Actual Start date.";
      }
    }
    
    console.log('🔍 TaskForm: Validation result', { errors, isValid: Object.keys(errors).length === 0 });
    
    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };
  
  const possibleParents = allTasks.filter(t => t.id !== task?.id); // Prevent a task from being its own parent

  return (
    <div className="bg-white rounded-lg shadow-xl p-8 max-w-4xl mx-auto border border-slate-200">
      <div className="flex justify-between items-start mb-6">
        <h2 className="text-2xl font-bold text-slate-800">{task ? "Edit Task" : "Create New Task"}</h2>
        <Button variant="ghost" size="icon" onClick={handleCancel}>
          <span className="text-2xl font-light">&times;</span>
        </Button>
      </div>

      {Object.keys(formErrors).length > 0 && (
        <div className="bg-red-50 border-l-4 border-red-400 p-4 mb-6">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertCircle className="h-5 w-5 text-red-400" />
            </div>
            <div className="ml-3">
              <p className="text-sm text-red-700">
                Please correct the following errors:
                <ul className="list-disc list-inside mt-1">
                  {Object.values(formErrors).map((error, i) => (
                    <li key={i}>{error}</li>
                  ))}
                </ul>
              </p>
            </div>
          </div>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Basic Information Section */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-700 border-b pb-2">Basic Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Project</label>
              <Select value={formData.project_id || ""} onValueChange={(value) => handleChange("project_id", value)}>
                <SelectTrigger><SelectValue placeholder="Select project" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>No Project</SelectItem>
                  {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Parent Task (Optional)</label>
              <Select value={formData.parent_task_id || ""} onValueChange={(value) => handleChange("parent_task_id", value)}>
                <SelectTrigger><SelectValue placeholder="Select parent task" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>No Parent</SelectItem>
                  {possibleParents.map((p) => <SelectItem key={p.id} value={p.id}>{p.title}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-600 mb-1">Task Title</label>
            <Input
              value={formData.title || ""}
              onChange={(e) => handleChange("title", e.target.value)}
              placeholder="Enter task title"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-600 mb-1">Description</label>
            <Textarea
              value={formData.description || ""}
              onChange={(e) => handleChange("description", e.target.value)}
              placeholder="Detailed task description"
              rows={4}
            />
          </div>
          <div className="flex items-center space-x-2 pt-2">
            <Checkbox
              id="is_ongoing"
              checked={formData.is_ongoing || false}
              onCheckedChange={(checked) => handleChange("is_ongoing", checked)}
            />
            <label htmlFor="is_ongoing" className="text-sm font-medium text-slate-700">
              Mark as Ongoing Task
              <span className="text-xs text-slate-500 ml-2">(Ongoing tasks can span multiple time periods and remain active across weeks)</span>
            </label>
          </div>
        </div>

        {/* Timeline & Duration Section */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-700 border-b pb-2">Planned Timeline & Duration</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 items-end">
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Start Date (Optional)</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {formData.start_date ? format(parseISO(formData.start_date), "PPP") : <span>No date set</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar 
                    mode="single" 
                    selected={formData.start_date ? parseISO(formData.start_date) : undefined} 
                    onSelect={(date) => handleDateChange("start_date", date)} 
                  />
                </PopoverContent>
              </Popover>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">End Date</label>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal bg-slate-100 cursor-not-allowed"
                disabled
              >
                <CalendarIcon className="mr-2 h-4 w-4" />
                {formData.end_date && isValid(parseISO(formData.end_date)) ? format(parseISO(formData.end_date), "PPP") : <span className="text-slate-500">Calculated automatically</span>}
              </Button>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Duration (Days)</label>
              <Input
                type="number"
                min="0"
                step="0.1"
                value={formData.duration_days || ""}
                onChange={(e) => handleChange("duration_days", parseFloat(e.target.value) || 0)}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Duration (Hours)</label>
              <Input
                type="number"
                min="0"
                step="0.1"
                value={formData.duration_hours || ""}
                onChange={(e) => handleChange("duration_hours", parseFloat(e.target.value) || 0)}
              />
            </div>
          </div>
        </div>
        
        {/* Planning Section */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-700 border-b pb-2">Effort Planning</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Effort (Days)</label>
              <Input
                type="number"
                min="0"
                step="0.1"
                value={formData.effort_days || ""}
                onChange={(e) => handleChange("effort_days", parseFloat(e.target.value) || 0)}
                placeholder="e.g., 5"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Effort (Hours)</label>
              <Input
                type="number"
                min="0"
                step="0.1"
                value={formData.effort_hours || ""}
                onChange={(e) => handleChange("effort_hours", parseFloat(e.target.value) || 0)}
                placeholder="e.g., 4"
              />
            </div>
            {/* New: Estimated Effort */}
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Estimated Effort (Total Hours)</label>
              <Input
                type="number"
                min="0"
                step="0.1"
                value={formData.estimated_effort || ""}
                onChange={(e) => handleChange("estimated_effort", parseFloat(e.target.value) || 0)}
                placeholder="e.g., 40"
              />
            </div>
          </div>
        </div>

        {/* New Section: Actuals & Approved Planning */}
        <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-700 border-b pb-2">Actuals & Approved Planning</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <DatePicker 
                    label="Approved Planning Start Date" 
                    value={formData.approved_planning_start_date} 
                    onChange={(date) => handleDateChange("approved_planning_start_date", date)} 
                />
                <DatePicker 
                    label="Approved Planning End Date" 
                    value={formData.approved_planning_end_date} 
                    onChange={(date) => handleDateChange("approved_planning_end_date", date)} 
                />
                <DatePicker 
                    label="Actual Start Date" 
                    value={formData.actual_start_date} 
                    onChange={(date) => handleDateChange("actual_start_date", date)} 
                />
                <DatePicker 
                    label="Actual End Date" 
                    value={formData.actual_end_date} 
                    onChange={(date) => handleDateChange("actual_end_date", date)} 
                />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-medium text-slate-600 mb-1">Actual Duration (Days)</label>
                    <Input 
                        value={`${actualDuration} day(s)`} 
                        disabled 
                        className="bg-slate-100 font-medium" 
                    />
                </div>
                {/* Add other actuals like actual effort if needed here */}
            </div>
        </div>

        {/* Other Details Section */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-700 border-b pb-2">Other Details</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Status</label>
              <Select value={formData.status || "not_started"} onValueChange={(value) => handleChange("status", value)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="not_started">Not Started</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="blocked">Blocked</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Priority (1-10)</label>
              <Input 
                type="number" 
                min="1" 
                max="10" 
                value={formData.priority || 5} 
                onChange={(e) => handleChange("priority", parseInt(e.target.value) || 5)} 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Assigned To</label>
              <Select value={formData.assigned_to || ""} onValueChange={(value) => handleChange("assigned_to", value)}>
                <SelectTrigger><SelectValue placeholder="Unassigned" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>Unassigned</SelectItem>
                  {resources.map((r) => <SelectItem key={r.id} value={r.id}>{r.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            {/* New: Sort Order */}
            <div>
              <label className="block text-sm font-medium text-slate-600 mb-1">Sort Order</label>
              <Input 
                type="number" 
                min="0" 
                value={formData.sort_order || 0} 
                onChange={(e) => handleChange("sort_order", parseInt(e.target.value) || 0)} 
                placeholder="e.g., 0"
              />
            </div>
          </div>
        </div>

        {/* Predecessor/Successor links (fields added to state, UI omitted as per current outline) */}
        {/* If a UI is needed for predecessor/successor links, it would go here. 
            For now, these are just part of the formData structure. */}

        <div className="flex justify-end gap-3 pt-4 border-t">
          {task && (
            <Button 
              type="button" 
              variant="destructive" 
              onClick={handleDelete}
              disabled={isSubmitting}
            >
              Delete Task
            </Button>
          )}
          <Button type="button" variant="outline" onClick={handleCancel} disabled={isSubmitting}>
            Cancel
          </Button>
          <Button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Saving..." : task ? "Save Changes" : "Create Task"}
          </Button>
        </div>
      </form>
    </div>
  );
}
