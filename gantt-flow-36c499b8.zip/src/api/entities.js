import { base44 } from './base44Client';


export const Project = base44.entities.Project;

export const Task = base44.entities.Task;

export const Resource = base44.entities.Resource;

export const AuditLog = base44.entities.AuditLog;

export const Setting = base44.entities.Setting;



// auth sdk:
export const User = base44.auth;