import React, { useState, useEffect, useCallback } from 'react';
import { Setting } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

const ALL_DAYS = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];

export default function SettingsPage() {
    const [settings, setSettings] = useState(null);
    const [workingDays, setWorkingDays] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);

    const loadSettings = useCallback(async () => {
        setIsLoading(true);
        try {
            const results = await Setting.filter({ key: 'working_days' });
            if (results.length > 0) {
                const workingDaysSetting = results[0];
                setSettings(workingDaysSetting);
                setWorkingDays(workingDaysSetting.value?.days || []);
            } else {
                // Default settings if none exist
                setWorkingDays(["monday", "tuesday", "wednesday", "thursday", "friday"]);
            }
        } catch (error) {
            console.error("Error loading settings:", error);
            // Show error feedback
            const errorDiv = document.createElement('div');
            errorDiv.textContent = 'Failed to load settings';
            errorDiv.className = 'fixed top-4 right-4 bg-red-500 text-white px-4 py-2 rounded shadow-lg z-50';
            document.body.appendChild(errorDiv);
            setTimeout(() => document.body.removeChild(errorDiv), 3000);
        }
        setIsLoading(false);
    }, []);

    useEffect(() => {
        loadSettings();
    }, [loadSettings]);

    const handleWorkingDayChange = (day) => {
        setWorkingDays(prev => 
            prev.includes(day) ? prev.filter(d => d !== day) : [...prev, day]
        );
    };

    const handleSaveChanges = async () => {
        setIsSaving(true);
        try {
            const value = { days: workingDays };
            if (settings && settings.id) {
                await Setting.update(settings.id, { value });
            } else {
                const newSetting = await Setting.create({ key: 'working_days', value });
                setSettings(newSetting);
            }
            // Show success feedback
            const successDiv = document.createElement('div');
            successDiv.textContent = 'Settings saved successfully!';
            successDiv.className = 'fixed top-4 right-4 bg-green-500 text-white px-4 py-2 rounded shadow-lg z-50';
            document.body.appendChild(successDiv);
            setTimeout(() => document.body.removeChild(successDiv), 3000);
        } catch (error) {
            console.error("Error saving settings:", error);
            // Show error feedback
            const errorDiv = document.createElement('div');
            errorDiv.textContent = 'Failed to save settings';
            errorDiv.className = 'fixed top-4 right-4 bg-red-500 text-white px-4 py-2 rounded shadow-lg z-50';
            document.body.appendChild(errorDiv);
            setTimeout(() => document.body.removeChild(errorDiv), 3000);
        }
        setIsSaving(false);
    };

    const renderSkeleton = () => (
        <Card className="max-w-2xl mx-auto">
            <CardHeader>
                <Skeleton className="h-8 w-1/2" />
                <Skeleton className="h-4 w-3/4 mt-2" />
            </CardHeader>
            <CardContent className="space-y-4">
                {Array(7).fill(0).map((_, i) => (
                    <div key={i} className="flex items-center space-x-2">
                        <Skeleton className="h-4 w-4" />
                        <Skeleton className="h-4 w-24" />
                    </div>
                ))}
                <Skeleton className="h-10 w-32 mt-4" />
            </CardContent>
        </Card>
    );

    if (isLoading) {
        return <div className="p-6">{renderSkeleton()}</div>;
    }

    return (
        <div className="p-6">
            <Card className="max-w-2xl mx-auto">
                <CardHeader>
                    <CardTitle className="text-2xl">Application Settings</CardTitle>
                    <CardDescription>Configure general settings for your workspace.</CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        <div>
                            <h3 className="text-lg font-medium text-slate-900">Working Days</h3>
                            <p className="text-sm text-slate-500 mt-1">
                                Select the days that are considered working days for date calculations.
                            </p>
                            <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                                {ALL_DAYS.map(day => (
                                    <div key={day} className="flex items-center space-x-2">
                                        <Checkbox
                                            id={day}
                                            checked={workingDays.includes(day)}
                                            onCheckedChange={() => handleWorkingDayChange(day)}
                                        />
                                        <label
                                            htmlFor={day}
                                            className="text-sm font-medium capitalize leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                        >
                                            {day}
                                        </label>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="flex justify-end pt-4">
                            <Button onClick={handleSaveChanges} disabled={isSaving}>
                                {isSaving ? "Saving..." : "Save Changes"}
                            </Button>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </div>
    );
}