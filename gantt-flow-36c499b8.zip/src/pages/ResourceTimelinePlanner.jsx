
import React, { useState, useEffect } from "react";
import { Task } from "@/api/entities";
import { Project } from "@/api/entities";
import { Resource } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge"; // Preserving existing import
import { ChevronLeft, ChevronRight, Calendar, CalendarDays, CalendarRange, Clock, User } from "lucide-react"; // Preserving existing imports
import { format, addDays, addWeeks, addMonths, startOfWeek, endOfWeek, startOfMonth, endOfMonth, parseISO, isValid, isSameDay, startOfDay, endOfDay, isSameWeek } from "date-fns";

// Helper function to layout tasks into lanes to prevent visual overlap
const layoutTasksForResource = (tasksToLayout) => {
  if (!tasksToLayout || tasksToLayout.length === 0) return { laidOutTasks: [], totalLanes: 1 };

  const sortedTasks = [...tasksToLayout]
    .filter(t => t.start_date && t.end_date && isValid(parseISO(t.start_date)) && isValid(parseISO(t.end_date)))
    .sort((a, b) => parseISO(a.start_date).getTime() - parseISO(b.start_date).getTime());
  
  const lanes = []; // This will store the end date of the last task in each lane
  const laidOutTasks = [];

  for (const task of sortedTasks) {
    const taskStart = parseISO(task.start_date);
    const taskEnd = parseISO(task.end_date);
    let placed = false;
    for (let i = 0; i < lanes.length; i++) {
      // Check if the current task starts after the last task in this lane ends
      // Using '>=' would allow tasks to start immediately after another ends in the same lane,
      // but if we want a small visual gap or strict non-overlap, '>' is better.
      // For this planner, '>=' might be visually cleaner for consecutive tasks.
      // Let's stick to the outline and use '>'
      if (taskStart > lanes[i]) { // Use > to allow tasks starting on the same day as another ends
        // Found an open spot in this lane
        lanes[i] = taskEnd;
        laidOutTasks.push({ ...task, lane: i });
        placed = true;
        break;
      }
    }

    if (!placed) {
      // No open spot, create a new lane
      lanes.push(taskEnd);
      laidOutTasks.push({ ...task, lane: lanes.length - 1 });
    }
  }

  // Ensure totalLanes is at least 1, even if no tasks
  return { laidOutTasks, totalLanes: lanes.length > 0 ? lanes.length : 1 };
};


export default function ResourceTimelinePlanner() {
  const [tasks, setTasks] = useState([]);
  const [projects, setProjects] = useState([]);
  const [resources, setResources] = useState([]);
  const [selectedResource, setSelectedResource] = useState(null); // Changed default from "" to null as per outline
  const [viewMode, setViewMode] = useState("weekly");
  const [currentDate, setCurrentDate] = useState(new Date());
  const [isLoading, setIsLoading] = useState(true);
  const [workingDays, setWorkingDays] = useState(["sunday", "monday", "tuesday", "wednesday", "thursday"]); // Preserving existing state

  useEffect(() => {
    loadData();

    const handleDataRefresh = () => {
        console.log("ResourceTimelinePlanner: Refreshing data due to external event.");
        loadData();
    };

    window.addEventListener("refreshTaskView", handleDataRefresh);
    window.addEventListener("taskCreated", handleDataRefresh);
    window.addEventListener("taskDeleted", handleDataRefresh);

    return () => {
        window.removeEventListener("refreshTaskView", handleDataRefresh);
        window.removeEventListener("taskCreated", handleDataRefresh);
        window.removeEventListener("taskDeleted", handleDataRefresh);
    };
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [tasksData, projectsData, resourcesData] = await Promise.all([
        Task.list("-created_date"),
        Project.list("-created_date"),
        Resource.list("name")
      ]);
      
      // Filter out any null/undefined entries and ensure they have required properties
      const validTasks = (tasksData || []).filter(t => t && t.id);
      const validProjects = (projectsData || []).filter(p => p && p.id);
      const validResources = (resourcesData || []).filter(r => r && (r.id || r.name));
      
      setTasks(validTasks);
      setProjects(validProjects);
      setResources(validResources);
      
      console.log('DEBUG ResourceTimeline: Loaded data', {
        tasksCount: validTasks.length,
        projectsCount: validProjects.length,
        resourcesCount: validResources.length,
        sampleTasks: validTasks.slice(0, 3).map(t => ({
          id: t.id,
          title: t.title,
          assigned_to: t.assigned_to,
          start_date: t.start_date,
          end_date: t.end_date
        }))
      });
    } catch (error) {
      console.error("Error loading data:", error);
      setTasks([]);
      setProjects([]);
      setResources([]);
    } finally {
      setIsLoading(false);
    }
  };

  // Preserving helper functions even if not directly used in new render
  const isWorkingDay = (date) => {
    if (!date) return false;
    const dayNames = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    const dayName = dayNames[date.getDay()];
    return workingDays.includes(dayName);
  };

  const isWeekend = (date) => {
    if (!date) return false;
    const dayNames = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    const dayName = dayNames[date.getDay()];
    return !workingDays.includes(dayName);
  };

  // Modified getDateRange to return the start of the week for timeline rendering (always 7 days),
  // while the label changes based on the selected view mode.
  const getDateRange = () => {
    const timelineStart = startOfWeek(currentDate, { weekStartsOn: 0 }); // Sunday as start
    const timelineEnd = endOfWeek(currentDate, { weekStartsOn: 0 }); // Sunday as start

    let label;
    switch (viewMode) {
      case "daily":
        label = format(currentDate, "EEEE, MMMM d, yyyy");
        break;
      case "weekly":
        label = `${format(timelineStart, "MMM d")} - ${format(timelineEnd, "MMM d, yyyy")}`;
        break;
      case "monthly":
        label = format(currentDate, "MMMM yyyy");
        break;
      default:
        label = format(currentDate, "EEEE, MMMM d, yyyy");
    }
    return { start: timelineStart, end: timelineEnd, label };
  };

  const navigateDate = (direction) => {
    switch (viewMode) {
      case "daily":
        setCurrentDate(prev => direction < 0 ? addDays(prev, -1) : addDays(prev, 1));
        break;
      case "weekly":
        setCurrentDate(prev => direction < 0 ? addWeeks(prev, -1) : addWeeks(prev, 1));
        break;
      case "monthly":
        setCurrentDate(prev => direction < 0 ? addMonths(prev, -1) : addMonths(prev, 1));
        break;
      default:
        setCurrentDate(prev => direction < 0 ? addDays(prev, -1) : addDays(prev, 1));
    }
  };

  // Helper functions for navigation buttons as specified in outline
  const handlePrev = () => navigateDate(-1);
  const handleNext = () => navigateDate(1);

  // Preserving resource and project name getters
  const getResourceName = (resourceId) => {
    if (!resourceId) return "Unassigned";
    const resource = resources.find(r => r && (r.id === resourceId || r.name === resourceId));
    return resource ? resource.name : "Unknown Resource";
  };

  const getProjectName = (projectId) => {
    if (!projectId) return "No Project";
    const project = projects.find(p => p && p.id === projectId);
    return project ? project.name : "Unknown Project";
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-64 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  const { start, end, label } = getDateRange();

  // Filter resources based on selectedResource as per outline
  const filteredResources = resources.filter(
    (resource) => !selectedResource || (resource.id && resource.id === selectedResource)
  );

  return (
    <div className="h-screen flex flex-col bg-slate-50 p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-slate-800">Resource Timeline Planner</CardTitle>
          <p className="text-slate-500">View resource allocation and identify gaps in the timeline</p>
        </CardHeader>
        <CardContent>
          {/* Controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
            <div className="flex items-center gap-4">
              <Select value={selectedResource} onValueChange={setSelectedResource}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="All Resources" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={null}>All Resources</SelectItem> {/* Changed value from "all" to null */}
                  {resources.map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <div className="flex items-center bg-slate-100 rounded-lg p-1">
                <Button variant={viewMode === 'daily' ? 'default' : 'ghost'} size="sm" onClick={() => setViewMode('daily')} className="flex items-center gap-2"><Calendar className="w-4 h-4" /> Day</Button>
                <Button variant={viewMode === 'weekly' ? 'default' : 'ghost'} size="sm" onClick={() => setViewMode('weekly')} className="flex items-center gap-2"><CalendarDays className="w-4 h-4" /> Week</Button>
                <Button variant={viewMode === 'monthly' ? 'default' : 'ghost'} size="sm" onClick={() => setViewMode('monthly')} className="flex items-center gap-2"><CalendarRange className="w-4 h-4" /> Month</Button>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={handlePrev}><ChevronLeft className="w-4 h-4" /></Button>
              <span className="font-semibold text-slate-700 w-48 text-center">{label}</span>
              <Button variant="outline" size="icon" onClick={handleNext}><ChevronRight className="w-4 h-4" /></Button>
            </div>
          </div>

          {/* Timeline View */}
          <div className="border rounded-lg overflow-x-auto">
            <div className="min-w-[1200px]">
              {/* Header */}
              <div className="flex bg-slate-50 border-b">
                <div className="w-64 p-3 font-semibold text-slate-600 border-r sticky left-0 bg-slate-50 z-10">Resource</div>
                <div className="flex-1 grid grid-cols-7">
                  {Array.from({ length: 7 }).map((_, i) => (
                    <div key={i} className="p-3 text-center font-semibold text-slate-600 border-r">
                      {format(addDays(start, i), "EEE, MMM d")}
                    </div>
                  ))}
                </div>
              </div>

              {/* Body */}
              <div>
                {/* Display message if no resources are found */}
                {resources.length === 0 && !isLoading && (
                  <div className="p-8 text-center text-slate-500">
                    <User className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p className="font-medium">No resources found</p>
                    <p className="text-sm">Please add resources to your system.</p>
                  </div>
                )}
                {/* Display message if a specific resource is selected but not found */}
                {filteredResources.length === 0 && resources.length > 0 && selectedResource !== null && (
                  <div className="p-8 text-center text-slate-500">
                    <User className="w-12 h-12 mx-auto mb-3 text-slate-300" />
                    <p className="font-medium">Selected resource not found</p>
                    <p className="text-sm">The selected resource might have been removed or does not exist.</p>
                  </div>
                )}

                {filteredResources.map((resource) => {
                  // Filter tasks for the current resource and exclude 'completed' or 'cancelled' status
                  const resourceTasks = tasks.filter(
                    (task) => task.assigned_to === resource.id && !['completed', 'cancelled'].includes(task.status)
                  );
                  // Layout tasks into lanes for the current resource
                  const { laidOutTasks, totalLanes } = layoutTasksForResource(resourceTasks);

                  return (
                    <div key={resource.id} className="flex border-b" style={{ minHeight: `${totalLanes * 2.5 + 1}rem` }}>
                      <div className="w-64 p-3 font-medium text-slate-800 border-r flex items-start sticky left-0 bg-white z-10">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-slate-400" />
                          {resource.name}
                        </div>
                        {/* Optionally show task count, keeping original logic comment for comparison */}
                        {/* <div className="text-xs text-slate-500 mt-1">
                          {resourceTasks.length} task{resourceTasks.length !== 1 ? 's' : ''} total
                        </div> */}
                      </div>
                      <div className="flex-1 grid grid-cols-7 relative">
                        {/* Background cells for each day */}
                        {Array.from({ length: 7 }).map((_, i) => (
                          <div key={i} className="border-r h-full"></div>
                        ))}
                        {laidOutTasks.map((task) => {
                          const taskStart = parseISO(task.start_date);
                          const taskEnd = parseISO(task.end_date);
                          // Ensure task dates are valid
                          if (!isValid(taskStart) || !isValid(taskEnd)) return null;

                          // Calculate offset and duration in days relative to the start of the current week (start)
                          const offset = Math.max(0, (taskStart.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
                          const duration = Math.max(1, (taskEnd.getTime() - taskStart.getTime()) / (1000 * 60 * 60 * 24) + 1); // +1 to include both start and end day

                          return (
                            <div
                              key={task.id}
                              className="absolute bg-blue-100 border border-blue-300 rounded-md p-1 px-2 text-xs text-blue-800 hover:bg-blue-200 cursor-pointer overflow-hidden truncate"
                              style={{
                                left: `calc(${offset / 7 * 100}%)`,
                                width: `calc(${duration / 7 * 100}%)`,
                                top: `${task.lane * 2.5 + 0.25}rem`, // Adjusted for lane positioning (2.5rem per lane = 40px)
                                height: '2rem', // 2rem = 32px
                              }}
                              title={task.title}
                            >
                              <p className="font-semibold">{task.title}</p>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
          {/* Message when no active tasks are found in the current view for the filtered resources */}
          {filteredResources.length > 0 && 
           tasks.length > 0 && 
           !filteredResources.some(res => tasks.some(t => t.assigned_to === res.id && !['completed', 'cancelled'].includes(t.status))) && 
           (
            <div className="p-8 text-center text-slate-500">
              <Calendar className="w-12 h-12 mx-auto mb-3 text-slate-300" />
              <p className="font-medium">No active tasks found in this view</p>
              <p className="text-sm">There are no active tasks assigned to the selected resource(s) for the current week.</p>
            </div>
          )}
          {/* Message when "All Resources" is selected and there are no tasks in the system */}
          {filteredResources.length > 0 && selectedResource === null && tasks.length === 0 && (
             <div className="p-8 text-center text-slate-500">
               <Calendar className="w-12 h-12 mx-auto mb-3 text-slate-300" />
               <p className="font-medium">No tasks found across all resources</p>
               <p className="text-sm">There are no tasks available in the system to display.</p>
             </div>
           )}
        </CardContent>
      </Card>
    </div>
  );
}
