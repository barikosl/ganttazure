import React, { useState, useEffect } from "react";
import { Task, Project, Resource } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from "recharts";
import { format, differenceInDays, startOfWeek, endOfWeek } from "date-fns";
import { TrendingUp, Users, Clock, Target, AlertCircle, CheckCircle } from "lucide-react";

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

export default function Analytics() {
  const [tasks, setTasks] = useState([]);
  const [projects, setProjects] = useState([]);
  const [resources, setResources] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedProject, setSelectedProject] = useState("all");
  const [timeRange, setTimeRange] = useState("month");

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [tasksData, projectsData, resourcesData] = await Promise.all([
        Task.list(),
        Project.list(),
        Resource.list()
      ]);
      setTasks(tasksData);
      setProjects(projectsData);
      setResources(resourcesData);
    } catch (error) {
      console.error("Error loading analytics data:", error);
    }
    setIsLoading(false);
  };

  const filteredTasks = selectedProject === "all" 
    ? tasks 
    : tasks.filter(task => task.project_id === selectedProject);

  // Task completion metrics
  const taskMetrics = {
    total: filteredTasks.length,
    completed: filteredTasks.filter(t => t.status === 'completed').length,
    inProgress: filteredTasks.filter(t => t.status === 'in_progress').length,
    notStarted: filteredTasks.filter(t => t.status === 'not_started').length,
    blocked: filteredTasks.filter(t => t.status === 'blocked').length,
  };

  const completionRate = taskMetrics.total > 0 
    ? Math.round((taskMetrics.completed / taskMetrics.total) * 100) 
    : 0;

  // Resource utilization
  const resourceMetrics = resources.map(resource => {
    const resourceTasks = filteredTasks.filter(t => t.assigned_to === resource.id);
    const totalEffort = resourceTasks.reduce((sum, task) => sum + (task.estimated_effort || 0), 0);
    const completedEffort = resourceTasks
      .filter(t => t.status === 'completed')
      .reduce((sum, task) => sum + (task.estimated_effort || 0), 0);
    
    const capacity = (resource.capacity_hours_per_day || 8) * 20; // Assume 20 working days per month
    const utilization = capacity > 0 ? Math.round((totalEffort / capacity) * 100) : 0;
    
    return {
      name: resource.name,
      totalTasks: resourceTasks.length,
      completedTasks: resourceTasks.filter(t => t.status === 'completed').length,
      totalEffort,
      completedEffort,
      utilization,
      efficiency: totalEffort > 0 ? Math.round((completedEffort / totalEffort) * 100) : 0
    };
  });

  // Priority distribution
  const priorityData = [
    { name: 'High (8-10)', value: filteredTasks.filter(t => (t.priority || 5) >= 8).length, color: '#FF8042' },
    { name: 'Medium (5-7)', value: filteredTasks.filter(t => {
      const p = t.priority || 5;
      return p >= 5 && p < 8;
    }).length, color: '#FFBB28' },
    { name: 'Low (1-4)', value: filteredTasks.filter(t => (t.priority || 5) < 5).length, color: '#00C49F' }
  ];

  // Status distribution for pie chart
  const statusData = [
    { name: 'Completed', value: taskMetrics.completed, color: '#00C49F' },
    { name: 'In Progress', value: taskMetrics.inProgress, color: '#0088FE' },
    { name: 'Not Started', value: taskMetrics.notStarted, color: '#FFBB28' },
    { name: 'Blocked', value: taskMetrics.blocked, color: '#FF8042' }
  ].filter(item => item.value > 0);

  // Performance trends (weekly completion)
  const weeklyData = [];
  for (let i = 4; i >= 0; i--) {
    const weekStart = startOfWeek(new Date(Date.now() - i * 7 * 24 * 60 * 60 * 1000));
    const weekEnd = endOfWeek(weekStart);
    const weekTasks = filteredTasks.filter(t => {
      const completedDate = t.actual_end_date ? new Date(t.actual_end_date) : null;
      return completedDate && completedDate >= weekStart && completedDate <= weekEnd;
    });
    
    weeklyData.push({
      week: format(weekStart, 'MMM d'),
      completed: weekTasks.length,
      totalEffort: weekTasks.reduce((sum, task) => sum + (task.estimated_effort || 0), 0)
    });
  }

  // Overdue tasks
  const overdueTasks = filteredTasks.filter(t => {
    if (t.status === 'completed') return false;
    const endDate = new Date(t.end_date);
    return endDate < new Date();
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {Array(4).fill(0).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded w-1/2"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Analytics</h1>
          <p className="text-slate-600 mt-1">Team performance insights and project metrics</p>
        </div>
        <div className="flex gap-4">
          <Select value={selectedProject} onValueChange={setSelectedProject}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="Select project" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Projects</SelectItem>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Total Tasks</p>
                <p className="text-2xl font-bold text-slate-900">{taskMetrics.total}</p>
              </div>
              <Target className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Completion Rate</p>
                <p className="text-2xl font-bold text-slate-900">{completionRate}%</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <Progress value={completionRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">In Progress</p>
                <p className="text-2xl font-bold text-slate-900">{taskMetrics.inProgress}</p>
              </div>
              <Clock className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-slate-600">Overdue</p>
                <p className="text-2xl font-bold text-slate-900">{overdueTasks.length}</p>
              </div>
              <AlertCircle className="h-8 w-8 text-red-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Task Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={statusData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {statusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Priority Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={priorityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#8884d8">
                  {priorityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Weekly Performance */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Weekly Completion Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="week" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="completed" stroke="#8884d8" name="Tasks Completed" />
              <Line type="monotone" dataKey="totalEffort" stroke="#82ca9d" name="Total Effort (hrs)" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Resource Performance */}
      <Card>
        <CardHeader>
          <CardTitle>Resource Performance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {resourceMetrics.map((resource, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-semibold">{resource.name}</h4>
                  <div className="flex gap-2">
                    <Badge variant="outline">
                      {resource.completedTasks}/{resource.totalTasks} tasks
                    </Badge>
                    <Badge variant={resource.utilization > 100 ? "destructive" : "secondary"}>
                      {resource.utilization}% utilized
                    </Badge>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-slate-600">Efficiency: </span>
                    <span className="font-medium">{resource.efficiency}%</span>
                  </div>
                  <div>
                    <span className="text-slate-600">Total Effort: </span>
                    <span className="font-medium">{resource.totalEffort}h</span>
                  </div>
                </div>
                <Progress value={resource.efficiency} className="mt-2" />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}