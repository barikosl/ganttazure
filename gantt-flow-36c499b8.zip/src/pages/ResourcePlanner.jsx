
import React, { useState, useEffect } from "react";
import { Resource } from "@/api/entities";
import { Task } from "@/api/entities";
import { Project } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { startOfWeek, addDays, format, addWeeks, startOfDay, endOfDay, isWithinInterval, eachDayOfInterval, isValid } from "date-fns";
import { Users2, Clock, CalendarDays, Sun, ChevronLeft, ChevronRight, Play, Calendar, GripVertical } from "lucide-react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";
import TaskForm from "@/components/gantt/TaskForm";
import ResourceConflictModal from "@/components/gantt/ResourceConflictModal";

const safeParseDate = (dateString) => {
    if (!dateString) return null;
    try {
      const date = new Date(dateString);
      return isValid(date) ? date : null;
    } catch (error) {
      console.warn("Failed to parse date:", dateString, error);
      return null;
    }
};

const safeDateFormat = (dateString, formatStr = "MMM d") => {
    const date = safeParseDate(dateString);
    return date ? format(date, formatStr) : "N/A";
};

export default function ResourcePlanner() {
  const [resources, setResources] = useState([]);
  const [tasks, setTasks] = useState([]);
  const [projects, setProjects] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [view, setView] = useState("week");
  const [currentDate, setCurrentDate] = useState(new Date());
  const [focusedResource, setFocusedResource] = useState(null);
  const [selectedProject, setSelectedProject] = useState(null);
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [selectedTask, setSelectedTask] = useState(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConflictModal, setShowConflictModal] = useState(false);
  const [conflictData, setConflictData] = useState({ newTask: null, conflictingTasks: [], allResourceTasks: [], resource: null, conflictingDays: [] });

  useEffect(() => {
    loadData();
    
    const handleTaskUpdate = () => {
      loadData();
    };

    const handleTaskDelete = () => {
      loadData();
    };

    window.addEventListener('taskUpdated', handleTaskUpdate);
    window.addEventListener('taskDeleted', handleTaskDelete);

    return () => {
      window.removeEventListener('taskUpdated', handleTaskUpdate);
      window.removeEventListener('taskDeleted', handleTaskDelete);
    };
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [resourcesData, tasksData, projectsData] = await Promise.all([
        Resource.list("name"),
        Task.list(),
        Project.list("name")
      ]);
      setResources(resourcesData);
      setTasks(tasksData);
      setProjects(projectsData);
    } catch (error) {
      console.error("Error loading data:", error);
    }
    setIsLoading(false);
  };
  
  // Helper to get business days between two dates, inclusive
  const getBusinessDays = (start, end) => {
    // Ensure dates are valid before processing
    if (!start || !end || !isValid(start) || !isValid(end)) return [];
    try {
      return eachDayOfInterval({ start, end }).filter(day => day.getDay() !== 0 && day.getDay() !== 6);
    } catch (error) {
      console.warn("Error calculating business days:", error);
      return [];
    }
  };

  const checkForConflict = (taskData) => {
    const assignedResource = resources.find(r => r.id === taskData.assigned_to);
    if (!assignedResource) return null;

    const dailyCapacity = assignedResource.capacity_hours_per_day || 8;

    const newPlannedStartDate = safeParseDate(taskData.start_date);
    const newPlannedEndDate = safeParseDate(taskData.end_date);
    
    if (!newPlannedStartDate || !newPlannedEndDate) {
        console.warn("Invalid start or end date for new/updated task, skipping conflict check:", taskData);
        return null;
    }

    // Calculate effective daily effort for the new task
    const newEffort = taskData.estimated_effort || 0;
    const newDurationDays = Math.max(1, getBusinessDays(newPlannedStartDate, newPlannedEndDate).length);
    const newDailyEffort = newDurationDays > 0 ? newEffort / newDurationDays : 0;

    // Filter out the task being updated from the list of existing tasks for accurate conflict checking
    const allTasksForResource = tasks.filter(t => 
      t.assigned_to === assignedResource.id && 
      t.status !== 'completed' && 
      t.id !== taskData.id
    );

    let foundConflict = false;
    let conflictingDays = [];
    let cumulativeConflictingTasks = [];

    try {
      const intervalToCheck = eachDayOfInterval({ start: newPlannedStartDate, end: newPlannedEndDate });

      for (const day of intervalToCheck) {
          if (day.getDay() === 0 || day.getDay() === 6) continue;

          let dailyWorkload = newDailyEffort;
          let dayConflictingTasks = [];

          for (const existingTask of allTasksForResource) {
              const existingPlannedStartDate = safeParseDate(existingTask.start_date);
              const existingPlannedEndDate = safeParseDate(existingTask.end_date);

              if (!existingPlannedStartDate || !existingPlannedEndDate) {
                  continue;
              }

              try {
                if (isWithinInterval(day, { start: startOfDay(existingPlannedStartDate), end: endOfDay(existingPlannedEndDate) })) {
                    const existingEffort = existingTask.estimated_effort || 0;
                    const existingDurationDays = Math.max(1, getBusinessDays(existingPlannedStartDate, existingPlannedEndDate).length);
                    const existingDailyEffort = existingDurationDays > 0 ? existingEffort / existingDurationDays : 0;
                    
                    dailyWorkload += existingDailyEffort;
                    dayConflictingTasks.push(existingTask);
                }
              } catch (dateError) {
                console.warn("Error checking date interval for task:", existingTask.id, dateError);
              }
          }

          if (dailyWorkload > dailyCapacity) {
              foundConflict = true;
              conflictingDays.push(day);
              cumulativeConflictingTasks.push(...dayConflictingTasks); 
          }
      }
    } catch (error) {
      console.warn("Error checking for conflicts:", error);
      return null;
    }

    if (foundConflict) {
        const uniqueConflictingTasks = Array.from(new Set([...cumulativeConflictingTasks.map(t => t.id)])).map(id => cumulativeConflictingTasks.find(t => t.id === id));
        
        if (!uniqueConflictingTasks.some(t => t.id === taskData.id)) {
            uniqueConflictingTasks.push(taskData);
        }

        return {
            conflictingTasks: uniqueConflictingTasks,
            allResourceTasks: allTasksForResource,
            resource: assignedResource,
            conflictingDays: conflictingDays.sort((a,b) => a.getTime() - b.getTime()),
        };
    }

    return null;
  };

  const saveTask = async (taskData) => {
    setIsSubmitting(true);
    try {
      const cleanTaskData = {
        ...taskData,
        priority: parseInt(taskData.priority) || 5,
        progress: parseInt(taskData.progress) || 0,
        duration_days: parseInt(taskData.duration_days) || 1,
        estimated_effort: parseFloat(taskData.estimated_effort) || 0,
        is_ongoing: Boolean(taskData.is_ongoing)
      };

      if (cleanTaskData.id) {
        await Task.update(cleanTaskData.id, cleanTaskData);
      } else {
        await Task.create(cleanTaskData);
      }
      await loadData();
      setShowTaskForm(false);
      setSelectedTask(null);
      setShowConflictModal(false);
      
      window.dispatchEvent(new CustomEvent('taskUpdated', { detail: { taskData: cleanTaskData } }));
    } catch (error) {
      console.error("Error saving task:", error);
      alert("Failed to save task. Please try again.");
    }
    setIsSubmitting(false);
  };
  
  const handleTaskFormSubmit = async (taskData) => {
    if (taskData.assigned_to && taskData.status !== 'completed') {
        const conflict = checkForConflict(taskData);

        if (conflict) {
            setConflictData({ newTask: taskData, ...conflict });
            setShowConflictModal(true);
            return;
        }
    }

    await saveTask(taskData);
  };
  
  const handleConflictResolved = async (resolvedTaskData) => {
    await saveTask(resolvedTaskData);
  };
  
  const handleTaskClick = (task) => {
    setSelectedTask(task);
    setShowTaskForm(true);
  };

  const handleTaskFormCancel = () => {
    setShowTaskForm(false);
    setSelectedTask(null);
  };

  const handleDeleteTask = async (taskId) => {
    if (!window.confirm("Are you sure you want to delete this task?")) return;
    try {
      await Task.delete(taskId);
      await loadData();
      setShowTaskForm(false);
      setSelectedTask(null);
      window.dispatchEvent(new CustomEvent('taskDeleted', { detail: { taskId } }));
    } catch (error) {
      console.error("Error deleting task:", error);
      alert("Failed to delete task. Please try again.");
    }
  };

  const getTasksForResource = (resourceId) => {
    const startOfTargetWeek = startOfWeek(currentDate, { weekStartsOn: 0 });
    const endOfTargetWeek = addDays(startOfTargetWeek, 4);

    const startOfTargetDay = startOfDay(currentDate);
    const endOfTargetDay = endOfDay(currentDate);

    const targetRange = view === 'day' 
      ? { start: startOfTargetDay, end: endOfTargetDay } 
      : { start: startOfTargetWeek, end: endOfTargetWeek };

    let filteredTasks = tasks.filter(task => {
      if (task.assigned_to !== resourceId || task.status === 'completed') {
        return false;
      }
      
      const plannedStartDate = safeParseDate(task.start_date);
      const plannedEndDate = safeParseDate(task.end_date);
      
      if (!plannedStartDate || !plannedEndDate) {
        return false;
      }

      if (selectedProject && task.project_id !== selectedProject) {
        return false;
      }

      const actualStartDate = safeParseDate(task.actual_start_date);
      
      try {
        // A task is considered relevant if its planned period overlaps with the target range
        // OR if it's ongoing (started before the target range and still active)
        // OR if its actual start date is within the target range.
        const plannedOverlap = plannedStartDate <= targetRange.end && plannedEndDate >= targetRange.start;
        const actualOverlap = actualStartDate && (
          isWithinInterval(actualStartDate, targetRange) ||
          (actualStartDate < targetRange.start && (task.status === 'in_progress' || task.status === 'not_started'))
        );

        // Additionally, consider tasks marked as 'is_ongoing' that started before the period
        const isCurrentlyOngoing = task.is_ongoing && plannedStartDate < targetRange.start && (task.status === 'in_progress' || task.status === 'not_started');
        
        return plannedOverlap || actualOverlap || isCurrentlyOngoing;
      } catch (error) {
        console.warn("Error filtering task:", task.id, error);
        return false;
      }
    }).map(task => {
      const plannedStartDate = safeParseDate(task.start_date);
      const actualStartDate = safeParseDate(task.actual_start_date);

      let displayMode = 'planned'; // Default

      try {
        // If task is explicitly marked as ongoing
        if (task.is_ongoing) {
          displayMode = 'ongoing';
        } 
        // If task has an actual start date within the current period
        else if (actualStartDate && isWithinInterval(actualStartDate, targetRange)) {
          displayMode = 'actual_started';
        }
        // If actual start date is before the current period and still active but not marked as is_ongoing
        else if (actualStartDate && actualStartDate < targetRange.start && (task.status === 'in_progress' || task.status === 'not_started')) {
          displayMode = 'ongoing'; // Treat as ongoing for display if it started before and is in progress
        }

        return {
          ...task,
          displayMode,
          // These flags are not strictly used for display anymore but kept for context if needed
          plannedForPeriod: isWithinInterval(plannedStartDate, targetRange) || 
                           isWithinInterval(safeParseDate(task.end_date), targetRange),
          actualInPeriod: actualStartDate && isWithinInterval(actualStartDate, targetRange)
        };
      } catch (error) {
        console.warn("Error processing task display mode:", task.id, error);
        return {
          ...task,
          displayMode: 'planned', // Fallback
          plannedForPeriod: false,
          actualInPeriod: false
        };
      }
    });

    return filteredTasks.sort((a, b) => {
      // Primary sort by custom sort_order
      const orderA = a.sort_order ?? Infinity;
      const orderB = b.sort_order ?? Infinity;
      if (orderA !== orderB) {
        return orderA - orderB;
      }

      // Secondary sort by priority (higher priority first)
      if (a.priority !== b.priority) {
        return (b.priority || 5) - (a.priority || 5);
      }
      
      // Tertiary sort by start date (earlier first)
      const aStartDate = safeParseDate(a.start_date);
      const bStartDate = safeParseDate(b.start_date);

      if (!aStartDate && bStartDate) return 1;
      if (aStartDate && !bStartDate) return -1;
      if (!aStartDate && !bStartDate) return 0;

      return aStartDate.getTime() - bStartDate.getTime();
    });
  };

  const calculateWorkload = (resource) => {
    const resourceTasks = getTasksForResource(resource.id);
    const capacity = resource.capacity_hours_per_day || 8;

    let periodDays;
    if (view === 'day') {
        periodDays = 1;
    } else {
        const start = startOfWeek(currentDate, { weekStartsOn: 0 });
        const end = addDays(start, 4);
        periodDays = getBusinessDays(start, end).length;
    }
    
    const totalCapacity = capacity * periodDays;
    
    let totalEffort = 0;
    resourceTasks.forEach(task => {
        const plannedStartDate = safeParseDate(task.start_date);
        const plannedEndDate = safeParseDate(task.end_date);

        if (!plannedStartDate || !plannedEndDate) {
          return;
        }

        try {
          const periodStart = view === 'day' ? startOfDay(currentDate) : startOfWeek(currentDate, { weekStartsOn: 0 });
          const periodEnd = view === 'day' ? endOfDay(currentDate) : addDays(startOfWeek(currentDate, { weekStartsOn: 0 }), 4);

          const overlapStart = new Date(Math.max(plannedStartDate.getTime(), periodStart.getTime()));
          const overlapEnd = new Date(Math.min(plannedEndDate.getTime(), periodEnd.getTime()));

          if (overlapStart <= overlapEnd) {
              const taskDurationDays = Math.max(1, getBusinessDays(plannedStartDate, plannedEndDate).length);
              const dailyEffort = (task.estimated_effort || 0) / taskDurationDays;
              
              const overlappingBusinessDays = getBusinessDays(overlapStart, overlapEnd).length;
              totalEffort += dailyEffort * overlappingBusinessDays;
          }
        } catch (error) {
          console.warn("Error calculating workload for task:", task.id, error);
        }
    });
    
    const workloadPercentage = totalCapacity > 0 ? Math.round((totalEffort / totalCapacity) * 100) : 0;
    
    return { totalEffort: parseFloat(totalEffort.toFixed(1)), totalCapacity, workloadPercentage };
  };

  const getInitials = (name) => {
    return name?.split(" ").map(n => n[0]).join("").toUpperCase() || 'U';
  };

  const handlePrev = () => {
    const newDate = view === 'day' ? addDays(currentDate, -1) : addWeeks(currentDate, -1);
    setCurrentDate(newDate);
  };

  const handleNext = () => {
    const newDate = view === 'day' ? addDays(currentDate, 1) : addWeeks(currentDate, 1);
    setCurrentDate(newDate);
  };

  const handleToday = () => {
    setCurrentDate(new Date());
    setView("day");
  };

  const handleProjectChange = (projectId) => {
    setSelectedProject(projectId === "all" ? null : projectId);
  };

  const handleTaskReorder = async (result) => {
    const { source, destination, draggableId } = result;

    if (!destination) return;

    // Helper to parse droppableId: can be just resourceId or "resourceId-columnType"
    const parseDroppableId = (id) => {
      const parts = id.split('-');
      if (parts.length > 1 && (parts[parts.length - 1] === 'ongoing' || parts[parts.length - 1] === 'period')) {
        return { resourceId: parts.slice(0, parts.length - 1).join('-'), columnType: parts[parts.length - 1] };
      }
      return { resourceId: id, columnType: null };
    };

    const sourceInfo = parseDroppableId(source.droppableId);
    const destInfo = parseDroppableId(destination.droppableId);

    const sourceResourceId = sourceInfo.resourceId;
    const destinationResourceId = destInfo.resourceId;
    const sourceColumnType = sourceInfo.columnType; // 'ongoing', 'period', or null (for main view)
    const destColumnType = destInfo.columnType;     // 'ongoing', 'period', or null (for main view)

    const taskId = draggableId;
    const currentTask = tasks.find(t => t.id === taskId);
    if (!currentTask) return;

    let updatedTaskData = { ...currentTask };
    let needsFullReload = false; // Indicates if assigned_to or is_ongoing changed, requiring a full data reload to re-evaluate display modes/sorting

    // Case 1: Moving between different resources (in the main view or between resource cards)
    if (sourceResourceId !== destinationResourceId) {
        updatedTaskData.assigned_to = destinationResourceId;
        updatedTaskData.sort_order = null; // Reset sort order when reassigning resource
        needsFullReload = true;
    }
    // Case 2: Moving within the same resource (could be same column or different columns in focused view)
    else {
        // Sub-case 2.1: Moving between 'ongoing' and 'period' columns for the same resource (focused view)
        if (sourceColumnType !== destColumnType) {
            updatedTaskData.is_ongoing = (destColumnType === 'ongoing'); // Update is_ongoing flag
            updatedTaskData.sort_order = null; // Reset sort order, let default sort apply for the new column
            needsFullReload = true;
        }
        // Sub-case 2.2: Reordering within the same column/droppable for the same resource
        else {
            // Get the list of tasks for the source resource, sorted by current sort_order.
            // Draggable's index is relative to this *global* list for the resource,
            // even if the task is displayed in a filtered column.
            let tasksForThisResource = getTasksForResource(sourceResourceId);

            // Create a mutable copy and reorder based on global indices (source.index, destination.index)
            const [reorderedItem] = tasksForThisResource.splice(source.index, 1);
            tasksForThisResource.splice(destination.index, 0, reorderedItem);

            // Prepare for optimistic UI update and API call for sort_order
            const updatedSortOrders = {};
            tasksForThisResource.forEach((task, idx) => {
                updatedSortOrders[task.id] = idx;
            });

            setTasks(prevTasks => prevTasks.map(t => {
                if (t.assigned_to === sourceResourceId && updatedSortOrders.hasOwnProperty(t.id)) {
                    return { ...t, sort_order: updatedSortOrders[t.id] };
                }
                return t;
            }));

            try {
                const updatePromises = tasksForThisResource.map(task =>
                    Task.update(task.id, { sort_order: updatedSortOrders[task.id] })
                );
                await Promise.all(updatePromises);
                window.dispatchEvent(new CustomEvent('taskUpdated', { detail: { updatedTasks: tasksForThisResource.map(t => ({id: t.id, sort_order: updatedSortOrders[t.id]})) } }));
            } catch (error) {
                console.error("Error reordering task:", error);
                loadData(); // Revert to server state on error
                alert("Failed to reorder task. Please try again.");
            }
            return; // Exit after handling simple reorder
        }
    }

    // Check for conflict if task properties (assigned_to or is_ongoing) are changing
    if (needsFullReload && updatedTaskData.assigned_to && updatedTaskData.status !== 'completed') {
        const conflict = checkForConflict(updatedTaskData);
        if (conflict) {
            setConflictData({ newTask: updatedTaskData, ...conflict });
            setShowConflictModal(true);
            return; // Do not proceed if conflict found
        }
    }

    // Perform API call and full reload for changes in assigned_to or is_ongoing
    try {
        setTasks(prevTasks => prevTasks.map(t =>
            t.id === taskId ? { ...t, ...updatedTaskData } : t
        )); // Optimistic UI update
        await Task.update(taskId, updatedTaskData);
        await loadData(); // Full data reload to correctly reflect changes in display mode and sorting
        window.dispatchEvent(new CustomEvent('taskUpdated', { detail: { taskId, changes: updatedTaskData } }));
    } catch (error) {
        console.error("Error updating task properties:", error);
        loadData(); // Revert to server state on error
        alert("Failed to update task. Please try again.");
    }
  };

  const renderDateHeader = () => {
    if (view === 'day') {
      return format(currentDate, "EEEE, MMMM d");
    }
    const start = startOfWeek(currentDate, { weekStartsOn: 0 });
    const end = addDays(start, 4);
    return `${format(start, 'MMM d')} - ${format(end, 'MMM d, yyyy')}`;
  };

  const getTaskDisplayColor = (task) => {
    switch (task.displayMode) {
      case 'actual_started':
        return 'bg-green-100 border-green-300 text-green-800';
      case 'ongoing':
        return 'bg-blue-100 border-blue-300 text-blue-800';
      case 'planned':
      default:
        return 'bg-gray-100 border-gray-300 text-gray-700';
    }
  };

  const getTaskIcon = (task) => {
    switch (task.displayMode) {
      case 'actual_started':
        return <Play className="w-3 h-3 text-green-600" />;
      case 'ongoing':
        return <Clock className="w-3 h-3 text-blue-600" />;
      case 'planned':
      default:
        return <Calendar className="w-3 h-3 text-gray-500" />;
    }
  };

  const getPriorityColor = (priority) => {
    if (priority >= 8) return 'bg-red-100 text-red-800';
    if (priority >= 6) return 'bg-orange-100 text-orange-800';
    if (priority >= 4) return 'bg-yellow-100 text-yellow-800';
    return 'bg-green-100 text-green-800';
  };

  const handleResourceFocus = (resource) => {
    setFocusedResource(resource);
  };

  const handleBackToAll = () => {
    setFocusedResource(null);
  };

  if (isLoading) {
    return (
      <div className="p-6">
        <Skeleton className="h-12 w-1/3 mb-8" />
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {Array(3).fill(0).map((_, i) => (
            <Card key={i}>
              <CardHeader><Skeleton className="h-6 w-1/2" /></CardHeader>
              <CardContent><Skeleton className="h-24 w-full" /></CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }
  
  if (showTaskForm) {
    return (
      <div className="p-6">
        <TaskForm
          task={selectedTask}
          onSubmit={handleTaskFormSubmit}
          onCancel={handleTaskFormCancel}
          onDelete={handleDeleteTask}
          projects={projects}
          resources={resources}
          allTasks={tasks}
          isSubmitting={isSubmitting}
        />
      </div>
    );
  }

  // Single Resource View
  if (focusedResource) {
    const tasksForFocusedResource = getTasksForResource(focusedResource.id);
    const { totalEffort, totalCapacity, workloadPercentage } = calculateWorkload(focusedResource);

    // Filter tasks based on is_ongoing flag and displayMode
    const ongoingTasks = tasksForFocusedResource.filter(t => t.is_ongoing || t.displayMode === 'ongoing');
    const periodTasks = tasksForFocusedResource.filter(t => !t.is_ongoing && t.displayMode !== 'ongoing');

    return (
      <div className="p-6">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Button variant="outline" onClick={handleBackToAll}>
              <ChevronLeft className="w-4 h-4 mr-2" />
              Back to All Resources
            </Button>
            <div className="flex items-center gap-3">
              <Avatar className="h-12 w-12">
                <AvatarFallback className="bg-slate-200 text-slate-700 font-semibold">
                  {getInitials(focusedResource.name)}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-2xl font-bold text-slate-900">{focusedResource.name}</h1>
                <p className="text-slate-600">{focusedResource.role}</p>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <Select value={selectedProject || "all"} onValueChange={handleProjectChange}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Projects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map((project) => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div className="flex items-center gap-1">
              <Button variant="outline" size="icon" onClick={handlePrev}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <Button variant="outline" size="icon" onClick={handleNext}>
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
            <Button variant="outline" onClick={handleToday}>Today</Button>
            <div className="flex bg-slate-100 rounded-lg p-1">
              <Button
                variant={view === 'day' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setView('day')}
                className={`flex items-center gap-2 ${view === 'day' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600'}`}
              >
                <Sun className="w-4 h-4" /> Day
              </Button>
              <Button
                variant={view === 'week' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setView('week')}
                className={`flex items-center gap-2 ${view === 'week' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600'}`}
              >
                <CalendarDays className="w-4 h-4" /> Week
              </Button>
            </div>
          </div>
        </div>

        <DragDropContext onDragEnd={handleTaskReorder}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 max-w-7xl mx-auto">
            {/* Ongoing Tasks Column */}
            <Card>
              <CardHeader>
                <CardTitle>Ongoing Tasks ({ongoingTasks.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <Droppable droppableId={`${focusedResource.id}-ongoing`}>
                  {(provided) => (
                    <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-3 min-h-[100px] border border-dashed rounded-lg p-2">
                      {ongoingTasks.map((task) => (
                        <Draggable key={task.id} draggableId={task.id} index={tasksForFocusedResource.findIndex(t => t.id === task.id)}>
                          {(provided, snapshot) => (
                            <div
                              ref={provided.innerRef}
                              {...provided.draggableProps}
                              onClick={() => handleTaskClick(task)}
                              className={`p-4 border rounded-lg ${getTaskDisplayColor(task)} ${
                                snapshot.isDragging ? 'shadow-lg' : ''
                              } cursor-pointer`}
                            >
                              <div className="flex items-start gap-3">
                                <div {...provided.dragHandleProps}>
                                  <GripVertical className="w-4 h-4 text-gray-400 mt-1" />
                                </div>
                                {getTaskIcon(task)}
                                <div className="flex-1">
                                  <div className="flex items-start justify-between">
                                    <h5 className="font-semibold text-sm">{task.title}</h5>
                                    <Badge className={getPriorityColor(task.priority || 5)}>
                                      P{task.priority || 5}
                                    </Badge>
                                  </div>
                                  <div className="flex items-center justify-between text-xs mt-2">
                                    <span>{safeDateFormat(task.start_date, 'MMM d')} - {safeDateFormat(task.end_date, 'MMM d')}</span>
                                    <span>{task.estimated_effort || 0}h</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          )}
                        </Draggable>
                      ))}
                      {provided.placeholder}
                      {ongoingTasks.length === 0 && (
                        <div className="text-center py-8 text-slate-500">
                          No ongoing tasks.
                        </div>
                      )}
                    </div>
                  )}
                </Droppable>
              </CardContent>
            </Card>

            {/* Period Tasks Column */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>Tasks for {renderDateHeader()}</CardTitle>
                   <Badge variant={workloadPercentage > 100 ? "destructive" : workloadPercentage > 80 ? "secondary" : "outline"}>
                    {workloadPercentage}%
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center text-sm mb-2">
                      <span className="text-slate-600">Workload</span>
                      <span className="font-medium">{totalEffort}h / {totalCapacity}h</span>
                    </div>
                    <Progress value={Math.min(100, workloadPercentage)} className="h-3" />
                  </div>
                  <Droppable droppableId={`${focusedResource.id}-period`}>
                    {(provided) => (
                      <div {...provided.droppableProps} ref={provided.innerRef} className="space-y-3 min-h-[100px] border border-dashed rounded-lg p-2">
                        {periodTasks.map((task) => (
                           <Draggable key={task.id} draggableId={task.id} index={tasksForFocusedResource.findIndex(t => t.id === task.id)}>
                            {(provided, snapshot) => (
                              <div
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                onClick={() => handleTaskClick(task)}
                                className={`p-4 border rounded-lg ${getTaskDisplayColor(task)} ${
                                  snapshot.isDragging ? 'shadow-lg' : ''
                                } cursor-pointer`}
                              >
                                <div className="flex items-start gap-3">
                                  <div {...provided.dragHandleProps}>
                                    <GripVertical className="w-4 h-4 text-gray-400 mt-1" />
                                  </div>
                                  {getTaskIcon(task)}
                                  <div className="flex-1">
                                    <div className="flex items-start justify-between">
                                      <h5 className="font-semibold text-sm">{task.title}</h5>
                                      <Badge className={getPriorityColor(task.priority || 5)}>
                                        P{task.priority || 5}
                                      </Badge>
                                    </div>
                                    <div className="flex items-center justify-between text-xs mt-2">
                                      <span>{safeDateFormat(task.start_date, 'MMM d')} - {safeDateFormat(task.end_date, 'MMM d')}</span>
                                      <span>{task.estimated_effort || 0}h</span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            )}
                          </Draggable>
                        ))}
                        {provided.placeholder}
                        {periodTasks.length === 0 && (
                          <div className="text-center py-8 text-slate-500">
                            No tasks for this period.
                          </div>
                        )}
                      </div>
                    )}
                  </Droppable>
                </div>
              </CardContent>
            </Card>
          </div>
        </DragDropContext>
        
        <ResourceConflictModal
          isOpen={showConflictModal}
          onClose={() => setShowConflictModal(false)}
          onConfirm={handleConflictResolved}
          newTaskData={conflictData.newTask}
          conflictingTasks={conflictData.conflictingTasks}
          allResourceTasks={conflictData.allResourceTasks}
          resource={conflictData.resource}
          conflictingDays={conflictData.conflictingDays}
        />
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Resource Planner</h1>
          <p className="text-slate-600 mt-1">View team workload with priorities and project filtering.</p>
        </div>
        <div className="flex items-center gap-4">
          <Select value={selectedProject || "all"} onValueChange={handleProjectChange}>
            <SelectTrigger className="w-48">
              <SelectValue placeholder="All Projects" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Projects</SelectItem>
              {projects.map((project) => (
                <SelectItem key={project.id} value={project.id}>
                  {project.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <div className="flex items-center gap-1">
            <Button variant="outline" size="icon" onClick={handlePrev}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={handleNext}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
          <Button variant="outline" onClick={handleToday}>
            Today
          </Button>
          <div className="flex bg-slate-100 rounded-lg p-1">
            <Button
              variant={view === 'day' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setView('day')}
              className={`flex items-center gap-2 ${view === 'day' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600'}`}
            >
              <Sun className="w-4 h-4" /> Day
            </Button>
            <Button
              variant={view === 'week' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setView('week')}
              className={`flex items-center gap-2 ${view === 'week' ? 'bg-white shadow-sm text-slate-900' : 'text-slate-600'}`}
            >
              <CalendarDays className="w-4 h-4" /> Week
            </Button>
          </div>
        </div>
      </div>

      <div className="mb-6">
        <div className="text-center mb-4">
          <h2 className="text-xl font-semibold text-slate-800">{renderDateHeader()}</h2>
        </div>
        
        <div className="flex justify-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-gray-300 rounded"></div>
            <span className="text-slate-600">Planned</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-400 rounded"></div>
            <span className="text-slate-600">Actually Started</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-400 rounded"></div>
            <span className="text-slate-600">Ongoing</span>
          </div>
        </div>
      </div>

      <DragDropContext onDragEnd={handleTaskReorder}>
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {resources.map((resource) => {
            const resourceTasks = getTasksForResource(resource.id);
            const { totalEffort, totalCapacity, workloadPercentage } = calculateWorkload(resource);
            
            return (
              <Card key={resource.id} className="hover:shadow-lg transition-shadow">
                <CardHeader onDoubleClick={() => handleResourceFocus(resource)} className="cursor-pointer">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-slate-200 text-slate-700 font-semibold">
                          {getInitials(resource.name)}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <CardTitle>{resource.name}</CardTitle>
                        <p className="text-sm text-slate-500">{resource.role}</p>
                      </div>
                    </div>
                    <Badge variant={workloadPercentage > 100 ? "destructive" : workloadPercentage > 80 ? "secondary" : "outline"} className="font-semibold">
                      {workloadPercentage}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between items-center text-sm mb-1">
                        <span className="text-slate-600">Workload</span>
                        <span className="font-medium">{totalEffort}h / {totalCapacity}h</span>
                      </div>
                      <Progress value={Math.min(100, workloadPercentage)} />
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-medium text-sm text-slate-800">Tasks ({resourceTasks.length})</h4>
                      <Droppable droppableId={resource.id}>
                        {(provided) => (
                          <div 
                            {...provided.droppableProps} 
                            ref={provided.innerRef} 
                            className="space-y-2 max-h-48 overflow-y-auto pr-2 min-h-[50px] border border-dashed rounded-lg p-2"
                          >
                            {resourceTasks.map((task, index) => (
                              <Draggable key={task.id} draggableId={task.id} index={index}>
                                {(provided, snapshot) => (
                                  <div
                                    ref={provided.innerRef}
                                    {...provided.draggableProps}
                                    onClick={() => handleTaskClick(task)}
                                    className={`block p-3 border rounded-lg hover:bg-opacity-80 transition-colors cursor-pointer ${getTaskDisplayColor(task)} ${
                                      snapshot.isDragging ? 'shadow-lg' : ''
                                    }`}
                                  >
                                    <div className="flex items-start gap-2">
                                      <div {...provided.dragHandleProps}>
                                        <GripVertical className="w-3 h-3 text-gray-400 mt-1" />
                                      </div>
                                      {getTaskIcon(task)}
                                      <div className="flex-1 min-w-0">
                                        <div className="flex items-start justify-between">
                                          <p className="font-semibold text-sm truncate">{task.title}</p>
                                          <Badge className={`${getPriorityColor(task.priority || 5)}`} variant="secondary">
                                            P{task.priority || 5}
                                          </Badge>
                                        </div>
                                        <div className="flex items-center justify-between text-xs mt-1">
                                          <span>{safeDateFormat(task.start_date, 'MMM d')} - {safeDateFormat(task.end_date, 'MMM d')}</span>
                                          <span>{task.estimated_effort || 0}h</span>
                                        </div>
                                        {task.actual_start_date && (
                                          <div className="text-xs opacity-75 mt-1">
                                            Started: {safeDateFormat(task.actual_start_date, 'MMM d')}
                                          </div>
                                        )}
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </Draggable>
                            ))}
                            {provided.placeholder}
                            {resourceTasks.length === 0 && (
                                <div className="text-center py-4 text-sm text-slate-500">No active tasks for this period. Drop tasks here.</div>
                            )}
                          </div>
                        )}
                      </Droppable>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </DragDropContext>
       <ResourceConflictModal
        isOpen={showConflictModal}
        onClose={() => setShowConflictModal(false)}
        onConfirm={handleConflictResolved}
        newTaskData={conflictData.newTask}
        conflictingTasks={conflictData.conflictingTasks}
        allResourceTasks={conflictData.allResourceTasks}
        resource={conflictData.resource}
        conflictingDays={conflictData.conflictingDays}
      />
    </div>
  );
}
