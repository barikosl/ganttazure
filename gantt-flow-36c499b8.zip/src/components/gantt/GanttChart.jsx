
import React, { useState, useEffect, useLayoutEffect, useRef, useMemo, useCallback } from "react";
import { format, addDays, differenceInDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth, addHours, isValid, parseISO } from "date-fns";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select"; // Added Select imports
import { CalendarDays, Clock, User, AlertTriangle, Plus, ChevronRight, ChevronDown, Edit, Trash, ChevronLeft, GripVertical, Indent, Outdent, Copy, Link, Unlink, ArrowRight, MoreVertical, TreePine, Search, ListCollapse, Loader2, X } from "lucide-react";
import InlineTaskEditor from "./InlineTaskEditor";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

const COMPACT_ROW_HEIGHT = 40; // Fixed height for compact rows

export default function GanttChart({
  tasks,
  projects,
  resources,
  viewMode = "weekly",
  selectedProject,
  onTaskClick,
  onTaskUpdate,
  onBulkTaskUpdate,
  onCreateTask,
  onTaskDelete,
  onTaskDuplicate,
  onTaskOutdent,
  onTaskIndent,
  onTaskReorder,
  onTaskReparent,
  onTaskUnlinkAll,
  onFindNextAvailableSlot,
  onApplySuggestion,
  expandedTasks,
  onExpandedChange,
  isConflictCheckMode,
  onSelectResourceForCheck,
  selectedResourcesForCheck,
  updatingTasks = new Set(),
  indentMode,
  onToggleIndentMode,
  hoursPerDay = 9
}) {
  const [timelineRange, setTimelineRange] = useState({
    start: new Date(),
    end: addDays(new Date(), 30)
  });
  const [creatingTaskAfter, setCreatingTaskAfter] = useState(null);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [editingField, setEditingField] = useState(null);
  const [showQuickTaskForm, setShowQuickTaskForm] = useState(false);
  const [linkingMode, setLinkingMode] = useState(false);
  const [selectedTasksForLinking, setSelectedTasksForLinking] = useState([]);
  const [hoveredLink, setHoveredLink] = useState(null);
  const [dragOverTarget, setDragOverTarget] = useState(null);
  const [durationDisplayUnit, setDurationDisplayUnit] = useState('days');
  const [slotFinderState, setSlotFinderState] = useState({ open: false, taskId: null, slots: [], isLoading: false });
  const [highlightedTask, setHighlightedTask] = useState(null); // New state for badge click highlighting
  const [forceRenderKey, setForceRenderKey] = useState(0); // Added for forced re-renders

  const [taskListWidth, setTaskListWidth] = useState(800);
  const [isResizing, setIsResizing] = useState(false);
  const ganttContainerRef = useRef(null);
  const taskListRef = useRef(null);
  const timelineRef = useRef(null);
  const timelineBarRefs = useRef({});
  const taskHeaderRef = useRef(null);
  const [headerHeight, setHeaderHeight] = useState(0);
  const isSyncingScroll = useRef(false);

  // Custom log helper
  const customLog = useCallback((context, data) => {
    console.log(`[GanttChart Debug] ${context}:`, data);
  }, []);

  // Helper functions for working hours and days
  const isWorkingDay = useCallback((date) => {
    const dayOfWeek = date.getDay(); // 0 = Sunday, 6 = Saturday
    return dayOfWeek !== 0 && dayOfWeek !== 6; // Exclude weekends
  }, []);

  // This function adds 'hoursToAdd' working hours, respecting working days and hoursPerDay
  const addWorkingHours = useCallback((startDate, hoursToAdd) => {
    let current = new Date(startDate);
    let remainingHours = hoursToAdd;

    // If the task itself has 0 duration, return the start date
    if (hoursToAdd <= 0) {
      return current;
    }

    // If current is not a working day, advance to the next working day, 8 AM
    while (!isWorkingDay(current)) {
      current = addDays(current, 1);
      current.setHours(8, 0, 0, 0); // Set to start of working day
    }

    // If task starts after assumed working hours start (e.g., 8 AM)
    let currentDayHoursUsed = Math.max(0, current.getHours() - 8);
    if (currentDayHoursUsed >= hoursPerDay) { // If task starts beyond working hours of current day, move to next day
      current = addDays(current, 1);
      current.setHours(8, 0, 0, 0); // Set to start of next working day
      currentDayHoursUsed = 0; // Reset hours used for the new day
      // Ensure the new day is also a working day
      while (!isWorkingDay(current)) {
        current = addDays(current, 1);
        current.setHours(8, 0, 0, 0);
      }
    }

    let hoursAvailableToday = hoursPerDay - currentDayHoursUsed;

    // Consume hours
    while (remainingHours > 0) {
      if (remainingHours <= hoursAvailableToday) {
        // All remaining hours fit into the current working day
        current = addHours(current, remainingHours);
        remainingHours = 0;
      } else {
        // Consume all available hours today
        remainingHours -= hoursAvailableToday;
        current = addDays(current, 1); // Move to the next day
        current.setHours(8, 0, 0, 0); // Start of working hours on the new day

        // Skip non-working days
        while (!isWorkingDay(current)) {
          current = addDays(current, 1);
          current.setHours(8, 0, 0, 0);
        }
        hoursAvailableToday = hoursPerDay; // Reset available hours for the new day
      }
    }

    return current;
  }, [isWorkingDay, hoursPerDay]);

  // handleCellEdit function
  const handleCellEdit = useCallback((taskId, field, value) => {
    console.log('🎯 GanttChart: handleCellEdit called', {
      taskId,
      field,
      value,
      valueType: typeof value,
      isNull: value === null,
      isUndefined: value === undefined
    });

    // Validate inputs
    if (!taskId) {
      console.error('❌ GanttChart: handleCellEdit called with invalid taskId', { taskId });
      customLog('handleCellEdit: Invalid taskId', { taskId, field, value });
      return;
    }

    if (!field) {
      console.error('❌ GanttChart: handleCellEdit called with invalid field', { field });
      customLog('handleCellEdit: Invalid field', { taskId, field, value });
      return;
    }

    // Find the task to validate it exists
    const task = tasks.find(t => t && t.id === taskId);
    if (!task) {
      console.error('❌ GanttChart: Task not found for edit', { taskId, availableTaskIds: tasks.map(t => t?.id).filter(Boolean) });
      customLog('handleCellEdit: Task not found', { taskId, field, value });
      return;
    }

    console.log('✅ GanttChart: Task found for edit', {
      taskId: task.id,
      taskTitle: task.title,
      currentValue: task[field],
      newValue: value
    });

    // Special handling for assigned_to field
    if (field === 'assigned_to') {
      console.log('👤 GanttChart: Processing assigned_to change', {
        taskId,
        oldValue: task.assigned_to,
        newValue: value,
        resourcesAvailable: resources.length,
        resourceIds: resources.map(r => r?.id).filter(Boolean)
      });

      // Validate that the resource exists if value is not null or empty string
      if (value && value !== null && value !== '') {
        const resource = resources.find(r => r && r.id === value);
        if (!resource) {
          console.error('❌ GanttChart: Invalid resource ID selected', {
            value,
            availableResources: resources.map(r => ({ id: r?.id, name: r?.name })).filter(r => r.id)
          });
          customLog('handleCellEdit: Invalid resource ID', { taskId, value, availableResources: resources.length });
          return;
        }
        console.log('✅ GanttChart: Valid resource selected', {
          resourceId: resource.id,
          resourceName: resource.name
        });
      }
    }

    try {
      // Create the update object
      const updateData = {
        id: taskId,
        [field]: value,
        __editedField: field // Add this flag for cascade logic
      };

      console.log('📤 GanttChart: Calling onTaskUpdate with data', { updateData });

      // Call the parent update handler
      onTaskUpdate(updateData);

      console.log('✅ GanttChart: onTaskUpdate called successfully');

    } catch (error) {
      console.error('❌ GanttChart: Error in handleCellEdit', {
        error,
        message: error?.message || 'No message',
        stack: error?.stack || 'No stack',
        taskId,
        field,
        value
      });
      customLog('handleCellEdit: Error occurred', {
        error: error.message,
        taskId,
        field,
        value
      });
    }
  }, [tasks, resources, onTaskUpdate, customLog]);

  // Handle splitter resizing
  useEffect(() => {
    const handleMouseMove = (e) => {
      if (!isResizing || !ganttContainerRef.current) return;
      const containerLeft = ganttContainerRef.current.getBoundingClientRect().left;
      const newWidth = e.clientX - containerLeft;
      const minWidth = 300;
      const maxWidth = ganttContainerRef.current.offsetWidth - 300;
      if (newWidth > minWidth && newWidth < maxWidth) {
        setTaskListWidth(newWidth);
      }
    };

    const handleMouseUp = () => {
      setIsResizing(false);
    };

    if (isResizing) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isResizing]);

  const handleResizeMouseDown = (e) => {
    e.preventDefault();
    setIsResizing(true);
  };

  // Synchronize Header Heights
  useEffect(() => {
    if (taskHeaderRef.current) {
      setHeaderHeight(taskHeaderRef.current.offsetHeight);
    }
  }, [linkingMode, indentMode, selectedTasksForLinking.length]);

  // Synchronize scrolling between task list and timeline
  useEffect(() => {
    const taskEl = taskListRef.current;
    const timelineEl = timelineRef.current;

    if (!taskEl || !timelineEl) return;

    const syncScroll = (source, target) => () => {
      if (!isSyncingScroll.current) {
        isSyncingScroll.current = true;
        target.scrollTop = source.scrollTop;
        requestAnimationFrame(() => {
          isSyncingScroll.current = false;
        });
      }
    };

    const handleTaskListScroll = syncScroll(taskEl, timelineEl);
    const handleTimelineScroll = syncScroll(timelineEl, taskEl);

    taskEl.addEventListener('scroll', handleTaskListScroll);
    timelineEl.addEventListener('scroll', handleTimelineScroll);

    return () => {
      taskEl.removeEventListener('scroll', handleTaskListScroll);
      timelineEl.removeEventListener('scroll', handleTimelineScroll);
    };
  }, []);

  // Effect to listen for custom viewRefresh and taskUpdated events
  useEffect(() => {
    const handleRefresh = (event) => {
      setForceRenderKey(prev => prev + 1);
      console.log(`GanttChart refreshed due to: ${event.detail?.reason || 'unknown'}`);
    };

    window.addEventListener("viewRefresh", handleRefresh);
    window.addEventListener("taskUpdated", handleRefresh);
    // New listener for targeted refreshes that might preserve state in parent
    window.addEventListener("refreshTaskView", handleRefresh);

    return () => {
      window.removeEventListener("viewRefresh", handleRefresh);
      window.removeEventListener("taskUpdated", handleRefresh);
      window.removeEventListener("refreshTaskView", handleRefresh);
    };
  }, []);

  const calculateTimelineRange = (baseDate = new Date()) => {
    let start, end;

    switch (viewMode) {
      case "daily":
        start = new Date(baseDate);
        end = addDays(baseDate, 14);
        break;
      case "weekly":
        start = startOfWeek(baseDate);
        end = addDays(startOfWeek(baseDate), 84);
        break;
      case "monthly":
        start = startOfMonth(baseDate);
        end = endOfMonth(addDays(startOfMonth(baseDate), 180));
        break;
      default:
        start = baseDate;
        end = addDays(baseDate, 30);
    }
    return { start, end };
  };

  useEffect(() => {
    setTimelineRange(calculateTimelineRange());
  }, [viewMode]);

  const handleTimelineShift = (direction) => {
    const shiftDays = {
      daily: 7,
      weekly: 28,
      monthly: 90
    }[viewMode] || 30;

    setTimelineRange((prev) => ({
      start: addDays(prev.start, direction === 'forward' ? shiftDays : -shiftDays),
      end: addDays(prev.end, direction === 'forward' ? shiftDays : -shiftDays)
    }));
  };

  const goToToday = () => {
    setTimelineRange(calculateTimelineRange(new Date()));
  };

  // Filter tasks
  const filteredTasks = selectedProject ?
    tasks.filter((task) => task.project_id === selectedProject) :
    tasks;

  // Recursively find all children for a given task
  const getSubTasks = (parentId, allTasks) => {
    return allTasks.
      filter((task) => task.parent_task_id === parentId).
      sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
  };

  // Enhanced parent calculation display
  const getParentDurationDisplay = (task, allTasks, unit = 'days') => {
    const children = allTasks.filter((t) => t.parent_task_id === task.id);
    if (children.length === 0) {
      const days = task.duration_days || 0;
      const hours = task.duration_hours || 0;

      if (unit === 'days') {
        // For leaf tasks, show days and hours separately
        let display = "";
        if (days > 0) display += `${days}d`;
        if (hours > 0) display += ` ${hours}h`;
        return display.trim() || "0d";
      } else {
        const totalHours = days * hoursPerDay + hours;
        return totalHours > 0 ? `${Math.round(totalHours * 10) / 10}h` : "0h";
      }
    }

    // Calculate total duration from children
    let totalDays = 0;
    let totalHours = 0;

    children.forEach((child) => {
      totalDays += child.duration_days || 0;
      totalHours += child.duration_hours || 0;
    });

    if (unit === 'days') {
      // Show as "Xd Yh" format
      let display = '';
      if (totalDays > 0) display += `${totalDays}d`;
      if (totalHours > 0) display += ` ${totalHours}h`;
      return display.trim() || "0d";
    } else {
      // Convert everything to hours for hours view
      const totalHoursConverted = totalDays * hoursPerDay + totalHours;
      return totalHoursConverted > 0 ? `${Math.round(totalHoursConverted * 10) / 10}h` : "0h";
    }
  };

  const getParentEffortDisplay = (task, allTasks, hoursPerDay) => {
    const children = allTasks.filter((t) => t.parent_task_id === task.id);
    if (children.length === 0) {
      // For leaf tasks, use its own effort
      const days = task.effort_days || 0;
      const hours = task.effort_hours || 0;
      let display = "";
      if (days > 0) display += `${days}d`;
      if (hours > 0) display += ` ${hours}h`;
      return display.trim() || "0h";
    }

    let totalEffortDays = 0;
    let totalEffortHours = 0;
    children.forEach((child) => {
      totalEffortDays += child.effort_days || 0;
      totalEffortHours += child.effort_hours || 0;
    });

    // Normalize hours to days if hours >= hoursPerDay
    if (totalEffortHours >= hoursPerDay) {
      totalEffortDays += Math.floor(totalEffortHours / hoursPerDay);
      totalEffortHours = totalEffortHours % hoursPerDay;
    }

    if (totalEffortDays === 0 && totalEffortHours === 0) return "0h";

    let display = "";
    if (totalEffortDays > 0) display += `${Math.round(totalEffortDays * 10) / 10}d`;
    if (totalEffortHours > 0) display += ` ${Math.round(totalEffortHours * 10) / 10}h`;
    return display.trim() || "0h";
  };

  const getProjectName = (projectId) => {
    const project = projects.find((p) => p.id === projectId);
    return project?.name || "Unknown Project";
  };

  const generateTimelineHeaders = () => {
    const headers = [];
    const totalDays = differenceInDays(timelineRange.end, timelineRange.start);
    const daysPerColumn = viewMode === "daily" ? 1 : viewMode === "weekly" ? 7 : 30;

    for (let i = 0; i <= totalDays; i += daysPerColumn) {
      const date = addDays(timelineRange.start, i);
      headers.push(date);
    }

    return headers;
  };

  // Enhanced task dimensions calculation for hours
  const getTaskDimensions = (task) => {
    if (!task.start_date || !task.end_date) {
      return { left: '0%', width: '0%' };
    }

    const startDate = new Date(task.start_date);
    const endDate = new Date(task.end_date);
    const totalDaysInTimeline = differenceInDays(timelineRange.end, timelineRange.start);
    const taskStartOffsetDays = differenceInDays(startDate, timelineRange.start);

    // Calculate duration considering hours if available
    let taskDurationDays;
    const taskDurationInHours = (task.duration_days || 0) * hoursPerDay + (task.duration_hours || 0);

    if (taskDurationInHours > 0) {
      taskDurationDays = taskDurationInHours / hoursPerDay;
    } else {
      // Fallback for tasks without duration but with dates
      taskDurationDays = differenceInDays(endDate, startDate) + 1;
    }

    const left = Math.max(0, taskStartOffsetDays / totalDaysInTimeline * 100);
    const width = Math.min(100 - left, taskDurationDays / totalDaysInTimeline * 100);

    return { left: `${left}%`, width: `${width}%` };
  };

  const getStatusColor = (status, progress) => {
    switch (status) {
      case "completed":
        return "bg-green-500"; // This won't be used directly for the bar anymore, but can be for other indicators
      case "in_progress":
        return "bg-blue-500";
      case "blocked":
        return "bg-red-500";
      case "not_started":
        return "bg-gray-400";
      default:
        return "bg-gray-400";
    }
  };

  const hasResourceConflict = (task) => {
    if (!task.assigned_to) return false;
    const overlappingTasks = filteredTasks.filter((t) =>
      t.id !== task.id &&
      t.assigned_to === task.assigned_to &&
      t.status !== "completed" &&
      new Date(t.start_date) <= new Date(task.end_date) &&
      new Date(t.end_date) >= new Date(task.start_date)
    );
    return overlappingTasks.length > 0;
  };

  const toggleTaskExpansion = (taskId) => {
    onExpandedChange((prev) => {
      const newSet = new Set(prev);
      if (newSet.has(taskId)) {
        newSet.delete(taskId);
      } else {
        newSet.add(taskId);
      }
      return newSet;
    });
  };

  const handleCreateTaskAfter = (afterTask, asSubtask = true) => {
    setCreatingTaskAfter({ task: afterTask, asSubtask });
    setNewTaskTitle("");
  };

  const handleCreateNewTask = async () => {
    if (!newTaskTitle.trim()) return;

    const { task: afterTask, asSubtask } = creatingTaskAfter;

    if (asSubtask && !expandedTasks.has(afterTask.id)) {
      toggleTaskExpansion(afterTask.id);
    }

    const newTask = {
      title: newTaskTitle.trim(),
      project_id: afterTask.project_id,
      parent_task_id: afterTask.id,
      start_date: "",
      end_date: "",
      duration_days: 1,
      duration_hours: 0,
      status: "not_started",
      priority: 5,
      progress: 0,
      effort_days: 0,
      effort_hours: 0,
      is_ongoing: false
    };

    try {
      await onCreateTask(newTask);
      setCreatingTaskAfter(null);
      setNewTaskTitle("");

      // Force refresh the view after creating a subtask
      setTimeout(() => {
        console.log("Refreshing view after creating subtask");
        window.dispatchEvent(new CustomEvent("refreshTaskView", { detail: { preserveState: true, reason: "createSubtask" } }));
      }, 100);

    } catch (error) {
      console.error("Error creating task:", error);
      alert("Failed to create task. Please try again.");
    }
  };

  const handleCancelCreate = () => {
    setCreatingTaskAfter(null);
    setNewTaskTitle("");
  };

  const confirmAndDelete = (taskId) => {
    if (window.confirm("Are you sure you want to delete this task and all its subtasks?")) {
      onTaskDelete(taskId);
    }
  };

  // FIXED: Only toggle linking mode, don't affect indent mode at all
  const toggleLinkingMode = () => {
    const wasLinkingMode = linkingMode;
    setLinkingMode(!linkingMode);
    setSelectedTasksForLinking([]);

    // If we're exiting linking mode, refresh the view to show any changes
    if (wasLinkingMode) {
      setTimeout(() => {
        console.log("Refreshing view after exiting link mode");
        // Trigger a gentle refresh that preserves expanded state
        window.dispatchEvent(new CustomEvent("refreshTaskView", {
          detail: { preserveState: true, reason: "exitLinkMode" }
        }));
      }, 100);
    }
  };

  // FIXED: Only toggle indent mode, completely independent of linking
  const toggleIndentMode = () => {
    onToggleIndentMode(!indentMode);
    // force a full remount of the DnD tree
    setForceRenderKey(k => k + 1);
  };

  const handleTaskSelection = (task) => {
    if (!linkingMode) return;

    setSelectedTasksForLinking((prev) => {
      if (prev.find((t) => t.id === task.id)) {
        return prev.filter((t) => t.id !== task.id);
      } else {
        return [...prev, task];
      }
    });
  };

  // Helper function to find next available date considering hourly capacity
  const findNextAvailableDateWithHours = async (task, earliestStartDate, taskMap) => {
    if (!task.assigned_to || (!task.duration_days && !task.duration_hours)) {
      return earliestStartDate;
    }

    const resourceId = task.assigned_to;
    const taskTotalHours = (task.duration_days * hoursPerDay) + (task.duration_hours || 0);

    // Get all tasks for this resource (excluding the task being scheduled)
    const resourceTasks = Array.from(taskMap.values()).filter(t =>
      t.assigned_to === resourceId &&
      t.id !== task.id &&
      !t.is_ongoing &&
      !["completed", "cancelled"].includes(t.status) &&
      t.start_date && t.end_date
    );

    let currentDate = new Date(earliestStartDate);
    const maxSearchDays = 365; // Prevent infinite loops
    let searchDays = 0;

    while (searchDays < maxSearchDays) {
      // Ensure we're on a working day
      while (!isWorkingDay(currentDate)) {
        currentDate = addDays(currentDate, 1);
        searchDays++;
        if (searchDays >= maxSearchDays) return currentDate;
      }

      // Calculate total hours already allocated for this resource on this date
      let hoursAllocatedOnDate = 0;

      for (const existingTask of resourceTasks) {
        const existingStart = new Date(existingTask.start_date);
        const existingEnd = new Date(existingTask.end_date);

        // Check if this existing task overlaps with currentDate
        // To accurately check daily allocation, consider the full span of the task and its total hours
        if (currentDate >= existingStart && currentDate <= existingEnd) {
          const existingTaskTotalHours = (existingTask.duration_days * hoursPerDay) + (existingTask.duration_hours || 0);
          const existingTaskDurationInWorkDays = Math.max(1, differenceInDays(existingEnd, existingStart) + 1); // Simple daily spread
          const dailyHoursForExistingTask = existingTaskTotalHours / existingTaskDurationInWorkDays;
          hoursAllocatedOnDate += dailyHoursForExistingTask;
        }
      }

      // Calculate daily hours for the new task
      const newTaskDurationInWorkDays = Math.max(1, Math.ceil(taskTotalHours / hoursPerDay));
      const dailyHoursForNewTask = taskTotalHours / newTaskDurationInWorkDays;

      // Check if there's capacity for the new task
      if (hoursAllocatedOnDate + dailyHoursForNewTask <= hoursPerDay) {
        return currentDate; // Found available slot
      }

      // Move to next day
      currentDate = addDays(currentDate, 1);
      searchDays++;
    }

    console.warn(`Could not find available slot for task ${task.title} within ${maxSearchDays} days`);
    return earliestStartDate; // Fallback to earliest date
  };

  const createTaskLinks = async () => {
    if (selectedTasksForLinking.length < 2) {
      alert("Please select at least 2 tasks to create a dependency chain.");
      return;
    }

    try {
      const taskMap = new Map(tasks.map((task) => [task.id, { ...task }]));

      for (let i = 0; i < selectedTasksForLinking.length - 1; i++) {
        const predecessor = selectedTasksForLinking[i];
        const successor = selectedTasksForLinking[i + 1];

        const currentPred = taskMap.get(predecessor.id);
        const currentSucc = taskMap.get(successor.id);

        if (!currentPred || !currentSucc) {
          console.warn(`Task ${predecessor.id} or ${successor.id} not found in map.`);
          continue;
        }

        if (hasCircularDependency(currentSucc.id, currentPred.id)) {
          alert(`Cannot link ${currentSucc.title} → ${currentPred.title}: would create circular dependency`);
          continue;
        }

        // Update predecessor's successor links, ensure uniqueness
        const newPredSuccessorLinks = [...(currentPred.successor_links || [])];
        if (!newPredSuccessorLinks.includes(currentSucc.id)) {
          newPredSuccessorLinks.push(currentSucc.id);
        }
        taskMap.set(currentPred.id, { ...currentPred, successor_links: newPredSuccessorLinks });

        // Update successor's predecessor links, ensure uniqueness
        const newSuccPredecessorLinks = [...(currentSucc.predecessor_links || [])];
        if (!newSuccPredecessorLinks.includes(currentPred.id)) {
          newSuccPredecessorLinks.push(currentPred.id);
        }
        let updatedSuccessor = { ...currentSucc, predecessor_links: newSuccPredecessorLinks };

        // Calculate next available start date considering hourly capacity
        const predEndDate = currentPred.actual_end_date || currentPred.end_date;
        if (predEndDate && updatedSuccessor.assigned_to) {
          const predEndDateObj = new Date(predEndDate);
          const nextAvailableDate = await findNextAvailableDateWithHours(
            updatedSuccessor,
            predEndDateObj, // Changed to not add 1 day here; findNextAvailableDateWithHours will handle advancing to the next working day if current day is full.
            taskMap
          );

          if (nextAvailableDate) {
            updatedSuccessor.start_date = format(nextAvailableDate, "yyyy-MM-dd");

            // Recalculate end date based on duration
            const hasChildren = tasks.some((t) => t.parent_task_id === updatedSuccessor.id);
            if ((updatedSuccessor.duration_days > 0 || updatedSuccessor.duration_hours > 0) && !hasChildren) {
              const totalDurationHours = (updatedSuccessor.duration_days * hoursPerDay) + (updatedSuccessor.duration_hours || 0);
              const endDateObj = addWorkingHours(nextAvailableDate, totalDurationHours);
              const finalEndDate = addHours(endDateObj, -0.01); // Keep it on the same day if needed, as per outline
              updatedSuccessor.end_date = format(finalEndDate, "yyyy-MM-dd");
            }
          }
        }

        taskMap.set(updatedSuccessor.id, updatedSuccessor);
      }

      const updatesToSend = [];
      for (const taskId of selectedTasksForLinking.map((t) => t.id)) {
        const updatedTask = taskMap.get(taskId);
        const originalTask = tasks.find((t) => t.id === taskId);

        if (updatedTask && originalTask && JSON.stringify(updatedTask) !== JSON.stringify(originalTask)) {
          updatesToSend.push({ id: updatedTask.id, data: updatedTask });
        }
      }

      if (updatesToSend.length > 0) {
        await onBulkTaskUpdate(updatesToSend);
      }

      setLinkingMode(false);
      setSelectedTasksForLinking([]);

      // FIXED: Use the new refresh event that preserves state
      setTimeout(() => {
        console.log("Refreshing view after creating task links");
        window.dispatchEvent(new CustomEvent("refreshTaskView", {
          detail: {
            preserveState: true,
            reason: "tasksLinked",
            linkedTasks: selectedTasksForLinking.map(t => t.id)
          }
        }));
      }, 200);

    } catch (error) {
      console.error("Error creating task links:", error);
      alert("Failed to create task links. Please try again.");
    }
  };

  const unlinkSelectedTasks = async () => {
    if (selectedTasksForLinking.length < 2) {
      alert("Please select at least 2 tasks to unlink dependencies between them.");
      return;
    }

    const selectedIds = new Set(selectedTasksForLinking.map((t) => t.id));
    const updatesToPerform = new Map();

    for (const task of selectedTasksForLinking) {
      let linksChanged = false;

      const currentPreds = task.predecessor_links || [];
      const currentSuccs = task.successor_links || [];

      const newPreds = currentPreds.filter((id) => !selectedIds.has(id));
      const newSuccs = currentSuccs.filter((id) => !selectedIds.has(id));

      if (newPreds.length !== currentPreds.length || newSuccs.length !== currentSuccs.length) {
        linksChanged = true;
      }

      if (linksChanged) {
        updatesToPerform.set(task.id, {
          ...(updatesToPerform.get(task.id) || {}),
          predecessor_links: newPreds,
          successor_links: newSuccs
        });
      }
    }

    if (updatesToPerform.size > 0) {
      const updatesArray = Array.from(updatesToPerform.entries()).map(([id, data]) => ({ id, data }));
      await onBulkTaskUpdate(updatesArray);
      alert(`${updatesToPerform.size} tasks had dependencies removed successfully.`);
      toggleLinkingMode();
    } else {
      alert("No direct dependencies found between the selected tasks.");
    }
  };

  const hasCircularDependency = (taskId, potentialPredecessorId, visited = new Set()) => {
    if (visited.has(taskId)) return true;
    if (taskId === potentialPredecessorId) return true;

    visited.add(taskId);
    const task = tasks.find((t) => t.id === taskId);
    if (!task || !task.predecessor_links) return false;

    for (const predId of task.predecessor_links) {
      if (hasCircularDependency(predId, potentialPredecessorId, new Set(visited))) {
        return true;
      }
    }

    return false;
  };

  const handleIndentTask = async (task) => {
    if (onTaskIndent) {
      onTaskIndent(task);
    }
  };

  const handleOutdentTask = async (task) => {
    if (onTaskOutdent) {
      onTaskOutdent(task);
    }
  };

  const handleInlineEdit = (taskId, field) => {
    setEditingField({ taskId, field });
  };

  const handleInlineSave = async (updatedTask) => {
    try {
      if (typeof updatedTask.title === 'object') {
        console.error("Invalid title update detected. Aborting save.", updatedTask.title);
        setEditingField(null);
        return;
      }

      // Call the main update handler from the Dashboard
      await onTaskUpdate(updatedTask);
      setEditingField(null); // Close the editor on successful save
    } catch (error) {
      console.error("Error updating task from inline editor:", error);
      setEditingField(null); // Close editor even on error
    }
  };

  const handleInlineCancel = () => {
    setEditingField(null);
  };

  const getTitleWidth = () => {
    const baseWidth = 200;
    const extraWidth = Math.max(0, taskListWidth - 800);
    return baseWidth + extraWidth * 0.6;
  };

  const getVisibleFields = () => {
    const titleWidth = getTitleWidth();
    const remainingWidth = taskListWidth - titleWidth - 80;

    const fields = ['task'];
    let usedWidth = 0;

    const fieldWidths = {
      start: 85,
      end: 85,
      days: 55,
      effort: 55, // Added effort field width
      priority: 45,
      assigned: 100
    };

    const fieldOrder = ['start', 'end', 'days', 'effort', 'priority', 'assigned']; // Added effort to field order

    for (const field of fieldOrder) {
      if (usedWidth + fieldWidths[field] <= remainingWidth) {
        fields.push(field);
        usedWidth += fieldWidths[field];
      }
    }

    fields.push('actions');
    return fields;
  };

  // Calculate dependency badge numbers for tasks within a project
  const calculateDependencyBadges = (projectTasks) => {
    const badges = new Map();
    const inDegree = new Map();
    const successorsMap = new Map();
    const queue = [];

    // Build successor map and initialize in-degrees
    projectTasks.forEach(task => {
      successorsMap.set(task.id, []);
      inDegree.set(task.id, 0);
    });

    projectTasks.forEach(task => {
      if (task.predecessor_links) {
        task.predecessor_links.forEach(predId => {
          if (successorsMap.has(predId)) {
            successorsMap.get(predId).push(task.id);
            inDegree.set(task.id, (inDegree.get(task.id) || 0) + 1);
          }
        });
      }
    });

    // Identify root tasks for chains (no predecessors but at least one successor)
    projectTasks.forEach(task => {
      if (inDegree.get(task.id) === 0 && successorsMap.get(task.id)?.length > 0) {
        queue.push(task.id);
        badges.set(task.id, 1); // Root tasks start with badge 1
      }
    });

    // Process tasks in topological order
    let head = 0;
    while (head < queue.length) {
      const u = queue[head++];
      const uBadge = badges.get(u) || 1;

      const successors = successorsMap.get(u) || [];
      for (const vId of successors) {
        const vTask = projectTasks.find(t => t.id === vId);
        if (vTask) {
          inDegree.set(vId, inDegree.get(vId) - 1);
          badges.set(vId, uBadge + 1);
          if (inDegree.get(vId) === 0) {
            queue.push(vId);
          }
        }
      }
    }
    return badges;
  };

  // Memoize the badge number calculation for efficiency
  const taskBadgeNumbers = useMemo(() => {
    // Only calculate if tasks or selectedProject changes
    const relevantTasks = selectedProject
      ? tasks.filter(t => t.project_id === selectedProject)
      : tasks;
    return calculateDependencyBadges(relevantTasks);
  }, [tasks, selectedProject]);

  // Get badge number for a task
  const getTaskBadgeNumber = (task) => {
    return taskBadgeNumbers.get(task.id);
  };

  // Handle badge click to highlight linked task
  const handleBadgeClick = (task, badgeNumber) => {
    const projectTasks = selectedProject
      ? tasks.filter(t => t.project_id === selectedProject)
      : tasks.filter(t => t.project_id === task.project_id);

    const badges = taskBadgeNumbers; // Use the memoized map

    let targetTaskId = null;

    // Try to find a direct predecessor with badgeNumber - 1
    if (task.predecessor_links) {
      for (const predId of task.predecessor_links) {
        if (badges.has(predId) && badges.get(predId) === badgeNumber - 1) {
          targetTaskId = predId;
          break;
        }
      }
    }

    // If no direct predecessor found with badgeNumber - 1, try a direct successor with badgeNumber + 1
    if (!targetTaskId && task.successor_links) {
      for (const succId of task.successor_links) {
        if (badges.has(succId) && badges.get(succId) === badgeNumber + 1) {
          targetTaskId = succId;
          break;
        }
      }
    }

    // Fallback: If still no target, try finding any linked task (predecessor or successor)
    // with a "related" badge number (badgeNumber-1 or badgeNumber+1)
    if (!targetTaskId) {
      // Find a direct predecessor
      if (task.predecessor_links && task.predecessor_links.length > 0) {
        targetTaskId = task.predecessor_links[0]; // Pick the first one as a general highlight
      } else {
        // Find a direct successor
        const directSuccessors = projectTasks.filter(t => (t.predecessor_links || []).includes(task.id));
        if (directSuccessors.length > 0) {
          targetTaskId = directSuccessors[0].id; // Pick the first one
        }
      }
    }

    if (targetTaskId) {
      setHighlightedTask(targetTaskId);
      // Clear highlight after 500ms
      setTimeout(() => setHighlightedTask(null), 500);
    }
  };


  const renderEditableField = (task, field, displayValue, className = "") => {
    const hasSubTasks = getSubTasks(task.id, tasks).length > 0;
    // Check if the editing field is either the current field OR the special 'duration_mixed' or 'estimated_effort_mixed' case
    const isEditing = editingField?.taskId === task.id &&
      (editingField.field === field ||
        (field === 'duration_combined' && editingField.field === 'duration_mixed') ||
        (field === 'estimated_effort_combined' && editingField.field === 'estimated_effort_mixed') ||
        (field === 'assigned_to' && editingField.field === 'assigned_to')
      );

    // Duration fields are disabled for parent tasks (those with subtasks)
    const isDurationDisabled = (field === 'duration_days' || field === 'duration_hours' || field === 'duration_mixed') && hasSubTasks;
    const isEffortDisabled = (field === 'estimated_effort_combined' || field === 'estimated_effort_mixed') && hasSubTasks;
    const isDateDisabled = (field === 'end_date' || field === 'start_date') && hasSubTasks;
    const isResourceSelectedForCheck = isConflictCheckMode && field === 'assigned_to' && selectedResourcesForCheck.has(task.assigned_to);

    // Special handling for assigned_to using the new AssignedCell component
    if (field === 'assigned_to') {
      return (
        <AssignedCell
          task={task}
          isEditing={isEditing}
          onEdit={() => handleInlineEdit(task.id, 'assigned_to')}
          onSave={(value) => {
            // AssignedCell's onSave sends the value directly, so pass it to handleCellEdit
            handleCellEdit(task.id, 'assigned_to', value);
            setEditingField(null); // Close the editor after save
          }}
          onCancel={handleInlineCancel}
          resources={resources} // Pass resources to AssignedCell
          isConflictCheckMode={isConflictCheckMode} // Pass for conflict check
          onSelectResourceForCheck={onSelectResourceForCheck} // Pass for conflict check
          isSelectedForCheck={isResourceSelectedForCheck} // Pass for styling
          linkingMode={linkingMode} // Pass linkingMode to disable interaction
          customLog={customLog} // Pass customLog for internal debugging
        />
      );
    }

    // Check if we should show the inline editor for other fields
    if (isEditing && !linkingMode && !isDurationDisabled && !isDateDisabled && !isEffortDisabled) {
      return (
        <InlineTaskEditor
          task={task}
          field={editingField.field} // Pass the ACTUAL field from the state, which is 'duration_mixed' or 'estimated_effort_mixed'
          onSave={handleInlineSave}
          onCancel={handleInlineCancel}
          resources={resources}
          projects={projects}
          durationUnit={durationDisplayUnit}
          hoursPerDay={hoursPerDay}
        />
      );
    }

    const priorityColors = {
      1: "bg-red-100 text-red-800 border-red-200",
      2: "bg-red-100 text-red-800 border-red-200",
      3: "bg-orange-100 text-orange-800 border-orange-200",
      4: "bg-orange-100 text-orange-800 border-orange-200",
      5: "bg-yellow-100 text-yellow-800 border-yellow-200",
      6: "bg-yellow-100 text-yellow-800 border-yellow-200",
      7: "bg-green-100 text-green-800 border-green-200",
      8: "bg-green-100 text-green-800 border-green-200",
      9: "bg-blue-100 text-blue-800 border-blue-200",
      10: "bg-blue-100 text-blue-800 border-blue-200"
    };

    if (field === 'priority') {
      return (
        <Badge
          className={`${priorityColors[displayValue] || 'bg-gray-100'} text-xs px-1.5 py-0.5 ${linkingMode ? 'cursor-not-allowed opacity-70' : 'cursor-pointer hover:ring-1 hover:ring-indigo-300'}`}
          onClick={() => !linkingMode && handleInlineEdit(task.id, field)}>

          P{displayValue}
        </Badge>
      );
    }

    const getTooltipText = () => {
      if (field === 'title') return task.title;
      if (isDurationDisabled) return "Duration calculated from subtasks - edit individual subtasks instead";
      if (isEffortDisabled) return "Effort is calculated from subtasks";
      if (isDateDisabled) return "Dates calculated from subtasks";
      return `Click to edit ${field}`;
    };

    const displayContent = () => {
      if (field === 'duration_combined') {
        if (hasSubTasks) {
          return (
            <span
              className={`px-1 py-0.5 rounded text-xs font-medium ${className} text-green-600 cursor-not-allowed`}
              title="Parent task duration (sum of children) - edit individual subtasks to change this"
            >
              {getParentDurationDisplay(task, tasks, durationDisplayUnit)}
            </span>
          );
        } else {
          const days = task.duration_days || 0;
          const hours = task.duration_hours || 0;
          let display = "";

          if (durationDisplayUnit === 'days') {
            // Show days and hours separately for leaf tasks
            if (days > 0) display += `${days}d`;
            if (hours > 0) display += ` ${hours}h`;
            display = display.trim() || "0d";
          } else {
            const totalHours = (days * hoursPerDay) + hours;
            display = totalHours > 0 ? `${Math.round(totalHours * 10) / 10}h` : "0h";
          }

          return (
            <span
              className={`cursor-pointer hover:bg-slate-100 px-1 py-0.5 rounded text-xs ${className} ${linkingMode || isDurationDisabled ? 'text-gray-400 cursor-not-allowed opacity-70' : ''}`}
              onClick={(e) => {
                e.stopPropagation();
                if (!linkingMode && !isDurationDisabled) {
                  // Correctly set the editing state to 'duration_mixed'
                  handleInlineEdit(task.id, 'duration_mixed');
                }
              }}
              title="Click to edit duration (format: 4h or 2d)"
            >
              {display}
            </span>
          );
        }
      }

      if (field === 'estimated_effort_combined') {
        if (hasSubTasks) { // Parent task effort is calculated from children
          return (
            <span
              className={`px-1 py-0.5 rounded text-xs font-medium ${className} text-gray-500 cursor-not-allowed`}
              title="Parent task effort (sum of children) - edit individual subtasks to change this"
            >
              {getParentEffortDisplay(task, tasks, hoursPerDay)}
            </span>
          );
        } else { // Leaf task effort is editable
          const days = task.effort_days || 0;
          const hours = task.effort_hours || 0;
          let display = "";
          if (days > 0) display += `${days}d`;
          if (hours > 0) display += ` ${hours}h`;
          display = display.trim() || "0h";

          return (
            <span
              className={`cursor-pointer hover:bg-slate-100 px-1 py-0.5 rounded text-xs ${className} ${linkingMode || isEffortDisabled ? 'text-gray-400 cursor-not-allowed opacity-70' : ''}`}
              onClick={(e) => {
                e.stopPropagation();
                if (!linkingMode && !isEffortDisabled) {
                  handleInlineEdit(task.id, 'estimated_effort_mixed');
                }
              }}
              title="Click to edit effort (format: 4h or 2d)"
            >
              {display}
            </span>
          );
        }
      }

      // This is the generic display for non-editing mode, for fields NOT handled by AssignedCell
      return (
        <span
          className={`cursor-pointer hover:bg-slate-100 px-1 py-0.5 rounded text-xs ${className} ${linkingMode || isDurationDisabled || isDateDisabled || isEffortDisabled ? 'text-gray-400 cursor-not-allowed opacity-70' : ''}`}
          onClick={(e) => {
            e.stopPropagation();
            if (!linkingMode && !isDurationDisabled && !isDateDisabled && !isEffortDisabled) {
              handleInlineEdit(task.id, field);
            }
          }}
          title={getTooltipText()}>

          {displayValue || "—"}
        </span>
      );
    };

    return displayContent();
  };

  const visibleFields = getVisibleFields();
  const titleWidth = getTitleWidth();

  const isDescendant = (taskId, potentialAncestorId) => {
    const task = tasks.find((t) => t.id === taskId);
    if (!task || !task.parent_task_id) return false;
    if (task.parent_task_id === potentialAncestorId) return true;
    return isDescendant(task.parent_task_id, potentialAncestorId);
  };

  const handleDragStart = (start) => {
    setDragOverTarget(null);
  };

  const handleDragUpdate = (update) => {
    if (!indentMode || !update.destination) {
      setDragOverTarget(null);
      return;
    }

    const { destination, draggableId } = update;
    const draggedTask = tasks.find((t) => t.id === draggableId);

    if (!draggedTask) {
      setDragOverTarget(null);
      return;
    }

    if (destination.droppableId === 'root') {
      setDragOverTarget({ type: 'unindent', targetId: 'root' });
    } else {
      const targetTask = tasks.find((t) => t.id === destination.droppableId);

      if (targetTask && targetTask.id !== draggableId) {
        if (!isDescendant(targetTask.id, draggedTask.id)) {
          setDragOverTarget({ type: 'indent', targetId: targetTask.id });
        } else {
          setDragOverTarget(null);
        }
      } else {
        setDragOverTarget(null);
      }
    }
  };

  const handleDragEnd = async (result) => {
    setDragOverTarget(null);

    if (!result.destination) {
      return;
    }

    if (indentMode) {
      const { draggableId, destination } = result;
      const newParentId = destination.droppableId === 'root' ? null : destination.droppableId;
      await onTaskReparent(draggableId, newParentId);

      // Trigger parent recalculation after drag-and-drop reparenting in indent mode
      // This ensures that when you exit indent mode, all parent durations are correctly calculated
      setTimeout(() => {
        // Small delay to ensure the reparenting has completed
        window.dispatchEvent(new CustomEvent("refreshTaskView", { detail: { preserveState: true, reason: "recalculateParents" } }));
      }, 100);
    } else {
      onTaskReorder(result);
    }
  };

  const renderTaskRow = (task, level, index) => {
    const subTasksForThis = getSubTasks(task.id, tasks).length;
    const hasSubTasks = subTasksForThis > 0;
    const isExpanded = expandedTasks.has(task.id);
    const isSelectedForLinking = selectedTasksForLinking.find((t) => t.id === task.id);
    const isDragTarget = indentMode && dragOverTarget?.targetId === task.id && dragOverTarget?.type === 'indent';
    const isHighlighted = highlightedTask === task.id;
    const badgeNumber = getTaskBadgeNumber(task);
    const isCompleted = task.status === 'completed'; // Added for task completion status

    return (
      <Draggable key={task.id} draggableId={task.id} index={index} isDragDisabled={linkingMode}>
        {(provided, snapshot) => (
          <div ref={provided.innerRef} {...provided.draggableProps} {...provided.dragHandleProps}>
            <div
              className={`flex items-center border-b border-slate-100 hover:bg-slate-50 transition-colors duration-150 group relative ${
                isSelectedForLinking ? 'bg-blue-100 border-blue-300' : ''
              } ${
                linkingMode ? 'cursor-pointer' : ''
              } ${
                isDragTarget ? 'bg-green-100 border-green-300' : ''
              } ${
                snapshot.isDragging && indentMode ? 'shadow-lg bg-white opacity-90' : ''
              } ${
                isHighlighted ? 'bg-yellow-100 border-yellow-400 animate-pulse' : ''
              }`}
              style={{
                height: `${COMPACT_ROW_HEIGHT}px`,
                paddingLeft: `${8 + level * 16}px`,
                paddingRight: '8px'
              }}
              onClick={() => linkingMode && handleTaskSelection(task)}
            >
              <div className="flex items-center flex-1 min-w-0">
                <div className="flex items-center gap-1 mr-2 flex-shrink-0">
                  {hasSubTasks && (
                    <Button
                      variant="ghost"
                      size="icon"
                      className="w-5 h-5 p-0"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleTaskExpansion(task.id);
                      }}
                    >
                      {isExpanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
                    </Button>
                  )}
                  {(!linkingMode || indentMode) && (
                    <GripVertical className="w-3 h-3 text-gray-400" />
                  )}
                </div>

                <div className={`font-medium text-slate-900 truncate text-sm leading-tight ${isCompleted ? "line-through text-slate-500" : ""}`} title={task.title}>
                  {renderEditableField(task, 'title', task.title)}
                </div>
                {updatingTasks.has(task.id) && <Loader2 className="w-4 h-4 animate-spin text-blue-500 ml-2" />}

                <div className="flex items-center gap-1 ml-2 flex-shrink-0">
                  {task.is_ongoing && (
                    <Badge variant="outline" className="text-xs px-1 py-0 bg-purple-50 text-purple-700 border-purple-200">
                      Ongoing
                    </Badge>
                  )}
                  {selectedProject === null && task.project_id && (
                    <Badge variant="outline" className="text-xs px-1 py-0 bg-blue-50 text-blue-700 border-blue-200">
                      {getProjectName(task.project_id)}
                    </Badge>
                  )}
                </div>
              </div>

              {/* New Dependency Badge Position */}
              <div className="flex items-center justify-center" style={{ minWidth: '30px' }}>
                {badgeNumber && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleBadgeClick(task, badgeNumber);
                    }}
                    className="w-5 h-5 bg-indigo-600 text-white text-xs font-medium rounded-full flex items-center justify-center hover:bg-indigo-700 transition-colors shadow-sm"
                    title={`Linked position: ${badgeNumber}. Click to highlight linked task.`}
                    aria-label={`Dependency link position ${badgeNumber}`}
                  >
                    {badgeNumber}
                  </button>
                )}
              </div>

              <div className="flex items-center gap-3 text-xs flex-shrink-0">
                {visibleFields.includes('start') &&
                  <div className="flex items-center gap-1" style={{ minWidth: '85px' }}>
                    <span className="text-slate-500">Start:</span>
                    {renderEditableField(task, 'start_date',
                      task.start_date ? format(new Date(task.start_date), "MMM d") : "—", "text-slate-700"
                    )}
                  </div>
                }

                {visibleFields.includes('end') &&
                  <div className="flex items-center gap-1" style={{ minWidth: '85px' }}>
                    <span className="text-slate-500">End:</span>
                    {renderEditableField(task, 'end_date',
                      task.end_date ? format(new Date(task.end_date), "MMM d") : "—", "text-slate-700"
                    )}
                  </div>
                }

                {visibleFields.includes('days') &&
                  <div className="flex items-center gap-1" style={{ minWidth: '55px' }}>
                    {renderEditableField(task, 'duration_combined', null, "text-slate-700")}
                  </div>
                }

                {visibleFields.includes('effort') &&
                  <div className="flex items-center gap-1" style={{ minWidth: '55px' }}>
                    {renderEditableField(task, 'estimated_effort_combined', null, "text-slate-700")}
                  </div>
                }

                {visibleFields.includes('priority') &&
                  <div style={{ minWidth: '45px' }}>
                    {renderEditableField(task, 'priority', task.priority || 5)}
                  </div>
                }

                {visibleFields.includes('assigned') &&
                  <div
                    className="truncate flex items-center gap-1" // Added gap-1 for spacing between cell content and search icon
                    style={{ minWidth: '100px' }}
                  >
                    {renderEditableField(task, 'assigned_to',
                      resources.find((r) => r.id === task.assigned_to)?.name || "Unassigned",
                      "text-slate-700 truncate"
                    )}
                    {task.assigned_to && !linkingMode && !indentMode &&
                      <Popover open={slotFinderState.open && slotFinderState.taskId === task.id} onOpenChange={(open) => setSlotFinderState({ ...slotFinderState, open, taskId: open ? task.id : null })}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="w-5 h-5 rounded-full"
                            onClick={async (e) => {
                              e.stopPropagation();
                              setSlotFinderState({ open: true, taskId: task.id, slots: [], isLoading: true });
                              const results = await onFindNextAvailableSlot(task);
                              if (results) {
                                setSlotFinderState({ open: true, taskId: task.id, slots: [results], isLoading: false });
                              } else {
                                setSlotFinderState({ open: true, taskId: task.id, slots: [], isLoading: false });
                              }
                            }}>

                            <Search className="w-3 h-3 text-slate-500" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-64 p-2">
                          <div className="font-semibold text-sm mb-2">Next Available Slot</div>
                          {slotFinderState.isLoading ?
                            <div className="text-sm text-slate-500">Searching...</div> :
                            slotFinderState.slots && slotFinderState.slots.length > 0 ?
                              <div className="space-y-2">
                                {slotFinderState.slots.map((slot) =>
                                  <div key={slot} className="flex items-center justify-between text-xs">
                                    <span>{format(new Date(slot), 'MMM d, yyyy')}</span>
                                    <Button size="sm" onClick={(e) => {
                                      e.stopPropagation();
                                      onApplySuggestion(task, format(new Date(slot), 'yyyy-MM-dd'));
                                      setSlotFinderState({ open: false, taskId: null, slots: [], isLoading: false });
                                    }}>Apply</Button>
                                  </div>
                                )}
                              </div> :

                              <div className="text-sm text-slate-500">No available slots found.</div>
                          }
                        </PopoverContent>
                      </Popover>
                    }
                  </div>
                }

                {visibleFields.includes('actions') &&
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="w-6 h-6 opacity-0 group-hover:opacity-100">
                        <MoreVertical className="w-3 h-3" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => onTaskClick(task)}>
                        <Edit className="w-3 h-3 mr-2" />
                        Edit Task
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => handleCreateTaskAfter(task, true)}>
                        <Plus className="w-3 h-3 mr-2" />
                        Add Subtask
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => onTaskDuplicate(task.id)}>
                        <Copy className="w-3 h-3 mr-2" />
                        Duplicate
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => onTaskIndent(task)} disabled={linkingMode || indentMode}>
                        <Indent className="w-3 h-3 mr-2" />
                        Indent
                      </DropdownMenuItem>
                      {task.parent_task_id &&
                        <DropdownMenuItem onClick={() => onTaskOutdent(task)} disabled={linkingMode || indentMode}>
                          <Outdent className="w-3 h-3 mr-2" />
                          Outdent
                        </DropdownMenuItem>
                      }
                      {(task.predecessor_links?.length > 0 || task.successor_links?.length > 0) &&
                        <DropdownMenuItem onClick={() => onTaskUnlinkAll(task)} disabled={linkingMode || indentMode}>
                          <Unlink className="w-3 h-3 mr-2" />
                          Unlink All Dependencies
                        </DropdownMenuItem>
                      }
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => confirmAndDelete(task.id)}
                        className="text-red-600 focus:text-red-600"
                        disabled={linkingMode || indentMode}
                      >
                        <Trash className="w-3 h-3 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                }
              </div>

              {isSelectedForLinking &&
                <div className="absolute right-2 top-1">
                  <Badge className="bg-blue-600 text-white text-xs h-4 w-4 flex items-center justify-center p-0">
                    {selectedTasksForLinking.findIndex((t) => t.id === task.id) + 1}
                  </Badge>
                </div>
              }
            </div>

            {creatingTaskAfter?.task.id === task.id && creatingTaskAfter.asSubtask &&
              <div
                className="flex items-center border-b border-slate-100 bg-slate-50"
                style={{
                  height: `${COMPACT_ROW_HEIGHT}px`,
                  paddingLeft: `${8 + (level + 1) * 16}px`,
                  paddingRight: '8px'
                }}
              >
                <Input
                  value={newTaskTitle}
                  onChange={(e) => setNewTaskTitle(e.target.value)}
                  placeholder="New subtask title..."
                  className="text-sm h-6 mr-2"
                  autoFocus
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      handleCreateNewTask();
                    }
                    if (e.key === "Escape") handleCancelCreate();
                  }}
                />
                <div className="flex gap-1">
                  <Button size="sm" className="h-6 px-2 text-xs" onClick={handleCreateNewTask} disabled={!newTaskTitle.trim()}>
                    Add
                  </Button>
                  <Button size="sm" variant="outline" className="h-6 px-2 text-xs" onClick={handleCancelCreate}>
                    Cancel
                  </Button>
                </div>
              </div>
            }

            {!indentMode && isExpanded && hasSubTasks &&
              <Droppable droppableId={task.id} type="task">
                {(provided) =>
                  <div {...provided.droppableProps} ref={provided.innerRef}>
                    {getSubTasks(task.id, tasks).map((subTask, subIndex) => renderTaskRow(subTask, level + 1, subIndex))}
                    {provided.placeholder}
                  </div>
                }
              </Droppable>
            }
          </div>
        )}
      </Draggable>
    );
  };

  function renderSubTasksForIndentMode(task, level, index) {
    const subTasks = getSubTasks(task.id, tasks);
    return (
      <Droppable key={task.id} droppableId={task.id} type="task">
        {(provided, snapshot) =>
          <div {...provided.droppableProps} ref={provided.innerRef}>
            {renderTaskRow(task, level, index)}
            {provided.placeholder}
            {expandedTasks.has(task.id) && subTasks.map((subTask, subIndex) =>
              renderSubTasksForIndentMode(subTask, level + 1, subIndex)
            )}
          </div>
        }
      </Droppable>);

  }

  const renderTimelineRow = (task, level) => {
    const subTasksForThis = getSubTasks(task.id, tasks).length;
    const hasSubTasks = subTasksForThis > 0;
    const isExpanded = expandedTasks.has(task.id);
    const isUpdating = updatingTasks.has(task.id);
    const isHighlighted = highlightedTask === task.id;
    const isCompleted = task.status === 'completed'; // Added for task completion status

    return (
      <div key={`timeline-${task.id}`}>
        <div
          className={`relative border-b border-slate-100 ${isHighlighted ? 'bg-yellow-100 animate-pulse' : ''}`}
          style={{ height: COMPACT_ROW_HEIGHT }}
        >
          {task.start_date && task.end_date && (
            <div
              ref={(el) => timelineBarRefs.current[task.id] = el}
              className={`absolute top-1/2 -translate-y-1/2 h-4 rounded
                ${isUpdating ? 'animate-pulse ring-2 ring-blue-300' : 'opacity-90'}
                flex items-center px-1
                ${linkingMode || indentMode ? 'cursor-default' : 'cursor-pointer hover:opacity-100'}
                transition-all duration-200 shadow-sm
                ${isHighlighted ? 'ring-2 ring-yellow-400' : ''}
                ${isCompleted ? 'bg-green-200 border border-green-400' : 'bg-blue-200 border border-blue-400'}
                hover:ring-2 hover:ring-offset-2 hover:ring-blue-500`
              }
              style={{ ...getTaskDimensions(task) }}
              onClick={() => !linkingMode && !indentMode && onTaskClick(task)}
            >
              {/* Progress overlay */}
              <div className={`absolute top-0 left-0 h-full rounded-l
                ${isCompleted ? 'bg-green-400' : 'bg-blue-400'}`}
                style={{ width: `${isCompleted ? 100 : task.progress || 0}%` }} />

              {/* Task Title */}
              <span className={`relative truncate px-2 text-sm font-medium
                ${isCompleted ? 'line-through text-green-800' : 'text-blue-800'}`}>
                {task.title}
              </span>
            </div>
          )}
        </div>
        {creatingTaskAfter?.task.id === task.id && creatingTaskAfter.asSubtask &&
          <div className="relative border-b border-slate-100 bg-slate-50/50" style={{ height: COMPACT_ROW_HEIGHT }}></div>
        }
        {isExpanded && hasSubTasks &&
          <div>
            {getSubTasks(task.id, tasks).map((subTask) => renderTimelineRow(subTask, level + 1))}
          </div>
        }
      </div>
    );
  };

  const handleQuickTaskCreate = () => {
    setShowQuickTaskForm(true);
  };

  const handleQuickTaskSubmit = (taskData) => {
    onCreateTask(taskData);
    setShowQuickTaskForm(false);
  };

  const handleQuickTaskCancel = () => {
    setShowQuickTaskForm(false);
  };

  const topLevelTasks = filteredTasks.
    filter((task) => !task.parent_task_id).
    sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

  const timelineHeaders = generateTimelineHeaders();

  const renderHeaderFields = () => {
    return (
      <div className="flex items-center gap-3 flex-shrink-0">
        {visibleFields.includes('start') && <div style={{ minWidth: '85px' }}>Start</div>}
        {visibleFields.includes('end') && <div style={{ minWidth: '85px' }}>End</div>}
        {visibleFields.includes('days') &&
          <div
            style={{ minWidth: '55px' }}
            className="cursor-pointer hover:text-indigo-600"
            onClick={() => setDurationDisplayUnit((prev) => prev === 'days' ? 'hours' : 'days')}
            title={`Switch to edit in ${durationDisplayUnit === 'days' ? 'hours' : 'days'}`}>

            {durationDisplayUnit === 'days' ? 'Duration (d)' : 'Duration (h)'}
          </div>
        }
        {visibleFields.includes('effort') && <div style={{ minWidth: '55px' }}>Effort</div>}
        {visibleFields.includes('priority') && <div style={{ minWidth: '45px' }}>Priority</div>}
        {visibleFields.includes('assigned') && <div style={{ minWidth: '100px' }}>Assigned</div>}
        {visibleFields.includes('actions') && <div className="w-6"></div>}
      </div>);

  };

  return (
    <div key={forceRenderKey} className="flex flex-col h-full min-h-0"> {/* Key added to force re-render when forceRenderKey changes */}
      <DragDropContext
        onDragStart={handleDragStart}
        onDragUpdate={handleDragUpdate}
        onDragEnd={handleDragEnd}>
        <div ref={ganttContainerRef} className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden flex flex-col flex-1 min-h-0">
          <div ref={taskHeaderRef} className="flex-shrink-0 border-b border-slate-200">
            <div className="flex">
              <div style={{ width: `${taskListWidth}px` }} className="flex flex-col">
                <div className="px-4 py-3 bg-slate-50 flex-shrink-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-slate-900 text-sm">Tasks & Details</h3>
                    <div className="flex gap-2">
                      {/* Link Tasks Button */}
                      <Button
                        variant={linkingMode ? "default" : "outline"}
                        size="sm"
                        onClick={toggleLinkingMode}
                        className={`flex items-center gap-2 ${linkingMode ? 'bg-blue-600 hover:bg-blue-700 text-white' : ''}`}
                      >
                        <Link className="w-4 h-4" />
                        {linkingMode ? "Exit Link Mode" : "Link Tasks"}
                      </Button>

                      {/* Indent Mode / Collapse Subtasks Button */}
                      <Button
                        variant={indentMode ? "default" : "outline"}
                        size="sm"
                        onClick={toggleIndentMode}
                        className={`flex items-center gap-2 ${indentMode ? 'bg-teal-600 hover:bg-teal-700 text-white' : ''}`}
                      >
                        <ListCollapse className="w-4 h-4" />
                        {indentMode ? "Exit Collapse" : "Collapse Subtasks"}
                      </Button>

                      {/* Conditional Link/Unlink buttons */}
                      {linkingMode && selectedTasksForLinking.length >= 2 && (
                        <>
                          <Button
                            size="sm"
                            onClick={createTaskLinks}
                            className="bg-green-600 hover:bg-green-700 text-white"
                          >
                            <ArrowRight className="w-4 h-4 mr-1" />
                            Create Links ({selectedTasksForLinking.length})
                          </Button>
                          <Button size="sm" onClick={unlinkSelectedTasks} className="bg-red-600 hover:bg-red-700 text-white">
                            <Unlink className="w-4 h-4 mr-1" />
                            Unlink Tasks
                          </Button>
                        </>
                      )}
                      {/* Quick Add Task Button */}
                      <Button size="sm" onClick={handleQuickTaskCreate} className="bg-indigo-600 hover:bg-indigo-700 text-white">
                        <Plus className="w-4 h-4 mr-1" /> Task
                      </Button>
                    </div>
                  </div>
                  {indentMode &&
                    <p className="text-xs text-purple-600 mt-1">
                      Indent Mode: Drag tasks onto other tasks to indent them, or onto the top drop zone to unindent.
                    </p>
                  }
                  {linkingMode &&
                    <p className="text-xs text-slate-600 mt-1">
                      Selected: {selectedTasksForLinking.length} tasks.
                      {selectedTasksForLinking.length >= 2 && " Click 'Create Links' to create dependencies or 'Unlink Tasks' to remove them."}
                      {selectedTasksForLinking.length < 2 && " Select 2+ tasks to link or unlink."}
                    </p>
                  }
                </div>
                <div className="flex items-center bg-slate-100 text-xs font-medium text-slate-600" style={{ height: '32px', paddingLeft: '40px', paddingRight: '8px' }}>
                  <div style={{ width: `${titleWidth}px` }} className="mr-3 flex-shrink-0">Task</div>
                  {renderHeaderFields()}
                </div>
              </div>

              <div
                onMouseDown={handleResizeMouseDown}
                className="w-2.5 bg-slate-200 hover:bg-indigo-100 cursor-col-resize flex items-center justify-center transition-colors"
                style={{ height: '100%' }}>

                <div className="w-1 h-8 bg-slate-400 rounded-full" />
              </div>

              <div className="flex-1 bg-slate-50">
                <div className="px-4 py-3 bg-slate-50 flex items-center gap-2 justify-end" style={{ height: '51px' }}>
                  <Button variant="outline" size="sm" onClick={goToToday}>Today</Button>
                  <div className="flex">
                    <Button variant="outline" size="icon" className="h-9 w-9 rounded-r-none border-r-0" onClick={() => handleTimelineShift('backward')}>
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <Button variant="outline" size="icon" className="h-9 w-9 rounded-l-none" onClick={() => handleTimelineShift('forward')}>
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                <div className="flex w-full" style={{ height: '32px' }}>
                  {timelineHeaders.map((date, index) =>
                    <div key={index} className="flex-1 px-2 py-1 border-r border-slate-100 min-w-0" style={{ flexBasis: `${100 / timelineHeaders.length}%` }}>
                      <div className="text-xs font-semibold text-slate-600">
                        {viewMode === "daily" && format(date, "MMM d")}
                        {viewMode === "weekly" && format(date, "MMM d")}
                        {viewMode === "monthly" && format(date, "MMM yyyy")}
                      </div>
                      <div className="text-xs text-slate-400">
                        {viewMode === "daily" && format(date, "EEE")}
                        {viewMode === "weekly" && `Week ${Math.floor(index / 7) + 1}`}
                        {viewMode === "monthly" && ""}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="flex flex-1 min-h-0">
            <div className="flex flex-col min-h-0" style={{ width: `${taskListWidth}px` }}>
              {indentMode &&
                <Droppable droppableId="root" type="task">
                  {(provided, snapshot) =>
                    <div
                      {...provided.droppableProps}
                      ref={provided.innerRef}
                      className={`h-8 border-2 border-dashed transition-colors flex-shrink-0 ${
                        snapshot.isDraggingOver || dragOverTarget?.type === 'unindent' && dragOverTarget?.targetId === 'root' ?
                          'border-green-400 bg-green-50' :
                          'border-gray-200 bg-gray-50'}`
                      }>

                      <div className="flex items-center justify-center h-full text-xs text-gray-500">
                        {snapshot.isDraggingOver || dragOverTarget?.type === 'unindent' && dragOverTarget?.targetId === 'root' ?
                          "Drop here to move to top level" :
                          "Drag tasks here to unindent"
                        }
                      </div>
                      {provided.placeholder}
                    </div>
                  }
                </Droppable>
              }

              <div ref={taskListRef} className="flex-1 overflow-y-auto min-h-0">
                {indentMode ?
                  <div>
                    {topLevelTasks.map((task, index) => renderSubTasksForIndentMode(task, 0, index))}
                  </div> :

                  <Droppable droppableId="root" type="task">
                    {(provided) =>
                      <div {...provided.droppableProps} ref={provided.innerRef}>
                        {topLevelTasks.map((task, index) =>
                          renderTaskRow(task, 0, index)
                        )}
                        {provided.placeholder}
                      </div>
                    }
                  </Droppable>
                }

                {filteredTasks.length === 0 &&
                  <div className="flex flex-col items-center justify-center h-48">
                    <CalendarDays className="w-12 h-12 text-slate-300 mb-4" />
                    <p className="text-slate-500 font-medium">No tasks found</p>
                    <p className="text-slate-400 text-sm mt-1">Create your first task to get started</p>
                  </div>
                }
              </div>
            </div>

            <div
              onMouseDown={handleResizeMouseDown}
              className="w-2.5 bg-slate-200 hover:bg-indigo-100 cursor-col-resize flex items-center justify-center transition-colors">

              <div className="w-1 h-8 bg-slate-400 rounded-full" />
            </div>

            <div className="flex-1 flex flex-col min-w-0 min-h-0 relative">
              <div ref={timelineRef} className="flex-1 overflow-y-auto min-h-0">
                <div>
                  {topLevelTasks.map((task) => renderTimelineRow(task, 0))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </DragDropContext>

      {showQuickTaskForm &&
        <QuickTaskForm
          onSubmit={handleQuickTaskSubmit}
          onCancel={handleQuickTaskCancel}
          projects={projects}
          resources={resources}
          hoursPerDay={hoursPerDay} />

      }
    </div>);

}

// New AssignedCell component
const AssignedCell = ({ task, isEditing, onEdit, onSave, onCancel, resources, isConflictCheckMode, onSelectResourceForCheck, isSelectedForCheck, linkingMode, customLog }) => {
  // Add comprehensive validation at the start
  try {
    console.log('👤 AssignedCell: Rendering START', {
      taskExists: !!task,
      taskId: task?.id,
      taskTitle: task?.title,
      currentAssignment: task?.assigned_to,
      isEditing,
      resourcesExists: !!resources,
      resourcesCount: resources?.length || 0,
      isConflictCheckMode,
      isSelectedForCheck,
      linkingMode
    });

    if (!task) {
      console.error('❌ AssignedCell: task is null/undefined');
      customLog('AssignedCell: task is null/undefined', { task });
      return <div className="text-red-500 text-xs p-1">Error: No task data</div>;
    }

    if (!task.id) {
      console.error('❌ AssignedCell: task.id is null/undefined', { task });
      customLog('AssignedCell: task.id is null/undefined', { task });
      return <div className="text-red-500 text-xs p-1">Error: Invalid task ID</div>;
    }

    if (!Array.isArray(resources)) {
      console.error('❌ AssignedCell: resources is not an array', { resources });
      customLog('AssignedCell: resources is not an array', { resources });
      return <div className="text-red-500 text-xs p-1">Error: No resources data</div>;
    }

    // Validate resources array for null/undefined entries
    const invalidResourceIndices = [];
    resources.forEach((resource, index) => {
      if (!resource) {
        invalidResourceIndices.push(index);
      } else if (!resource.id) {
        console.warn(`Resource at index ${index} has no ID:`, resource);
        customLog('Resource missing ID', { index, resource });
      }
    });

    if (invalidResourceIndices.length > 0) {
      console.error('❌ AssignedCell: Found null/undefined resources at indices:', invalidResourceIndices);
      customLog('AssignedCell: Invalid resources found', { invalidResourceIndices });
    }

    // Filter out invalid resources for safety
    const validResources = resources.filter(r => r && r.id);
    console.log('👤 AssignedCell: Valid resources count:', validResources.length);

    let assignedResource = null;
    if (task.assigned_to) {
      assignedResource = validResources.find(r => r.id === task.assigned_to);
      console.log('👤 AssignedCell: Resource lookup result', {
        taskId: task.id,
        assigned_to: task.assigned_to,
        foundResource: assignedResource ? { id: assignedResource.id, name: assignedResource.name } : null
      });
    }

    if (isEditing) {
      console.log('✏️ AssignedCell: Rendering edit mode for task:', task.id);
      return (
        <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
          <Select
            value={task.assigned_to || ""}
            onValueChange={(value) => {
              console.log('👤 AssignedCell: Select value changing', {
                taskId: task.id,
                oldValue: task.assigned_to,
                newValue: value,
                valueType: typeof value
              });

              try {
                // Validate the new value
                const finalValue = value === "" ? null : value;
                if (finalValue && finalValue !== null) {
                  const selectedResource = validResources.find(r => r.id === finalValue);
                  if (!selectedResource) {
                    console.error('❌ AssignedCell: Selected invalid resource ID:', finalValue);
                    customLog('AssignedCell: Invalid resource selection', { taskId: task.id, finalValue, availableIds: validResources.map(r => r.id) });
                    return;
                  }
                  console.log('✅ AssignedCell: Valid resource selected:', { id: selectedResource.id, name: selectedResource.name });
                }

                // Call the save handler
                console.log('💾 AssignedCell: Calling onSave with value:', finalValue);
                onSave(finalValue); // `onSave` prop expects just the value
                console.log('✅ AssignedCell: onSave completed');

              } catch (error) {
                console.error('❌ AssignedCell: Error in onValueChange:', {
                  error,
                  message: error?.message,
                  taskId: task.id,
                  value
                });
                customLog('AssignedCell: Error in onValueChange', { error: error.message, taskId: task.id, value });
              }
            }}
          >
            <SelectTrigger className="w-32">
              <SelectValue placeholder="Unassigned" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={null}>Unassigned</SelectItem> {/* Use "" for unassigned, will be mapped to null */}
              {validResources.map((resource) => {
                try {
                  if (!resource || !resource.id) {
                    console.warn('Skipping invalid resource in dropdown:', resource);
                    return null;
                  }
                  return (
                    <SelectItem key={resource.id} value={resource.id}>
                      {resource.name || 'Unnamed Resource'}
                    </SelectItem>
                  );
                } catch (error) {
                  console.error('Error rendering resource option:', { error, resource });
                  return null;
                }
              })}
            </SelectContent>
          </Select>
          <Button variant="ghost" size="sm" onClick={() => {
            console.log('❌ AssignedCell: Cancel clicked for task:', task.id);
            onCancel();
          }}>
            <X className="w-3 h-3" />
          </Button>
        </div>
      );
    }

    // Display mode
    console.log('👁️ AssignedCell: Rendering display mode for task:', task.id);
    const fieldSpecificClass = isConflictCheckMode && task.assigned_to && isSelectedForCheck ? "bg-blue-200 ring-2 ring-blue-500" : "";

    return (
      <div
        className={`px-2 py-1 text-sm rounded min-h-[24px] flex items-center ${linkingMode ? 'cursor-not-allowed text-gray-400 opacity-70' : 'cursor-pointer hover:bg-slate-100'} ${fieldSpecificClass}`}
        onClick={(e) => {
          e.stopPropagation();
          if (isConflictCheckMode && task.assigned_to) {
            console.log('👤 AssignedCell: Conflict check click', { taskId: task.id, resourceId: task.assigned_to });
            onSelectResourceForCheck(task.assigned_to);
          } else if (!linkingMode) {
            console.log('✏️ AssignedCell: Clicked for editing', { taskId: task.id });
            try {
              onEdit();
            } catch (error) {
              console.error('❌ AssignedCell: Error in onEdit:', { error, taskId: task.id });
              customLog('AssignedCell: Error in onEdit', { error: error.message, taskId: task.id });
            }
          }
        }}
        title={isConflictCheckMode && task.assigned_to ? `Click to select ${assignedResource?.name || 'resource'} for conflict check` : `Click to edit assignment`}>

        {assignedResource ? (
          <span className="text-slate-700">{assignedResource.name}</span>
        ) : (
          <span className="text-slate-400 italic">Unassigned</span>
        )}
      </div>
    );

  } catch (error) {
    console.error('❌ AssignedCell: Unexpected error in render:', {
      error,
      message: error?.message,
      stack: error?.stack,
      task,
      isEditing
    });
    customLog('AssignedCell: Unexpected render error', {
      error: error.message,
      taskId: task?.id || 'unknown',
      isEditing
    });

    return <div className="text-red-500 text-xs p-1">Render Error: {error.message}</div>;
  }
};

function QuickTaskForm({ onSubmit, onCancel, projects, resources, hoursPerDay = 9 }) {
  const [formData, setFormData] = useState({
    title: "",
    project_id: "",
    assigned_to: "",
    start_date: "",
    duration_days: 1,
    duration_hours: 0,
    priority: 5,
    effort_days: 0,
    effort_hours: 0
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.title.trim()) return;

    let endDate = "";
    if (formData.start_date && (formData.duration_days > 0 || formData.duration_hours > 0)) {
      const startDate = new Date(formData.start_date);
      // NOTE: QuickTaskForm does not have access to addWorkingHours,
      // so it uses a simplified addHours logic for endDate calculation.
      // For more accurate calculation, this should be handled by the parent
      // GanttChart component or a shared utility.
      const totalDurationHours = formData.duration_days * hoursPerDay + formData.duration_hours;
      const calculatedEndDate = addHours(startDate, totalDurationHours);
      endDate = format(calculatedEndDate, "yyyy-MM-dd");
    }

    onSubmit({
      ...formData,
      end_date: endDate,
      status: "not_started",
      progress: 0,
      is_ongoing: false,
      // Removed estimated_effort as effort_days/hours are now direct properties
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md mx-4">
        <h3 className="text-lg font-semibold text-slate-900 mb-4">Add New Task</h3>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Task Title</label>
            <Input
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="Enter task title"
              autoFocus
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Project</label>
            <select
              value={formData.project_id}
              onChange={(e) => setFormData({ ...formData, project_id: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Select Project</option>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Assigned To</label>
            <select
              value={formData.assigned_to}
              onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
              className="w-full px-3 py-2 border border-slate-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Unassigned</option>
              {resources.map((resource) => (
                <option key={resource.id} value={resource.id}>
                  {resource.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Start Date</label>
              <Input
                type="date"
                value={formData.start_date}
                onChange={(e) => setFormData({ ...formData, start_date: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Duration (Days)</label>
              <Input
                type="number"
                min="0"
                step="0.1"
                value={formData.duration_days}
                onChange={(e) => setFormData({ ...formData, duration_days: parseFloat(e.target.value) || 0 })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Duration (Hours)</label>
              <Input
                type="number"
                min="0"
                step="0.1"
                value={formData.duration_hours}
                onChange={(e) => setFormData({ ...formData, duration_hours: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Priority (1-10)</label>
              <Input
                type="number"
                min="1"
                max="10"
                value={formData.priority}
                onChange={(e) => setFormData({ ...formData, priority: parseInt(e.target.value) || 5 })}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Effort (Days)</label>
              <Input
                type="number"
                min="0"
                step="0.1"
                value={formData.effort_days}
                onChange={(e) => setFormData({ ...formData, effort_days: parseFloat(e.target.value) || 0 })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1">Effort (Hours)</label>
              <Input
                type="number"
                min="0"
                step="0.1"
                value={formData.effort_hours}
                onChange={(e) => setFormData({ ...formData, effort_hours: parseFloat(e.target.value) || 0 })}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Hours per Day</label>
            <Input
              type="number"
              min="1"
              max="24"
              value={hoursPerDay}
              disabled
              className="bg-gray-50"
              title="Default hours per day (currently set to 9)"
            />
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button type="button" variant="outline" onClick={onCancel}>
              Cancel
            </Button>
            <Button type="submit" className="bg-indigo-600 hover:bg-indigo-700">
              Add Task
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
