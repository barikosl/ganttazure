import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, CheckCircle, ArrowRight, Sparkles, User, Calendar, Clock, ChevronRight } from "lucide-react";
import { format, parseISO } from "date-fns";

const ConflictItem = ({ conflict, resources }) => {
    const resourceNameA = resources.find(r => r && r.id === conflict.taskA?.id)?.name || 'N/A';
    const resourceNameB = resources.find(r => r && r.id === conflict.taskB?.id)?.name || 'N/A';
    
    return (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
            <p className="font-semibold text-red-800">Conflict for {resourceNameA}</p>
            <div className="text-sm text-slate-700 mt-2 space-y-1">
                <p><strong>Task:</strong> {conflict.taskA?.title || 'Unknown Task'}</p>
                <p><strong>Time:</strong> {conflict.taskA?.start_date ? format(parseISO(conflict.taskA.start_date), 'MMM d') : 'N/A'} - {conflict.taskA?.end_date ? format(parseISO(conflict.taskA.end_date), 'MMM d') : 'N/A'}</p>
            </div>
            <div className="text-sm text-slate-700 mt-2 space-y-1">
                <p><strong>Overlaps with:</strong> {conflict.taskB?.title || 'Unknown Task'}</p>
                <p><strong>Time:</strong> {conflict.taskB?.start_date ? format(parseISO(conflict.taskB.start_date), 'MMM d') : 'N/A'} - {conflict.taskB?.end_date ? format(parseISO(conflict.taskB.end_date), 'MMM d') : 'N/A'}</p>
            </div>
        </div>
    );
};

const SuggestionItem = ({ task, slots, onApply }) => {
    if (!slots || slots.length === 0) {
        return (
             <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="font-semibold text-amber-800">No available slots found for "{task?.title || 'Unknown Task'}" within the next 90 days.</p>
             </div>
        )
    }

    return (
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="font-semibold text-blue-800">Suggested Start Dates for "{task?.title || 'Unknown Task'}"</p>
            <div className="mt-2 space-y-2">
                {slots.map(slot => (
                    <div key={slot} className="flex items-center justify-between">
                        <span className="text-sm font-medium text-slate-700">{slot ? format(parseISO(slot), 'E, MMM d, yyyy') : 'Invalid Date'}</span>
                        <Button size="sm" variant="outline" onClick={() => onApply(task, slot)}>
                            Apply
                            <ArrowRight className="w-4 h-4 ml-2"/>
                        </Button>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default function ConflictCheckResultsModal({
  isOpen,
  onClose,
  results,
  tasks,
  resources,
  onApplySuggestion,
  findNextAvailableSlotForTask,
}) {

  useEffect(() => {
    if (isOpen) {
      console.log('ConflictCheckResultsModal opened with props', {
        resultsExists: !!results,
        conflictsCount: results?.conflicts?.length ?? 0,
        suggestionsCount: results?.suggestions ? Object.keys(results.suggestions).length : 0,
        tasksCount: tasks?.length ?? 0,
        resourcesCount: resources?.length ?? 0,
        resultsData: results, // Log full results data for inspection
      });
    }
  }, [isOpen, results, tasks, resources]);

  const [selectedConflict, setSelectedConflict] = useState(null);

    if (!isOpen || !results) return null;

    // Add validation for results structure
    if (!results.conflicts || !Array.isArray(results.conflicts)) {
        console.error('ConflictCheckResultsModal: Invalid results structure - conflicts is not an array', results);
        return null;
    }

    const tasksWithSuggestions = results.conflicts.length > 0
        ? [...new Map(results.conflicts
            .filter(c => c && c.taskB && c.taskB.id) // Filter out invalid conflicts
            .map(c => [c.taskB.id, c.taskB])).values()]
        : [];

    return (
        <Dialog open={isOpen} onOpenChange={onClose}>
            <DialogContent className="max-w-3xl">
                <DialogHeader>
                    <DialogTitle className="text-xl">Resource Conflict Check Results</DialogTitle>
                    <DialogDescription>
                        Review the scheduling conflicts and apply suggestions to resolve them.
                    </DialogDescription>
                </DialogHeader>

                <div className="py-4 max-h-[60vh] overflow-y-auto space-y-6">
                    {results.conflicts.length > 0 ? (
                        <div>
                            <h3 className="text-lg font-semibold text-red-700 mb-3 flex items-center gap-2">
                                <AlertTriangle className="w-5 h-5"/>
                                {results.conflicts.length} Conflict(s) Found
                            </h3>
                            <div className="space-y-3">
                                {results.conflicts
                                    .filter(conflict => conflict && conflict.taskA && conflict.taskB) // Filter out invalid conflicts
                                    .map((conflict, index) => (
                                    <ConflictItem key={index} conflict={conflict} resources={resources || []} />
                                ))}
                            </div>
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center p-8 bg-green-50 rounded-lg">
                           <CheckCircle className="w-12 h-12 text-green-500 mb-4"/>
                           <p className="text-lg font-semibold text-green-800">No conflicts found for the selected resources.</p>
                        </div>
                    )}

                    {tasksWithSuggestions.length > 0 && (
                         <div>
                            <h3 className="text-lg font-semibold text-blue-700 mb-3">
                                Resolution Suggestions
                            </h3>
                             <div className="space-y-3">
                                {tasksWithSuggestions
                                    .filter(task => task && task.id) // Filter out invalid tasks
                                    .map(task => (
                                    <SuggestionItem 
                                        key={task.id} 
                                        task={task} 
                                        slots={results.suggestions && results.suggestions[task.id] ? results.suggestions[task.id] : []}
                                        onApply={onApplySuggestion}
                                    />
                                ))}
                             </div>
                        </div>
                    )}
                </div>

                <DialogFooter>
                    <Button variant="outline" onClick={onClose}>Close</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    );
}