import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format, addDays, differenceInDays, parseISO, isValid } from "date-fns";
import { Calendar as CalendarIcon, AlertTriangle, Sparkles, User, Clock } from "lucide-react";

export default function ResourceConflictModal({
  isOpen,
  onClose,
  onConfirm,
  newTaskData,
  conflictingTasks,
  allResourceTasks,
  resource
}) {
  const [editedTask, setEditedTask] = useState(newTaskData);

  useEffect(() => {
    setEditedTask(newTaskData);
  }, [newTaskData]);

  const safeParseDate = (dateString) => {
    if (!dateString) return null;
    try {
      const date = new Date(dateString);
      return isValid(date) ? date : null;
    } catch (error) {
      console.warn("Failed to parse date in conflict modal:", dateString, error);
      return null;
    }
  };

  const safeDateFormat = (dateString, formatStr = "MMM d, yyyy") => {
    const date = safeParseDate(dateString);
    return date ? format(date, formatStr) : "N/A";
  };

  const handleDateChange = (field, date) => {
    if (!date || !isValid(date)) return;
    
    try {
      const newDate = format(date, "yyyy-MM-dd");
      let newEndDate = editedTask.end_date;
      
      if (field === 'start_date' && editedTask.duration_days) {
        const startDate = new Date(newDate);
        newEndDate = format(addDays(startDate, editedTask.duration_days - 1), "yyyy-MM-dd");
      }
      
      setEditedTask(prev => ({ 
        ...prev, 
        [field]: newDate, 
        end_date: newEndDate 
      }));
    } catch (error) {
      console.error("Error handling date change:", error);
    }
  };
  
  const handleDurationChange = (duration) => {
    const newDuration = parseInt(duration, 10) || 1;
    let newEndDate = editedTask.end_date;

    if (editedTask.start_date) {
      const startDate = safeParseDate(editedTask.start_date);
      if (startDate) {
        try {
          newEndDate = format(addDays(startDate, newDuration - 1), "yyyy-MM-dd");
        } catch (error) {
          console.error("Error calculating new end date:", error);
        }
      }
    }
    
    setEditedTask(prev => ({
      ...prev, 
      duration_days: newDuration, 
      end_date: newEndDate 
    }));
  };

  const findNextAvailableDay = () => {
    if (!editedTask || !editedTask.duration_days || !resource) {
      console.warn("Cannot find next available day: missing task data or resource");
      return;
    }

    console.log("Finding next available day for:", {
      task: editedTask.title,
      resource: resource.name,
      duration: editedTask.duration_days,
      currentStart: editedTask.start_date
    });

    // Filter tasks for the same resource, excluding the current task being edited
    const resourceTasks = (allResourceTasks || [])
      .filter(t => 
        t.id !== editedTask.id && 
        t.assigned_to === resource.id &&
        !t.is_ongoing &&
        !['completed', 'cancelled'].includes(t.status) &&
        t.start_date && 
        t.end_date
      )
      .sort((a, b) => {
        const dateA = safeParseDate(a.start_date);
        const dateB = safeParseDate(b.start_date);
        if (!dateA || !dateB) return 0;
        return dateA.getTime() - dateB.getTime();
      });

    console.log("Resource tasks to consider:", resourceTasks.map(t => ({
      title: t.title,
      start: t.start_date,
      end: t.end_date
    })));

    // Start from today or the current start date, whichever is later
    let proposedStartDate = new Date();
    if (editedTask.start_date) {
      const currentStartDate = safeParseDate(editedTask.start_date);
      if (currentStartDate && currentStartDate > proposedStartDate) {
        proposedStartDate = currentStartDate;
      }
    }
    
    try {
      proposedStartDate.setHours(0, 0, 0, 0);

      let isAvailable = false;
      let attempts = 0;
      const maxAttempts = 365;

      while (!isAvailable && attempts < maxAttempts) {
        const proposedEndDate = addDays(proposedStartDate, editedTask.duration_days - 1);
        let hasOverlap = false;

        console.log("Checking slot:", {
          start: format(proposedStartDate, 'yyyy-MM-dd'),
          end: format(proposedEndDate, 'yyyy-MM-dd')
        });

        for (const task of resourceTasks) {
          const taskStart = safeParseDate(task.start_date);
          const taskEnd = safeParseDate(task.end_date);
          
          if (!taskStart || !taskEnd) continue;
          
          // Check for overlap: [start1, end1] overlaps [start2, end2] if start1 <= end2 && end1 >= start2
          if (proposedStartDate <= taskEnd && proposedEndDate >= taskStart) {
            console.log("Overlap found with:", {
              conflictingTask: task.title,
              conflictStart: task.start_date,
              conflictEnd: task.end_date
            });
            hasOverlap = true;
            // Move to the day after the overlapping task ends
            proposedStartDate = addDays(taskEnd, 1);
            proposedStartDate.setHours(0, 0, 0, 0);
            break;
          }
        }

        if (!hasOverlap) {
          console.log("Available slot found:", format(proposedStartDate, 'yyyy-MM-dd'));
          isAvailable = true;
        }
        attempts++;
      }
      
      if (isAvailable) {
        handleDateChange('start_date', proposedStartDate);
      } else {
        console.warn("No available slot found within 365 days");
        alert("No available slot found within the next year. Please manually adjust the schedule.");
      }
    } catch (error) {
      console.error("Error finding next available day:", error);
      alert("An error occurred while finding the next available day. Please try again.");
    }
  };
  
  if (!isOpen || !editedTask) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <AlertTriangle className="w-6 h-6 text-amber-500" />
            Resource Schedule Conflict
          </DialogTitle>
          <DialogDescription>
            <strong>{resource?.name}</strong> is already scheduled for other tasks during this time. Please adjust the schedule.
          </DialogDescription>
        </DialogHeader>

        <div className="py-4 space-y-6">
          <div>
            <h4 className="font-semibold text-slate-800 mb-2">New/Updated Task</h4>
            <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-lg grid grid-cols-3 gap-4">
              <div className="space-y-1">
                <Label>Start Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start font-normal">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {safeDateFormat(editedTask.start_date)}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent>
                    <Calendar 
                      mode="single" 
                      selected={safeParseDate(editedTask.start_date)} 
                      onSelect={(d) => handleDateChange('start_date', d)} 
                    />
                  </PopoverContent>
                </Popover>
              </div>
              <div className="space-y-1">
                <Label>End Date</Label>
                <Input 
                  value={safeDateFormat(editedTask.end_date)} 
                  disabled 
                  className="bg-slate-100"
                />
              </div>
              <div className="space-y-1">
                <Label>Duration (days)</Label>
                <Input 
                  type="number" 
                  min="1"
                  value={editedTask.duration_days || ''} 
                  onChange={(e) => handleDurationChange(e.target.value)} 
                />
              </div>
            </div>
            <div className="mt-2 text-center">
              <Button 
                onClick={findNextAvailableDay} 
                size="sm" 
                variant="outline"
                disabled={!editedTask.duration_days || !resource}
              >
                <Sparkles className="w-4 h-4 mr-2"/>
                Find Next Available Day
              </Button>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-slate-800 mb-2">Conflicting Tasks</h4>
            <div className="space-y-2 p-4 max-h-48 overflow-y-auto border rounded-lg">
              {(conflictingTasks || []).map(task => (
                <div key={task.id} className="p-3 bg-slate-50 rounded-md flex justify-between items-center">
                  <p className="font-medium text-slate-700">{task.title}</p>
                  <div className="text-sm text-slate-500 flex items-center gap-4">
                    <span>
                      {safeDateFormat(task.start_date, "MMM d")} - {safeDateFormat(task.end_date, "MMM d")}
                    </span>
                    <div className="flex items-center gap-1">
                        <Clock className="w-3 h-3"/>
                        <span>{task.estimated_effort || 0}h</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={() => onConfirm(editedTask)}>Confirm and Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}