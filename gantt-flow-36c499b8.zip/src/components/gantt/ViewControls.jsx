
import React from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar, CalendarDays, CalendarRange, Plus, Filter, Undo, Redo, CalendarSearch, ListCollapse, Download, RefreshCw } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function ViewControls({
  viewMode,
  onViewModeChange,
  selectedProject,
  onProjectChange,
  projects,
  onCreateTask,
  onShowFilters,
  activeFilters = {},
  onUndo,
  onRedo,
  canUndo,
  canRedo,
  isConflictCheckMode,
  onToggleConflictCheckMode,
  indentMode,
  onToggleIndentMode,
  onDownloadLogs, // New prop for downloading logs
  onRefreshLinkedTasks, // New prop for refreshing links
}) {
  const viewModes = [
    { value: "daily", label: "Daily", icon: Calendar },
    { value: "weekly", label: "Weekly", icon: CalendarDays },
    { value: "monthly", label: "Monthly", icon: CalendarRange }
  ];

  const activeFilterCount = Object.values(activeFilters).filter(Boolean).length;

  return (
    <div className="bg-white border-b border-slate-200 px-6 py-4">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Left side - View controls */}
        <div className="flex items-center gap-4">
           <div className="flex items-center">
            <Button variant="ghost" size="icon" onClick={onUndo} disabled={!canUndo} title="Undo last action">
              <Undo className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={onRedo} disabled={!canRedo} title="Redo last action">
              <Redo className="w-4 h-4" />
            </Button>
          </div>
          
          <Button variant="outline" size="sm" onClick={onDownloadLogs} title="Download Debug Logs">
            <Download className="w-4 h-4 mr-2" />
            Logs
          </Button>

          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-slate-700">View:</span>
            <div className="flex bg-slate-100 rounded-lg p-1">
              {viewModes.map((mode) => (
                <Button
                  key={mode.value}
                  variant={viewMode === mode.value ? "default" : "ghost"}
                  size="sm"
                  onClick={() => onViewModeChange(mode.value)}
                  className={`flex items-center gap-2 ${
                    viewMode === mode.value 
                      ? "bg-white shadow-sm text-slate-900" 
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  <mode.icon className="w-4 h-4" />
                  {mode.label}
                </Button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-sm font-medium text-slate-700">Project:</span>
            <Select value={selectedProject || "all"} onValueChange={onProjectChange}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="All Projects" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Projects</SelectItem>
                {projects.map((project) => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Right side - Actions */}
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={onRefreshLinkedTasks}
            className="flex items-center gap-2"
            title="Recalculate dates for all linked tasks"
          >
            <RefreshCw className="w-4 h-4" />
            Refresh Links
          </Button>

          <Button
            variant={isConflictCheckMode ? "default" : "outline"}
            size="sm"
            onClick={onToggleConflictCheckMode}
            className={`flex items-center gap-2 ${isConflictCheckMode ? 'bg-teal-600 hover:bg-teal-700' : ''}`}
          >
            <CalendarSearch className="w-4 h-4" />
            Check Conflicts
          </Button>

          <Button
            variant={indentMode ? "default" : "outline"}
            size="sm"
            onClick={onToggleIndentMode}
            className={`flex items-center gap-2 ${indentMode ? 'bg-teal-600 hover:bg-teal-700' : ''}`}
          >
            <ListCollapse className="w-4 h-4" />
            Collapse Subtasks
          </Button>

          <Button
            variant="outline"
            size="sm"
            onClick={onShowFilters}
            className="flex items-center gap-2"
          >
            <Filter className="w-4 h-4" />
            Filters
            {activeFilterCount > 0 && (
              <Badge variant="secondary" className="ml-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
                {activeFilterCount}
              </Badge>
            )}
          </Button>

          <Button 
            onClick={onCreateTask}
            className="bg-indigo-600 hover:bg-indigo-700 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Task
          </Button>
        </div>
      </div>
    </div>
  );
}
