

import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Calendar,
  BarChart3,
  Users, // Used for 'Resources' and now specified for 'Resource Planner' in outline
  Settings,
  FolderKanban,
  GanttChartSquare,
  Users2, // Original icon for 'Resource Planner'
  Settings2
} from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Gantt View",
    url: createPageUrl("Dashboard"),
    icon: GanttChartSquare,
    description: "Timeline & dependencies"
  },
  {
    title: "Projects",
    url: createPageUrl("Projects"),
    icon: FolderKanban,
    description: "Manage projects"
  },
  {
    title: "Resources",
    url: createPageUrl("Resources"),
    icon: Users,
    description: "Team management"
  },
  {
    title: "Resource Planner", // Keep in array to maintain order and structure
    url: createPageUrl("ResourcePlanner"),
    icon: Users2, // Original icon, will be overridden by hardcoded link
    description: "Daily/weekly workload"
  },
  {
    title: "Resource Timeline Planner", // Changed title from "Resource Timeline" to "Resource Timeline Planner"
    url: createPageUrl("ResourceTimelinePlanner"),
    icon: Calendar,
    description: "Timeline view & gaps"
  },
  {
    title: "Analytics",
    url: createPageUrl("Analytics"),
    icon: BarChart3,
    description: "Performance insights"
  }
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();

  // Defensive check: Ensure location and its pathname property exist
  // Use optional chaining and default to an empty string to prevent TypeError if location or pathname is null/undefined.
  const currentPath = location?.pathname || '';

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-slate-50">
        <Sidebar className="border-r border-slate-200 bg-white">
          <SidebarHeader className="border-b border-slate-100 p-4">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-lg flex items-center justify-center shadow-md flex-shrink-0">
                <Calendar className="w-4 h-4 text-white" />
              </div>
              <div className="min-w-0 flex-1">
                <h2 className="font-bold text-slate-900 text-base truncate">GanttPro</h2>
                <p className="text-xs text-slate-500 font-medium truncate">Project Management</p>
              </div>
            </div>
          </SidebarHeader>

          <SidebarContent className="p-3 flex flex-col">
            <SidebarGroup className="flex-1">
              <SidebarGroupLabel className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-3 py-2">
                Navigation
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu className="space-y-1">
                  {navigationItems.map((item) => {
                    // Apply the new structure and styling for "Resource Planner"
                    if (item.title === "Resource Planner") {
                      return (
                        <Link
                          key={item.title}
                          to={createPageUrl("ResourcePlanner")}
                          className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                            currentPageName === "ResourcePlanner" ? "bg-indigo-100 text-indigo-700" : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                          }`}
                        >
                          {/* Note: The outline explicitly uses Users icon, not Users2 */}
                          <Users className="w-5 h-5" />
                          Resource Planner
                        </Link>
                      );
                    }
                    // Apply the new structure and styling for "Resource Timeline Planner"
                    if (item.title === "Resource Timeline Planner") { // Updated condition to match new title
                      return (
                        <Link
                          key={item.title}
                          to={createPageUrl("ResourceTimelinePlanner")}
                          className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
                            currentPageName === "ResourceTimelinePlanner" ? "bg-indigo-100 text-indigo-700" : "text-slate-600 hover:text-slate-900 hover:bg-slate-100"
                          }`}
                        >
                          <Calendar className="w-5 h-5" />
                          Resource Timeline Planner
                        </Link>
                      );
                    }

                    // For all other navigation items, render as before
                    return (
                      <SidebarMenuItem key={item.title}>
                        <SidebarMenuButton
                          asChild
                          className={`rounded-lg transition-all duration-200 group min-h-0 py-2 ${
                            currentPath === item.url
                              ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                              : 'hover:bg-slate-50 text-slate-600 hover:text-slate-900'
                          }`}
                        >
                          <Link to={item.url} className="flex items-center gap-3 px-3">
                            <item.icon className={`w-4 h-4 flex-shrink-0 ${
                              currentPath === item.url ? 'text-indigo-600' : 'text-slate-400 group-hover:text-slate-600'
                            }`} />
                            <div className="flex-1 min-w-0">
                              <span className="font-semibold text-sm block truncate">{item.title}</span>
                              <p className="text-xs text-slate-400 mt-0.5 truncate">{item.description}</p>
                            </div>
                          </Link>
                        </SidebarMenuButton>
                      </SidebarMenuItem>
                    );
                  })}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            {/* New SidebarGroup for Settings, pushed to bottom with mt-auto */}
            <SidebarGroup className="mt-auto">
               <SidebarGroupContent>
                <SidebarMenu>
                  <SidebarMenuItem>
                    <SidebarMenuButton
                        asChild
                        className={`rounded-lg transition-all duration-200 group min-h-0 py-2 ${
                          currentPath === createPageUrl("Settings")
                            ? 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                            : 'hover:bg-slate-50 text-slate-600 hover:text-slate-900'
                        }`}
                      >
                        <Link to={createPageUrl("Settings")} className="flex items-center gap-3 px-3">
                          <Settings2 className={`w-4 h-4 flex-shrink-0 ${
                            currentPath === createPageUrl("Settings") ? 'text-indigo-600' : 'text-slate-400 group-hover:text-slate-600'
                          }`} />
                           <div className="flex-1 min-w-0">
                             <span className="font-semibold text-sm block truncate">Settings</span>
                           </div>
                        </Link>
                      </SidebarMenuButton>
                  </SidebarMenuItem>
                </SidebarMenu>
               </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-slate-100 p-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-slate-200 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-slate-600 font-semibold text-xs">U</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-slate-900 text-sm truncate">Team Lead</p>
                <p className="text-xs text-slate-500 truncate">Manage projects</p>
              </div>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col min-w-0">
          <header className="bg-white border-b border-slate-200 px-4 py-3 lg:hidden">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-slate-100 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-lg font-bold text-slate-900">GanttPro</h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            {children}
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}

