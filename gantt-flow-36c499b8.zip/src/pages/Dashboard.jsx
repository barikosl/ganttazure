
// src/pages/Dashboard.jsx

import React, { useState, useEffect, useCallback, useRef } from "react";
import { Task } from "@/api/entities";
import { Project } from "@/api/entities"; // Fixed syntax error here
import { Resource } from "@/api/entities";
import { AuditLog } from "@/api/entities";
import { Setting } from "@/api/entities";
import { format, addDays, differenceInDays, isValid, addHours, parseISO, isWeekend, getDay } from "date-fns";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { AlertCircle } from "lucide-react"; // Added import for AlertCircle

import GanttChart from "../components/gantt/GanttChart";
import TaskForm from "../components/gantt/TaskForm";
import ViewControls from "../components/gantt/ViewControls";
import ResourceConflictModal from "../components/gantt/ResourceConflictModal";
import ConflictCheckResultsModal from "../components/gantt/ConflictCheckResultsModal";

// --- Debug Logging Utility ---
const logCollector = [];
const customLog = (message, data) => {
    const timestamp = new Date().toISOString();
    const formattedMessage = `[${timestamp}] ${message}`;

    // Log to console for real-time debugging
    console.log(formattedMessage, data !== undefined ? data : '');

    // Collect logs for download
    let dataString = '';
    if (data !== undefined) {
        try {
            dataString = JSON.stringify(data, (key, value) =>
                typeof value === 'object' && value !== null && 'id' in value ? { id: value.id, title: value.title || value.name || 'N/A' } : value, 2);
        } catch (e) {
            dataString = 'Could not stringify data';
        }
    }
    logCollector.push({ timestamp, message: formattedMessage, data: dataString });
};

const downloadLogsAsCSV = () => {
    if (logCollector.length === 0) {
        alert("No logs have been recorded yet.");
        return;
    }
    const header = "timestamp,message,data\n";
    const csvContent = logCollector.map(e => {
        const escapedMessage = `"${String(e.message).replace(/"/g, '""')}"`;
        const escapedData = `"${String(e.data).replace(/"/g, '""')}"`;
        return [e.timestamp, escapedMessage, escapedData].join(",");
    }).join("\n");

    const blob = new Blob([header + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `ganttflow_logs_${new Date().toISOString()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    document.body.removeChild(link);
    link.click(); // Trigger download
    customLog("Logs downloaded.");
};
// --- End Debug Logging Utility ---


export default function Dashboard() {
  // Add error boundary state
  const [hasError, setHasError] = useState(false);
  const [errorDetails, setErrorDetails] = useState(null);

  // Global error handler
  useEffect(() => {
    const handleError = (event) => {
      console.error('🚨 Global Error Caught:', event.error);
      customLog('Global Error', { 
        message: event.error?.message, 
        stack: event.error?.stack,
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno
      });
      
      setHasError(true);
      setErrorDetails({
        message: event.error?.message || 'Unknown error',
        stack: event.error?.stack || 'No stack trace',
        timestamp: new Date().toISOString()
      });
    };

    const handleUnhandledRejection = (event) => {
      console.error('🚨 Unhandled Promise Rejection:', event.reason);
      customLog('Unhandled Promise Rejection', { 
        reason: event.reason?.message || event.reason,
        stack: event.reason?.stack
      });
      setHasError(true);
      setErrorDetails({
        message: event.reason?.message || 'Unhandled Promise Rejection',
        stack: event.reason?.stack || 'No stack trace',
        timestamp: new Date().toISOString()
      });
    };

    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);

    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []);

  const [history, setHistory] = useState([[]]); // History of task states
  const [historyIndex, setHistoryIndex] = useState(0); // Current position in history
  const tasks = history[historyIndex] || []; // Derived tasks state

  const [projects, setProjects] = useState([]);
  const [resources, setResources] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [viewMode, setViewMode] = useState("weekly");
  const [selectedProject, setSelectedProject] = useState(null);
  const [selectedTask, setSelectedTask] = useState(null);
  const [showTaskForm, setShowTaskForm] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showConflictModal, setShowConflictModal] = useState(false);
  const [conflictData, setConflictData] = useState({ // Initialized with useState
    newTask: null,
    conflictingTasks: [],
    allResourceTasks: [],
    resource: null
  });
  const [expandedTasks, setExpandedTasks] = useState(new Set()); // Corrected initialization
  // Ref to always get the current value of expandedTasks inside event listeners
  const expandedTasksRef = useRef(expandedTasks);

  const sortTasksHierarchically = useCallback((tasks) => {
    // 1) Clone so we don't accidentally mutate
    const all = [...tasks];

    // 2) Build a map from parentId → [child, child, …]
    //    Normalize any "missing" parent (undefined, '', null) into the same 'root' key
    const byParent = all.reduce((map, t) => {
      const key = t.parent_task_id != null && t.parent_task_id !== ''
        ? t.parent_task_id
        : 'root';
      if (!map[key]) map[key] = [];
      map[key].push(t);
      return map;
    }, {});

    // 3) Sort each sibling-group exactly once by *numeric* sort_order
    Object.values(byParent).forEach(group => {
      group.sort((a, b) => {
        const aNum = Number(a.sort_order) || 0;
        const bNum = Number(b.sort_order) || 0;
        return aNum - bNum;
      });
    });

    // 4) DFS from 'root' to flatten in the exact saved order
    const result = [];
    function walk(parentKey) {
      const children = byParent[parentKey] || [];
      for (const child of children) {
        result.push(child);
        walk(child.id);
      }
    }
    walk('root');
    return result;
  }, []);


  // Effect to keep expandedTasksRef always current
  useEffect(() => {
    expandedTasksRef.current = expandedTasks;
  }, [expandedTasks]);

  const [isConflictCheckMode, setIsConflictCheckMode] = useState(false); // FIX: Initialize to false
  const [selectedResourcesForCheck, setSelectedResourcesForCheck] = useState(new Set()); // Initialize with new Set()
  const [conflictCheckResults, setConflictCheckResults] = useState(null);
  const [isConflictResultsModalOpen, setIsConflictResultsModalOpen] = useState(false);
  const [updatingTasks, setUpdatingTasks] = useState(new Set()); // Correctly initialize useState with a new Set
  const runConflictCheckRef = useRef(); // Add ref for debouncing conflict check
  const [indentMode, setIndentMode] = useState(false); // Moved from GanttChart
  const [forceRenderKey, setForceRenderKey] = useState(0); // Add forceRenderKey state
  const [workingDays, setWorkingDays] = useState(["monday", "tuesday", "wednesday", "thursday", "friday"]); // Default
  const [hoursPerDay, setHoursPerDay] = useState(9); // Updated to 9 hours per day

  // Add debounce helper (original, but no longer used for task updates directly)
  const debounce = useCallback((func, wait) => {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }, []);

  // Add debounce helper with cancellation support
  const debounceWithCancel = useCallback((func, wait) => {
    let timeout;
    let cancel = () => {};
    
    const debouncedFunction = function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
      
      cancel = () => {
        clearTimeout(timeout);
      };
    };
    
    debouncedFunction.cancel = cancel;
    return debouncedFunction;
  }, []);

  // Add a ref to track the current debounced update function
  const debouncedUpdateRef = useRef(null);

  // Add toggleIndentMode function
      const toggleIndentMode = useCallback(() => {
        customLog("Toggling indentMode", { from: indentMode, to: !indentMode });
        setIndentMode(prev => !prev);
        // bump this to force React to unmount/remount GanttChart
        setForceRenderKey(k => k + 1);
      }, [indentMode]);

  // Add comprehensive task validation function
  const validateTasks = useCallback((taskList) => {
    if (!Array.isArray(taskList)) {
      console.error('validateTasks: taskList is not an array', taskList);
      return [];
    }

    const validTasks = [];
    const invalidTasks = [];

    taskList.forEach((task, index) => {
      try {
        if (!task) {
          invalidTasks.push({ index, reason: 'null/undefined task', task });
          return;
        }

        if (!task.id) {
          invalidTasks.push({ index, reason: 'missing id', task });
          return;
        }

        if (typeof task.id !== 'string') {
          invalidTasks.push({ index, reason: 'invalid id type', task });
          return;
        }

        // Additional validation for critical fields
        const validatedTask = {
          ...task,
          title: task.title || 'Untitled Task',
          status: task.status || 'not_started',
          priority: isNaN(Number(task.priority)) ? 5 : Number(task.priority),
          duration_days: isNaN(Number(task.duration_days)) ? 0 : Number(task.duration_days),
          duration_hours: isNaN(Number(task.duration_hours)) ? 0 : Number(task.duration_hours),
          effort_days: isNaN(Number(task.effort_days)) ? 0 : Number(task.effort_days),
          effort_hours: isNaN(Number(task.effort_hours)) ? 0 : Number(task.effort_hours),
          sort_order: isNaN(Number(task.sort_order)) ? 0 : Number(task.sort_order),
          predecessor_links: Array.isArray(task.predecessor_links) ? task.predecessor_links : [],
          successor_links: Array.isArray(task.successor_links) ? task.successor_links : []
        };

        validTasks.push(validatedTask);
      } catch (error) {
        console.error(`Error validating task at index ${index}:`, error);
        invalidTasks.push({ index, reason: 'validation error', task, error: error.message });
      }
    });

    if (invalidTasks.length > 0) {
      console.warn('Found invalid tasks:', invalidTasks);
      customLog('Invalid tasks found', { count: invalidTasks.length, invalidTasks });
    }

    return validTasks;
  }, []);

  const updateTasksAndRecordHistory = useCallback((newTasks) => {
    // If we undo and then make a new change, we want to discard the old 'future'
    const newHistory = history.slice(0, historyIndex + 1);

    // Limit history size to 10 previous states + the new one
    const limitedHistory = newHistory.length >= 11 ? newHistory.slice(newHistory.length - 10) : newHistory;

    limitedHistory.push(sortTasksHierarchically(newTasks));

    setHistory(limitedHistory);
    setHistoryIndex(limitedHistory.length - 1);
  }, [history, historyIndex, sortTasksHierarchically]);
  
  // Wrap updateTasksAndRecordHistory with validation
  const safeUpdateTasksAndRecordHistory = useCallback((newTasks) => {
    try {
      console.log('🔄 safeUpdateTasksAndRecordHistory called', { tasksCount: newTasks?.length });
      
      if (!newTasks) {
        console.error('safeUpdateTasksAndRecordHistory: newTasks is null/undefined');
        return;
      }

      const validatedTasks = validateTasks(newTasks);
      console.log('✅ Tasks validated', { original: newTasks.length, valid: validatedTasks.length });
      
      updateTasksAndRecordHistory(validatedTasks);
    } catch (error) {
      console.error('Error in safeUpdateTasksAndRecordHistory:', error);
      customLog('safeUpdateTasksAndRecordHistory error', { error: error.message });
      setHasError(true);
      setErrorDetails({
        message: `Error updating tasks: ${error.message}`,
        stack: error.stack,
        timestamp: new Date().toISOString()
      });
    }
  }, [validateTasks, updateTasksAndRecordHistory]);


  const handleUndo = useCallback(() => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
    }
  }, [historyIndex]);

  const handleRedo = useCallback(() => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
    }
  }, [history, historyIndex]);

  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < history.length - 1;

  // Working days helper functions
  const getWorkingDays = (project) => {
    // Project-specific working days can override global settings in the future.
    // For now, we use the global settings.
    return workingDays;
  };

  const getHoursPerDay = (project) => {
    // Project-specific hours can override global settings.
    return hoursPerDay;
  };

  const isWorkingDay = (date, project) => {
    const workingDays = getWorkingDays(project);
    const dayNames = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"];
    const dayName = dayNames[getDay(date)]; // getDay returns 0 for Sunday, 6 for Saturday
    return workingDays.includes(dayName);
  };

  const addWorkingDays = (startDate, days, project) => {
    let currentDate = new Date(startDate);
    let daysAdded = 0;

    // If startDate itself is not a working day, move to the next working day first
    if (!isWorkingDay(currentDate, project)) {
      while (!isWorkingDay(currentDate, project)) {
        currentDate = addDays(currentDate, 1);
      }
    }

    while (daysAdded < days) {
      currentDate = addDays(currentDate, 1);
      if (isWorkingDay(currentDate, project)) {
        daysAdded++;
      }
    }

    return currentDate;
  };

  const addWorkingHours = (startDate, hours, projectSettings, startHourOffset = 0) => {
    const { hoursPerDay, isWorkingDay } = projectSettings;
    
    // Total hours to account for, including any offset from the start day.
    const totalEffectiveHours = Math.max(0, hours);
    if (totalEffectiveHours === 0) return new Date(startDate);

    let resultDate = new Date(startDate);
    let hoursRemainingToSchedule = totalEffectiveHours;

    // Account for startHourOffset on the first day
    // This assumes startHourOffset is hours already used on resultDate by *other* tasks or previous parts of this task
    // And this task starts *after* startHourOffset.
    const hoursAvailableOnFirstDay = hoursPerDay - startHourOffset;

    if (hoursAvailableOnFirstDay > 0) {
        const hoursToTakeOnFirstDay = Math.min(hoursRemainingToSchedule, hoursAvailableOnFirstDay);
        resultDate = addHours(resultDate, hoursToTakeOnFirstDay);
        hoursRemainingToSchedule -= hoursToTakeOnFirstDay;
    }

    // If there are still hours remaining, proceed to full days
    while (hoursRemainingToSchedule > 0) {
        resultDate = addDays(resultDate, 1); // Move to the next day
        while (!isWorkingDay(resultDate)) {
            resultDate = addDays(resultDate, 1); // Skip non-working days
        }
        
        const hoursToTakeOnCurrentDay = Math.min(hoursRemainingToSchedule, hoursPerDay);
        resultDate = addHours(resultDate, hoursToTakeOnCurrentDay);
        hoursRemainingToSchedule -= hoursToTakeOnCurrentDay;
    }

    return resultDate;
  };

  const validateDateRange = (startDate, endDate) => {
    if (!startDate || !endDate) return true; // Allow null or empty dates
    const start = parseISO(startDate);
    const end = parseISO(endDate);
    return isValid(start) && isValid(end) && start <= end;
  };

  // Enhanced parent calculation with mixed duration support - FIXED
  const calculateParentDuration = (parentTask, allTasks) => {
    const children = allTasks.filter(t => t.parent_task_id === parentTask.id);
    if (children.length === 0) return { days: parentTask.duration_days || 0, hours: parentTask.duration_hours || 0 };

    // FIXED: Simple sum of children's durations - no conversion or double counting
    let totalDays = 0;
    let totalHours = 0;

    children.forEach(child => {
      totalDays += (child.duration_days || 0);
      totalHours += (child.duration_hours || 0);
    });

    // ==== normalize every 9h into 1d ====
    const hoursInDay = hoursPerDay;      // 9
    const extraDays  = Math.floor(totalHours / hoursInDay);
    totalDays  += extraDays;
    totalHours = totalHours % hoursInDay;
    return {
      days: totalDays,
      hours: totalHours
    };
  };

  const calculateParentEffort = (parentTask, allTasks, visited = new Set()) => {
    const startTime = Date.now();
    customLog('calculateParentEffort start', { parentId: parentTask.id, visited: Array.from(visited) });

    if (visited.has(parentTask.id)) {
      customLog("Circular parent dependency detected in effort calculation for task:", parentTask.id);
      return { days: 0, hours: 0 };
    }
    visited.add(parentTask.id);

    const children = allTasks.filter(t => t.parent_task_id === parentTask.id);
    if (children.length === 0) {
        // Leaf task, return its own effort
        const result = { days: parentTask.effort_days || 0, hours: parentTask.effort_hours || 0 };
        customLog('calculateParentEffort end (leaf)', { parentId: parentTask.id, result, elapsedMs: Date.now() - startTime });
        return result;
    }

    // Parent task, sum up children's efforts recursively
    let totalDays = 0;
    let totalHours = 0;

    children.forEach(child => {
        const childEffort = calculateParentEffort(child, allTasks, new Set(visited)); // Pass a copy of visited set
        totalDays += childEffort.days;
        totalHours += childEffort.hours;
    });

    const hoursInDay = getHoursPerDay(null);
    if (totalHours >= hoursInDay) {
        totalDays += Math.floor(totalHours / hoursInDay);
        totalHours = totalHours % hoursInDay;
    }

    const result = {
        days: Math.round(totalDays * 10) / 10,
        hours: Math.round(totalHours * 10) / 10,
    };

    customLog('calculateParentEffort end (parent)', { parentId: parentTask.id, result, childrenCount: children.length, elapsedMs: Date.now() - startTime });
    return result;
  };

  const getParentEffortUpdates = (currentTasks) => {
      const startTime = Date.now();
      customLog('getParentEffortUpdates start');
      const taskMap = new Map(currentTasks.map(t => [t.id, { ...t }]));
      const updates = new Map();

      const parents = Array.from(taskMap.values()).filter(t =>
          Array.from(taskMap.values()).some(child => child.parent_task_id === t.id)
      );

      // Process each parent only once - no iteration loop that could cause issues
      for (const parent of parents) {
          const { days, hours } = calculateParentEffort(parent, Array.from(taskMap.values()), new Set());
          const currentParentInMap = taskMap.get(parent.id);
          if (currentParentInMap.effort_days !== days || currentParentInMap.effort_hours !== hours) {
              updates.set(parent.id, { effort_days: days, effort_hours: hours });
          }
      }

      const result = Array.from(updates.entries()).map(([id, data]) => ({id, data}));
      customLog('getParentEffortUpdates finished', { updates: result, elapsedMs: Date.now() - startTime });
      return result;
  };

  const recalculateAllParentDates = (currentTasks) => {
    customLog('recalculateAllParentDates start');
    // This function is now PURE. It returns updates, doesn't make API calls.
    const taskMap = new Map(currentTasks.map(t => [t.id, { ...t }]));
    const updates = new Map();

    const getAllDescendantIds = (parentId, currentTaskMap) => {
        let descendants = [];
        const children = Array.from(currentTaskMap.values()).filter(t => t.parent_task_id === parentId);
        for (const child of children) {
            descendants.push(child.id);
            descendants = descendants.concat(getAllDescendantIds(child.id, currentTaskMap));
        }
        return descendants;
    };

    for (const task of taskMap.values()) {
        const descendantIds = getAllDescendantIds(task.id, taskMap);
        if (descendantIds.length > 0) {
            const descendants = descendantIds.map(id => taskMap.get(id));
            const validChildren = descendants.filter(d => d.start_date && d.end_date && isValid(parseISO(d.start_date)) && isValid(parseISO(d.end_date)));

            const { days: totalDurationDays, hours: totalDurationHours } = calculateParentDuration(task, Array.from(taskMap.values()));

            if (validChildren.length > 0) { // FIXED: Changed 'children.length > 0' to 'validChildren.length > 0'
                const startDates = validChildren.map(d => parseISO(d.start_date));
                const endDates = validChildren.map(d => parseISO(d.end_date));

                const minStartDate = new Date(Math.min.apply(null, startDates));
                const maxEndDate = new Date(Math.max.apply(null, endDates));

                const newStartDateStr = format(minStartDate, "yyyy-MM-dd");
                const newEndDateStr = format(maxEndDate, "yyyy-MM-dd");

                const currentTaskInMap = taskMap.get(task.id);
                if (currentTaskInMap.start_date !== newStartDateStr || currentTaskInMap.end_date !== newEndDateStr ||
                    currentTaskInMap.duration_days !== totalDurationDays || currentTaskInMap.duration_hours !== totalDurationHours) {

                    const updateData = {
                        start_date: newStartDateStr,
                        end_date: newEndDateStr,
                        duration_days: totalDurationDays,
                        duration_hours: totalDurationHours,
                    };

                    taskMap.set(task.id, { ...currentTaskInMap, ...updateData });
                    updates.set(task.id, { ...updates.get(task.id), ...updateData });
                }
            }
        }
    }
    customLog('recalculateAllParentDates finished', { updates: Array.from(updates.values()) });
    return Array.from(updates.entries()).map(([id, data]) => ({ id, data }));
  };

  // REPLACEMENT FOR runAllRecalculationsAndUpdateState FOR FULL DATA SETS
  const processAllDerivedTaskProperties = async (baseTasks) => {
    customLog('processAllDerivedTaskProperties started', { tasksCount: baseTasks.length });
    const allUpdatesMap = new Map();

    const mergeUpdates = (updates) => {
        updates.forEach(update => {
            const existing = allUpdatesMap.get(update.id) || {};
            allUpdatesMap.set(update.id, { ...existing, ...update.data });
        });
    };

    // 1. Get Parent Effort Updates
    const effortUpdates = getParentEffortUpdates(baseTasks);
    mergeUpdates(effortUpdates);

    // Create a temporary state with effort updates applied for date calculations
    let taskMapForDates = new Map(baseTasks.map(t => [t.id, {...t}]));
    allUpdatesMap.forEach((data, id) => {
        const existingTask = taskMapForDates.get(id) || {};
        taskMapForDates.set(id, { ...existingTask, ...data });
    });

    // 2. Get Parent Date/Duration Updates
    const dateUpdates = recalculateAllParentDates(Array.from(taskMapForDates.values()));
    mergeUpdates(dateUpdates);

    const finalUpdates = Array.from(allUpdatesMap.entries()).map(([id, data]) => ({ id, data }));

    let finalTasksState = baseTasks;
    if (finalUpdates.length > 0) {
        customLog('processAllDerivedTaskProperties: Found updates', { finalUpdates });
        finalTasksState = baseTasks.map(t => allUpdatesMap.has(t.id) ? { ...t, ...allUpdatesMap.get(t.id) } : t);
        // Save the cascading updates to the API
        await handleBulkUpdate(finalUpdates);
    } else {
        customLog('processAllDerivedTaskProperties: No derived updates needed.');
    }

    // Always update history with the latest complete task list, whether changed or not.
    safeUpdateTasksAndRecordHistory(finalTasksState); // Changed to safeUpdateTasksAndRecordHistory
    logHierarchySnapshot(finalTasksState);
    setForceRenderKey(k => k + 1); // Force Gantt re-render

    customLog('processAllDerivedTaskProperties finished');
    return finalTasksState; // Return the final state
  };


 useEffect(() => {
  // 1) Fetch initial data
  const fetchInitialData = async () => {
    setIsLoading(true);
    try {
      const [tasksResponse, projectsResponse, resourcesResponse, settingsData] = await Promise.all([
        Task.list("sort_order"),
        Project.list("-created_date"),
        Resource.list("name"),
        Setting.filter({ key: 'working_days' })
      ]);

      // --- Data Sanitization ---
      // Filter out any null, undefined, or incomplete records from API responses
      const tasksData = (tasksResponse || []).filter(t => t && t.id);
      const projectsData = (projectsResponse || []).filter(p => p && p.id);
      const resourcesData = (resourcesResponse || []).filter(r => r && (r.id || r.name));

      if (settingsData.length > 0 && settingsData[0].value?.days) {
        setWorkingDays(settingsData[0].value.days);
      }

      // Initial history set, then trigger full recalculation
      const initialSortedTasks = sortTasksHierarchically(tasksData);
      // History will be updated by processAllDerivedTaskProperties
      await processAllDerivedTaskProperties(initialSortedTasks);

      setProjects(projectsData);
      resourcesData.forEach(r => (r.id = r.id || r.name));
      setResources(resourcesData);
      customLog("Initial data loaded and sanitized successfully", {
        tasksCount: tasksData.length,
        projectsCount: projectsData.length,
        resourcesCount: resourcesData.length,
      });
    } catch (error) {
      console.error("Error loading data:", error);
      customLog("Error loading initial data", { error: error.message });
      setHasError(true);
      setErrorDetails({
        message: `Failed to load initial application data: ${error.message}`,
        stack: error.stack,
        timestamp: new Date().toISOString()
      });
      if (error.response?.status === 429) {
        setTimeout(fetchInitialData, 2000);
      }
    } finally {
      setIsLoading(false);
    }
  };
  fetchInitialData();

  // 2) One-time “indent mode” kick
  const initializeIndentMode = () => {
    customLog("Auto-initializing indent mode to fix logic");
    setIndentMode(true);
    setTimeout(() => {
      setIndentMode(false);
      customLog("Auto-initialization complete - indent mode disabled");
    }, 100);
  };
  const initTimer = setTimeout(initializeIndentMode, 500);

  // 3) Event listeners
  const handleRefreshTaskView = async (event) => {
    const { reason } = event.detail || {};
    customLog(`Refresh task view triggered: ${reason}`, { reason });

    const refreshed = await Task.list("sort_order");
    await processAllDerivedTaskProperties(refreshed);
  };

  const handleTaskCreated = async (event) => {
    const { newTask } = event.detail || {}; // Removed parentId destructuring
    customLog("New task created, refreshing view", { newTask });

    const refreshed = await Task.list("sort_order");
    await processAllDerivedTaskProperties(refreshed);
  };

  window.addEventListener("refreshTaskView", handleRefreshTaskView);
  window.addEventListener("taskCreated", handleTaskCreated);

  // 4) Cleanup once when unmounting
  return () => {
    clearTimeout(initTimer);
    window.removeEventListener("refreshTaskView", handleRefreshTaskView);
    window.removeEventListener("taskCreated", handleTaskCreated);
  };
}, [sortTasksHierarchically]); // Add sortTasksHierarchically to dependency array

  // Separate useEffect for refreshTaskView after initial load
  useEffect(() => {
    if (!isLoading) {
      customLog("Initial load complete, doing full Gantt refresh");
      window.dispatchEvent(new CustomEvent("refreshTaskView", {
        detail: { reason: "initialLoad" }
      }));
    }
  }, [isLoading]);

  const logHierarchyChange = async (task, operation, details) => {
    try {
      customLog(`Audit Log: ${operation}`, { taskId: task.id, details });
      await AuditLog.create({
        task_id: task.id,
        task_title: task.title,
        operation_type: operation,
        details: JSON.stringify(details)
      });
    } catch (error) {
      customLog("Failed to create audit log", { error: error.message, task, operation, details });
    }
  };

  const logGeneric = async(operation, details) => {
    try {
        customLog(`Audit Log (Generic): ${operation}`, details);
        await AuditLog.create({
            task_id: "N/A",
            task_title: "System Operation",
            operation_type: operation,
            details: JSON.stringify(details)
        });
    } catch (error) {
        customLog("Failed to create generic audit log", { error: error.message, operation, details });
    }
  }

  const logHierarchySnapshot = (tasksToLog) => {
    const parents = tasksToLog.filter(t => tasksToLog.some(child => child.parent_task_id === t.id));
    const snapshot = parents.map(p => ({
        parent: { id: p.id, title: p.title, duration_days: p.duration_days, duration_hours: p.duration_hours, effort_days: p.effort_days, effort_hours: p.effort_hours },
        children: tasksToLog.filter(c => c.parent_task_id === p.id).map(c => ({ id: c.id, title: c.title, duration_days: c.duration_days, duration_hours: c.duration_hours, effort_days: c.effort_days, effort_hours: c.effort_hours }))
    }));
    customLog("Hierarchy Snapshot", snapshot);
  };

  const loadData = async () => {
    // This function is now mainly for manual refresh or error recovery
    setIsLoading(true);
    try {
      const tasksData = await Task.list("-created_date"); // Fixed: Use single column sort
      await processAllDerivedTaskProperties(tasksData); // Recalculate and update history
      customLog("Data reloaded successfully.");
    } catch (error) {
      console.error("Error loading data:", error);
      customLog("Error reloading data", { error: error.message });
      if (error.response?.status === 429) {
        setTimeout(() => {
          loadData();
        }, 2000);
      }
    }
    setIsLoading(false);
  };

  const handleBulkUpdate = async (updates) => {
    customLog('handleBulkUpdate start', { count: updates.length });

  // 1) Sanitize & coerce exactly what changed
    const numericFields = new Set([
      'sort_order',
      'duration_days','duration_hours',
      'effort_days','effort_hours',
      'progress','estimated_effort'
    ]);

    const sanitized = updates
      .map(({ id, data }) => {
        const payload = {};
        for (const [key, raw] of Object.entries(data)) {
          if (raw == null || raw === '') continue;
          let val = typeof raw === 'string' ? raw.trim() : raw;

          if (key === 'priority') {
            const n = Number(val);
            payload.priority = Number.isNaN(n) ? 5 : n;
          }
          else if (numericFields.has(key)) {
            const n = Number(val);
            if (Number.isNaN(n)) continue;
            payload[key] = n;
          }
          else {
            payload[key] = val;
          }
        }
        // drop any no-op updates
        return Object.keys(payload).length
          ? { id, data: payload }
          : null;
      })
      .filter(Boolean);

    if (sanitized.length === 0) {
      customLog('handleBulkUpdate: nothing to send');
      return;
    }

    console.log('📤 bulk payload:', sanitized);

    // 2) Fire off updates sequentially with a delay to avoid rate limiting
    try {
      for (let i = 0; i < sanitized.length; i++) {
        const { id, data } = sanitized[i];
        customLog('handleBulkUpdate sending', { id, data });
        await Task.update(id, data);

        // Add a delay to prevent hitting the rate limit
        if (i < sanitized.length - 1) {
          await new Promise(resolve => setTimeout(resolve, 250));
        }
      }
      customLog('handleBulkUpdate finish');
    }
    catch (err) {
      customLog('handleBulkUpdate encountered error', { error: err.message });
      throw err;
    }
  };

  const handleCreateTask = async (taskData = null) => {
    if (taskData && taskData.title) {
      // If taskData is provided with a title, save it directly (inline creation)
      await saveTask(taskData);
      // After inline save, record a new history entry
      safeUpdateTasksAndRecordHistory([...tasks]); // Changed to safeUpdateTasksAndRecordHistory
    } else {
      // Otherwise, open the task form (button creation)
      setSelectedTask(taskData);
      setShowTaskForm(true);
    }
  };

  const handleEditTask = (task) => {
    setSelectedTask(task);
    setShowTaskForm(true);
  };

  const checkForConflict = (taskData) => {
    // If the task being saved is "ongoing", or completed/cancelled, it doesn't cause conflicts.
    if (taskData.is_ongoing || ["completed", "cancelled"].includes(taskData.status)) {
      return null;
    }

    if (!taskData.assigned_to || !taskData.start_date || !taskData.end_date) return null;

    // Filter for tasks assigned to the same resource, excluding the task being edited itself,
    // and also excluding any other "ongoing" tasks, as they don't block the schedule.
    const resourceTasks = tasks.filter(t =>
      t.assigned_to === taskData.assigned_to &&
      t.id !== taskData.id &&
      !t.is_ongoing && // Ongoing tasks do not conflict
      !["completed", "cancelled"].includes(t.status) &&
      t.start_date && t.end_date
    );

    const taskStart = parseISO(taskData.start_date);
    const taskEnd = parseISO(taskData.end_date);

    const conflictingTasks = resourceTasks.filter(existingTask => {
      const existingStart = parseISO(existingTask.start_date);
      const existingEnd = parseISO(existingTask.end_date);

      // Basic overlap check
      const overlaps = taskStart <= existingEnd && taskEnd >= existingStart;
      if (!overlaps) return false;

      // Hourly conflict check for overlapping days
      // Determine the actual period of overlap
      let currentCheckDate = new Date(Math.max(taskStart.getTime(), existingStart.getTime()));
      const endCheckDate = new Date(Math.min(taskEnd.getTime(), existingEnd.getTime()));

      const resourceHourlyCapacity = getHoursPerDay(null); // Assuming global hours per day

      while(currentCheckDate.getTime() <= endCheckDate.getTime()) {
        if(isWorkingDay(currentCheckDate, null)) { // Assuming global project settings for now
            // Get all tasks for this resource that are active on the currentCheckDate, including the new task and the existing one
            // We need to consider *all* tasks on that resource for that day, not just the one being compared.
            const allTasksForResourceOnDay = tasks.filter(t =>
                t.assigned_to === taskData.assigned_to &&
                t.id !== taskData.id && // Exclude the new task if it's already in 'tasks' list (update scenario)
                parseISO(t.start_date) <= currentCheckDate &&
                parseISO(t.end_date) >= currentCheckDate &&
                !t.is_ongoing &&
                !["completed", "cancelled"].includes(t.status)
            ).concat([taskData]); // Add the task being currently checked

            let totalHoursAllocatedOnDay = 0;
            allTasksForResourceOnDay.forEach(task => {
                // Calculate daily distributed hours for each task
                const taskS = parseISO(task.start_date);
                const taskE = parseISO(task.end_date);
                if (!isValid(taskS) || !isValid(taskE)) return; // Skip invalid dates

                const durationDays = task.duration_days || 0;
                const durationHours = task.duration_hours || 0;
                const totalTaskHours = (durationDays * resourceHourlyCapacity) + durationHours; // Use resourceHourlyCapacity for conversion

                // Calculate actual number of working days the task spans
                let workingDaysSpan = 0;
                let tempDate = new Date(taskS);
                while (tempDate.getTime() <= taskE.getTime()) {
                    if (isWorkingDay(tempDate, null)) {
                        workingDaysSpan++;
                    }
                    tempDate = addDays(tempDate, 1);
                }

                const dailyDistributedHours = workingDaysSpan > 0 ? (totalTaskHours / workingDaysSpan) : 0;
                totalHoursAllocatedOnDay += dailyDistributedHours;
            });

            if (totalHoursAllocatedOnDay > resourceHourlyCapacity) {
                return true; // Conflict found due to hourly over-allocation
            }
        }
        currentCheckDate = addDays(currentCheckDate, 1);
      }

      return false; // No hourly conflict found on overlapping days
    });

    if (conflictingTasks.length) {
      return {
        conflictingTasks,
        allResourceTasks: resourceTasks,
        resource: resources.find(r => r.id === taskData.assigned_to)
      };
    }
    return null;
  };

  const saveTask = async (taskData) => {
    customLog('saveTask start', { taskData });
    // This function is now only responsible for API calls, not state updates.
    if (isSubmitting) return;
    setIsSubmitting(true);
    try {
      // Validate date range before attempting to save
      if (taskData.start_date && taskData.end_date) {
        const startDate = parseISO(taskData.start_date);
        const endDate = parseISO(taskData.end_date);
        
        if (isValid(startDate) && isValid(endDate) && endDate < startDate) {
          // Auto-correct: set end date to start date if it's before
          taskData.end_date = taskData.start_date;
          customLog('Auto-corrected end date to match start date', {
            taskId: taskData.id || 'new',
            start_date: taskData.start_date,
            corrected_end_date: taskData.end_date
          });
        }
      }

      // Validate durations
      if ((taskData.duration_days && taskData.duration_days < 0) || 
          (taskData.duration_hours && taskData.duration_hours < 0)) {
        throw new Error("Duration must be zero or greater.");
      }

      // Create a completely clean object to prevent SecurityErrors
      // Only include primitive values (strings, numbers, booleans, null)
      const cleanData = {
        title: String(taskData.title || ""),
        description: String(taskData.description || ""),
        start_date: String(taskData.start_date || ""),
        end_date: String(taskData.end_date || ""),
        actual_start_date: taskData.actual_start_date || null,
        actual_end_date: taskData.actual_end_date || null,
        approved_planning_start_date: taskData.approved_planning_start_date || null,
        approved_planning_end_date: taskData.approved_planning_end_date || null,
        status: String(taskData.status || "not_started"),
        notes: String(taskData.notes || ""),
        azure_work_item_id: taskData.azure_work_item_id || null,
        user_story_link: String(taskData.user_story_link || ""),
        resource_name: String(taskData.resource_name || ""),

        project_id: taskData.project_id || null,
        parent_task_id: taskData.parent_task_id || null,
        assigned_to: taskData.assigned_to || null,

        // Using predecessor_links for dependencies as per linking feature
        predecessor_links: Array.isArray(taskData.predecessor_links) ? taskData.predecessor_links : [],
        successor_links: Array.isArray(taskData.successor_links) ? taskData.successor_links : [],

        // Fix: Explicitly handle priority validation to align with handleBulkUpdate
        priority: (() => {
          const num = Number(taskData.priority);
          if (Number.isNaN(num)) {
            console.warn(`⛔ Invalid value for "priority"="${taskData.priority}" for task ${taskData.id || 'new task'}, defaulting to 5.`);
            customLog(`Invalid priority for task ${taskData.id || 'new task'}`, { value: taskData.priority, defaultingTo: 5 });
            return 5;
          }
          return num || 5; // If num is 0 (from ''), default to 5. Otherwise use num.
        })(),
        progress: Number(taskData.progress) || 0,
        duration_days: Number(taskData.duration_days) || 0, // Default to 0 for new tasks
        duration_hours: Number(taskData.duration_hours) || 0, // New field
        effort_days: Number(taskData.effort_days) || 0,
        effort_hours: Number(taskData.effort_hours) || 0,
        estimated_effort: Number(taskData.estimated_effort) || 0, // This is legacy, but keep for now
        sort_order: Number(taskData.sort_order) || 0,

        is_ongoing: Boolean(taskData.is_ongoing)
      };

      let savedTask;
      if (taskData.id) {
        savedTask = await Task.update(taskData.id, cleanData);
        customLog('Task updated via API', { taskId: taskData.id, cleanData });
      } else {
        // It's a new task, calculate its sort order using current state
        const siblings = tasks.filter(t => t.parent_task_id === cleanData.parent_task_id);
        const maxSortOrder = Math.max(-1, ...siblings.map(s => s.sort_order || 0)); // Use -1 to handle empty list
        cleanData.sort_order = maxSortOrder + 1;

        savedTask = await Task.create(cleanData);
        customLog('Task created via API', { savedTask });
      }

      customLog('saveTask success', { savedTask });
      return savedTask; // Return the saved task
    } catch (error) {
      console.error("Error saving task:", error);
      customLog("Error saving task", { error: error.message, taskData });
      if (error.response?.status === 429) {
        // No alert needed, rate limited
      } else {
        // No alert needed, other error
      }
      throw error; // Re-throw to allow calling functions to handle
    } finally {
      setIsSubmitting(false);
    }
  };

  // NEW: Processes updates for a task's parent chain.
  const runCascadingParentUpdate = async (startTask, allTasks) => {
    // Add validation at the start
    if (!startTask || !startTask.id) {
      console.error('runCascadingParentUpdate: Invalid startTask', startTask);
      customLog('runCascadingParentUpdate: Invalid startTask', { startTask });
      return allTasks; // Return original tasks if input is invalid
    }

    if (!Array.isArray(allTasks)) {
      console.error('runCascadingParentUpdate: allTasks is not an array', allTasks);
      customLog('runCascadingParentUpdate: allTasks is not an array', { allTasks });
      return []; // Return empty array if input is invalid
    }

    customLog('Running cascading parent update for task:', { id: startTask.id, title: startTask.title });

    const getParentChainUpdates = (task, tasks) => {
        if (!task || !task.id) {
          console.error('getParentChainUpdates: Invalid task', task);
          return { updates: [], updatedTasks: tasks };
        }

        const updates = [];
        let currentParentId = task.parent_task_id;
        const taskMap = new Map();
        
        // Validate tasks before creating map
        const validTasks = tasks.filter(t => t && t.id);
        validTasks.forEach(t => taskMap.set(t.id, { ...t }));

        while (currentParentId) {
            const parent = taskMap.get(currentParentId);
            if (!parent || !parent.id) {
              console.warn('Parent task not found or invalid:', currentParentId);
              break;
            }

            const updateData = {};

            // Recalculate parent dates & duration
            const { days: durationDays, hours: durationHours } = calculateParentDuration(parent, Array.from(taskMap.values()));
            const { days: effortDays, hours: effortHours } = calculateParentEffort(parent, Array.from(taskMap.values()));

            updateData.duration_days = durationDays;
            updateData.duration_hours = durationHours;
            updateData.effort_days = effortDays;
            updateData.effort_hours = effortHours;

            const children = Array.from(taskMap.values()).filter(t => t && t.parent_task_id === parent.id);
            const validChildren = children.filter(c => c && c.start_date && isValid(parseISO(c.start_date)) && c.end_date && isValid(parseISO(c.end_date)));

            if (validChildren.length > 0) {
                const startDates = validChildren.map(c => parseISO(c.start_date));
                const endDates = validChildren.map(c => parseISO(c.end_date));
                updateData.start_date = format(new Date(Math.min(...startDates)), 'yyyy-MM-dd');
                updateData.end_date = format(new Date(Math.max(...endDates)), 'yyyy-MM-dd');
            }

            const hasChanged = Object.keys(updateData).some(key => parent[key] !== updateData[key]);

            if (hasChanged) {
                updates.push({ id: parent.id, data: updateData });
                taskMap.set(parent.id, { ...parent, ...updateData }); // Update map for subsequent parent calculations
            }

            currentParentId = parent.parent_task_id;
        }
        return { updates, updatedTasks: Array.from(taskMap.values()) };
    };

    try {
      const { updates: parentUpdates, updatedTasks: tasksWithParentChanges } = getParentChainUpdates(startTask, allTasks);

      if (parentUpdates.length === 0) {
          customLog('No parent updates required.');
          return allTasks; // Return original tasks if no changes
      }

      // Save parent updates with rate limiting
      customLog('Saving parent updates with rate limit', { count: parentUpdates.length });
      for (let i = 0; i < parentUpdates.length; i++) {
          const { id, data } = parentUpdates[i];
          try {
              await Task.update(id, data);
          } catch (error) {
              console.error(`Failed to update parent task ${id}:`, error);
              // Non-blocking toast can be added here
          }
          if (i < parentUpdates.length - 1) {
              await new Promise(resolve => setTimeout(resolve, 250)); // Avoid rate limits
          }
      }

      return tasksWithParentChanges; // Return the fully updated list
    } catch (error) {
      console.error('Error in runCascadingParentUpdate:', error);
      customLog('Error in runCascadingParentUpdate', { error: error.message });
      return allTasks; // Return original tasks on error
    }
  };

  const recalculateLinkedTaskDates = async (startTask, allTasks, projectSettings) => {
    // Comprehensive validation
    if (!startTask) {
        console.error('recalculateLinkedTaskDates: startTask is null/undefined');
        customLog('recalculateLinkedTaskDates: startTask is null/undefined', { startTask });
        return [];
    }
    
    if (!startTask.id) {
        console.error('recalculateLinkedTaskDates: startTask.id is undefined', startTask);
        customLog('recalculateLinkedTaskDates: startTask.id is undefined', { startTask });
        return [];
    }

    if (!Array.isArray(allTasks)) {
        console.error('recalculateLinkedTaskDates: allTasks is not an array', { allTasks });
        customLog('recalculateLinkedTaskDates: allTasks is not an array', { allTasks });
        return [];
    }

    if (!projectSettings) {
        console.error('recalculateLinkedTaskDates: projectSettings is undefined');
        customLog('recalculateLinkedTaskDates: projectSettings is undefined', { projectSettings });
        return [];
    }

    customLog('recalculateLinkedTaskDates started (resource-aware)', { 
        startTaskId: startTask.id, 
        startTaskTitle: startTask.title,
        allTasksCount: allTasks.length 
    });

    // Validate that all tasks have IDs
    const invalidTasks = allTasks.filter(t => !t || !t.id);
    if (invalidTasks.length > 0) {
        console.error('Found tasks without IDs:', invalidTasks);
        customLog('Found tasks without IDs', { invalidTasks });
        // Filter out invalid tasks
        allTasks = allTasks.filter(t => t && t.id);
    }

    const taskMap = new Map();
    try {
        allTasks.forEach((task, index) => {
            if (!task) {
                console.error(`Task at index ${index} is null/undefined`);
                return;
            }
            if (!task.id) {
                console.error(`Task at index ${index} has no ID:`, task);
                return;
            }
            taskMap.set(task.id, { ...task });
        });
    } catch (error) {
        console.error('Error building taskMap:', error);
        customLog('Error building taskMap', { error: error.message });
        return [];
    }

    const updates = [];
    const queue = [startTask.id];
    const visited = new Set();

    // Resource calendar with defensive checks
    const resourceCalendar = new Map();

    // Find tasks to reschedule with better error handling
    const tasksToReschedule = new Set();
    const findSuccessorsRecursively = (taskId) => {
        if (!taskId) {
            console.warn('findSuccessorsRecursively called with null/undefined taskId');
            return;
        }
        
        if (tasksToReschedule.has(taskId)) return;
        tasksToReschedule.add(taskId);
        
        const task = taskMap.get(taskId);
        if (!task) {
            console.warn(`Task not found in taskMap: ${taskId}`);
            return;
        }
        
        if (task.successor_links && Array.isArray(task.successor_links)) {
            task.successor_links.forEach(succId => {
                if (succId) {
                    findSuccessorsRecursively(succId);
                }
            });
        }
    };

    try {
        findSuccessorsRecursively(startTask.id);
    } catch (error) {
        console.error('Error in findSuccessorsRecursively:', error);
        customLog('Error in findSuccessorsRecursively', { error: error.message });
        return [];
    }

    // Build static calendar with error handling
    const staticTasks = allTasks.filter(t => t && t.id && !tasksToReschedule.has(t.id));
    
    for (const task of staticTasks) {
        try {
            if (!task.assigned_to || !task.start_date || !task.end_date) continue;
            
            const totalTaskHours = (task.duration_days || 0) * projectSettings.hoursPerDay + (task.duration_hours || 0);
            if (totalTaskHours <= 0) continue;

            let currentDate = parseISO(task.start_date);
            if (!isValid(currentDate)) {
                console.warn(`Invalid start_date for task ${task.id}: ${task.start_date}`);
                continue;
            }

            let hoursRemaining = totalTaskHours;
            while (hoursRemaining > 0) {
                if (projectSettings.isWorkingDay(currentDate)) {
                    const key = `${task.assigned_to}-${format(currentDate, 'yyyy-MM-dd')}`;
                    const hoursOnDay = resourceCalendar.get(key) || 0;
                    const capacityLeft = Math.max(0, projectSettings.hoursPerDay - hoursOnDay);
                    const hoursToAdd = Math.min(hoursRemaining, capacityLeft);
                    
                    if (hoursToAdd > 0) {
                        resourceCalendar.set(key, hoursOnDay + hoursToAdd);
                        hoursRemaining -= hoursToAdd;
                    }
                }
                
                if (hoursRemaining > 0) {
                    currentDate = addDays(currentDate, 1);
                }
            }
        } catch (error) {
            console.error(`Error processing static task ${task.id}:`, error);
            customLog(`Error processing static task ${task.id}`, { error: error.message, task });
        }
    }

    customLog('Built static resource calendar', { calendarSize: resourceCalendar.size });

    // Main processing loop with comprehensive error handling
    while (queue.length > 0) {
        let currentTaskId;
        try {
            currentTaskId = queue.shift();
            
            if (!currentTaskId) {
                console.warn('Found null/undefined task ID in queue');
                continue;
            }
            
            if (visited.has(currentTaskId)) continue;
            visited.add(currentTaskId);

            const predecessor = taskMap.get(currentTaskId);
            if (!predecessor) {
                console.warn(`Predecessor task not found: ${currentTaskId}`);
                continue;
            }

            if (!predecessor.successor_links || !Array.isArray(predecessor.successor_links) || predecessor.successor_links.length === 0) {
                continue;
            }

            const predecessorEndDate = predecessor.end_date ? parseISO(predecessor.end_date) : null;
            if (!predecessorEndDate || !isValid(predecessorEndDate)) {
                console.warn(`Invalid predecessor end date for ${predecessor.title || predecessor.id}: ${predecessor.end_date}`);
                continue;
            }

            for (const successorId of predecessor.successor_links) {
                try {
                    if (!successorId) {
                        console.warn('Found null/undefined successor ID');
                        continue;
                    }

                    const successorTask = taskMap.get(successorId);
                    if (!successorTask) {
                        console.warn(`Successor task not found: ${successorId}`);
                        continue;
                    }

                    if (visited.has(successorId)) continue;

                    const successorTotalHours = (successorTask.duration_days || 0) * projectSettings.hoursPerDay + (successorTask.duration_hours || 0);
                    if (successorTotalHours <= 0) continue;

                    // FIXED: Check if successor can start on the same day as predecessor ends
                    let newStartDate = null;
                    let startHourOffset = 0;

                    if (successorTask.assigned_to && predecessor.assigned_to === successorTask.assigned_to) {
                        // Same resource: Check remaining capacity on predecessor's end date
                        const predecessorEndDateKey = `${predecessor.assigned_to}-${format(predecessorEndDate, 'yyyy-MM-dd')}`;
                        const hoursAlreadyUsedOnEndDate = resourceCalendar.get(predecessorEndDateKey) || 0;
                        const remainingCapacityOnEndDate = projectSettings.hoursPerDay - hoursAlreadyUsedOnEndDate;

                        customLog('DEBUG: Same resource dependency check', {
                            predecessor: predecessor.title,
                            successor: successorTask.title,
                            resource: predecessor.assigned_to,
                            endDate: format(predecessorEndDate, 'yyyy-MM-dd'),
                            hoursAlreadyUsed: hoursAlreadyUsedOnEndDate,
                            remainingCapacity: remainingCapacityOnEndDate,
                            successorNeedsHours: successorTotalHours
                        });

                        if (remainingCapacityOnEndDate >= successorTotalHours) {
                            // Successor can start on the same day
                            newStartDate = new Date(predecessorEndDate);
                            startHourOffset = hoursAlreadyUsedOnEndDate;
                            customLog('✅ Successor can start same day as predecessor ends', {
                                successor: successorTask.title,
                                startDate: format(newStartDate, 'yyyy-MM-dd'),
                                startHourOffset
                            });
                        }
                    }

                    // If we couldn't fit on the same day, find next available slot
                    if (!newStartDate) {
                        let searchDate = new Date(predecessorEndDate);
                        
                        // If different resources, can start immediately after predecessor
                        if (!successorTask.assigned_to || predecessor.assigned_to !== successorTask.assigned_to) {
                            newStartDate = new Date(predecessorEndDate);
                            startHourOffset = 0;
                        } else {
                            // Same resource, need to find next available slot
                            searchDate = addDays(searchDate, 1);
                            
                            while (newStartDate === null) {
                                if (projectSettings.isWorkingDay(searchDate)) {
                                    const key = `${successorTask.assigned_to}-${format(searchDate, 'yyyy-MM-dd')}`;
                                    const hoursAlreadyOnDay = resourceCalendar.get(key) || 0;
                                    
                                    if (hoursAlreadyOnDay < projectSettings.hoursPerDay) {
                                        const availableHours = projectSettings.hoursPerDay - hoursAlreadyOnDay;
                                        if (availableHours >= successorTotalHours) {
                                            newStartDate = new Date(searchDate);
                                            startHourOffset = hoursAlreadyOnDay;
                                        }
                                    }
                                }
                                
                                if (newStartDate === null) {
                                    searchDate = addDays(searchDate, 1);
                                }
                            }
                        }
                    }

                    // Calculate end date using addWorkingHours
                    const newEndDate = addWorkingHours(newStartDate, successorTotalHours, projectSettings, startHourOffset);
                    const finalEndDate = addHours(newEndDate, -0.01);
                    
                    const newStartDateStr = format(newStartDate, "yyyy-MM-dd");
                    const newEndDateStr = isValid(finalEndDate) ? format(finalEndDate, "yyyy-MM-dd") : newStartDateStr;

                    const hasChanged = successorTask.start_date !== newStartDateStr || successorTask.end_date !== newEndDateStr;

                    if (hasChanged) {
                        const updateData = { start_date: newStartDateStr, end_date: newEndDateStr };
                        updates.push({ id: successorId, data: updateData });
                        
                        const updatedSuccessor = { ...successorTask, ...updateData };
                        taskMap.set(successorId, updatedSuccessor);

                        // Update resource calendar
                        if (updatedSuccessor.assigned_to) {
                            let hoursToSchedule = successorTotalHours;
                            let currentSchedulingDay = new Date(newStartDate);
                            let isFirstDay = true;

                            while (hoursToSchedule > 0) {
                                if (projectSettings.isWorkingDay(currentSchedulingDay)) {
                                    const key = `${updatedSuccessor.assigned_to}-${format(currentSchedulingDay, 'yyyy-MM-dd')}`;
                                    const hoursAlreadyOnCalendar = resourceCalendar.get(key) || 0;
                                    
                                    let capacityForTaskOnDay;
                                    if (isFirstDay) {
                                        capacityForTaskOnDay = Math.max(0, projectSettings.hoursPerDay - startHourOffset);
                                    } else {
                                        capacityForTaskOnDay = projectSettings.hoursPerDay;
                                    }

                                    const hoursToApplyToCalendar = Math.min(hoursToSchedule, capacityForTaskOnDay);
                                    const remainingCapacity = Math.max(0, projectSettings.hoursPerDay - hoursAlreadyOnCalendar);
                                    const actualHoursToAdd = Math.min(hoursToApplyToCalendar, remainingCapacity);

                                    if (actualHoursToAdd > 0) {
                                        resourceCalendar.set(key, hoursAlreadyOnCalendar + actualHoursToAdd);
                                        hoursToSchedule -= actualHoursToAdd;
                                    }
                                    
                                    isFirstDay = false;
                                }
                                
                                if (hoursToSchedule > 0) {
                                    currentSchedulingDay = addDays(currentSchedulingDay, 1);
                                } else {
                                    break;
                                }
                            }
                        }

                        customLog('Cascading date update with resource constraint', {
                            predecessor: predecessor.title || predecessor.id,
                            successor: successorTask.title || successorTask.id,
                            newStart: newStartDateStr,
                            newEnd: newEndDateStr,
                            resourceId: successorTask.assigned_to,
                            startHourOffset: startHourOffset,
                        });
                    }
                    
                    queue.push(successorId);
                } catch (error) {
                    console.error(`Error processing successor ${successorId}:`, error);
                    customLog(`Error processing successor ${successorId}`, { error: error.message });
                }
            }
        } catch (error) {
            console.error(`Error processing task ${currentTaskId}:`, error);
            customLog(`Error processing task ${currentTaskId}`, { error: error.message });
        }
    }
    
    customLog('recalculateLinkedTaskDates finished', { updates });
    return updates;
  };

  const handleRefreshAllLinkedTasks = async () => {
    customLog("Manual refresh of all linked tasks initiated.");
    // Set a loading state to give user feedback
    const allTaskIds = new Set(tasks.map(t => t.id));
    setUpdatingTasks(allTaskIds);

    try {
        const allUpdatesMap = new Map();
        let currentTasksState = [...tasks]; // Start with the current state

        // Find all tasks that are at the beginning of any dependency chain
        // These are tasks that don't have any predecessors
        const chainStarters = tasks.filter(t => !t.predecessor_links || t.predecessor_links.length === 0);

        customLog("Found chain starter tasks to process", { count: chainStarters.length, titles: chainStarters.map(t=>t.title) });

        // Process each dependency chain starting from its root
        for (const startTask of chainStarters) {
            const project = projects.find(p => p.id === startTask.project_id);
            const projectSettings = {
                hoursPerDay: getHoursPerDay(project),
                isWorkingDay: (date) => isWorkingDay(date, project),
            };

            // Run the cascade calculation. It's crucial to pass the progressively updated `currentTasksState`
            // so that calculations for one chain can correctly see the results from a previous one.
            const updates = await recalculateLinkedTaskDates(startTask, currentTasksState, projectSettings);

            if (updates.length > 0) {
                // Merge updates into our main map
                updates.forEach(update => {
                    const existingData = allUpdatesMap.get(update.id) || {};
                    allUpdatesMap.set(update.id, { ...existingData, ...update.data });
                });

                // Apply updates to the temporary state for the next iteration
                const tempUpdateMap = new Map(updates.map(u => [u.id, u.data]));
                currentTasksState = currentTasksState.map(t => tempUpdateMap.has(t.id) ? { ...t, ...tempUpdateMap.get(t.id) } : t);
            }
        }

        const finalUpdates = Array.from(allUpdatesMap.entries()).map(([id, data]) => ({ id, data }));

        if (finalUpdates.length > 0) {
            customLog('Applying bulk updates from linked task refresh', { count: finalUpdates.length, updates: finalUpdates });
            await handleBulkUpdate(finalUpdates);
            safeUpdateTasksAndRecordHistory(currentTasksState); // Changed to safeUpdateTasksAndRecordHistory // Update UI with the final state
        } else {
            customLog('No linked task updates were necessary.');
        }

        // Show a success toast
        const toastDiv = document.createElement('div');
        toastDiv.textContent = 'Linked tasks refreshed successfully!';
        toastDiv.className = 'fixed top-4 right-4 bg-green-500 text-white px-4 py-2 rounded shadow-lg z-50';
        document.body.appendChild(toastDiv);
        setTimeout(() => document.body.removeChild(toastDiv), 3000);

    } catch (error) {
        console.error("Error during manual linked task refresh:", error);
        customLog("Error refreshing linked tasks", { error: error.message });
    } finally {
        setUpdatingTasks(new Set()); // Clear loading state
    }
  };


  const handleTaskSubmit = async (taskData) => {
    console.log('🚀 Dashboard: handleTaskSubmit - START', { 
      taskData: { ...taskData },
      isSubmitting,
      showTaskForm 
    });
    
    customLog('handleTaskSubmit start', { taskData });
    
    // Prevent multiple submissions
    if (isSubmitting) {
      console.log('⏳ Dashboard: Already submitting, ignoring duplicate submit');
      return Promise.reject(new Error('Already submitting, please wait'));
    }
    
    try {
      let processedTaskData = { ...taskData };
      
      // New: If status is 'completed', set actual_end_date and progress
      if (processedTaskData.status === 'completed' && !processedTaskData.actual_end_date) {
        processedTaskData.actual_end_date = format(new Date(), 'yyyy-MM-dd');
        processedTaskData.progress = 100;
        console.log('✅ Dashboard: Task completed. Set actual_end_date and progress.', {
            actual_end_date: processedTaskData.actual_end_date
        });
        customLog('Task marked as completed', { taskId: processedTaskData.id, title: processedTaskData.title });
      }
      
      const hasChildren = tasks.some(t => t.parent_task_id === processedTaskData.id);

      console.log('📊 Dashboard: Processing task data', { 
        hasChildren,
        currentTasksCount: tasks.length 
      });

      // Calculate end date based on duration and working days/hours
      if (processedTaskData.start_date && (processedTaskData.duration_days > 0 || processedTaskData.duration_hours > 0) && !hasChildren) {
          const startDate = parseISO(processedTaskData.start_date);
          if (isValid(startDate)) {
              const project = projects.find(p => p.id === processedTaskData.project_id);
              const projectSettings = {
                  hoursPerDay: getHoursPerDay(project),
                  isWorkingDay: (date) => isWorkingDay(date, project),
              };

              const totalHours = (processedTaskData.duration_days * projectSettings.hoursPerDay) + (processedTaskData.duration_hours || 0);
              
              console.log('📅 Dashboard: Calculating end date', { 
                startDate: processedTaskData.start_date,
                totalHours,
                projectSettings 
              });
              
              if (totalHours > 0) {
                  const newEndDate = addWorkingHours(startDate, totalHours, projectSettings);
                  const finalEndDate = addHours(newEndDate, -0.01);

                  if (isValid(finalEndDate) && finalEndDate >= startDate) {
                      processedTaskData.end_date = format(finalEndDate, "yyyy-MM-dd");
                      console.log('✅ Dashboard: End date calculated', { endDate: processedTaskData.end_date });
                  } else {
                      // Fallback: if calculation fails, set end date to start date
                      processedTaskData.end_date = processedTaskData.start_date;
                      console.log('⚠️ Dashboard: End date fallback to start date');
                  }
              } else {
                  // Zero duration task - end date same as start date
                  processedTaskData.end_date = processedTaskData.start_date;
                  console.log('⚠️ Dashboard: Zero duration, end date = start date');
              }
          }
      } else if (processedTaskData.start_date && !processedTaskData.end_date) {
          // If no end date and no duration, set end date to start date
          processedTaskData.end_date = processedTaskData.start_date;
          console.log('📅 Dashboard: No duration specified, end date = start date');
      }

      // Validate that end date is not before start date
      if (processedTaskData.start_date && processedTaskData.end_date) {
          const startDate = parseISO(processedTaskData.start_date);
          const endDate = parseISO(processedTaskData.end_date);
          
          if (isValid(startDate) && isValid(endDate) && endDate < startDate) {
              console.log('⚠️ Dashboard: End date before start date, correcting', {
                  original_start: processedTaskData.start_date,
                  original_end: processedTaskData.end_date,
              });
              customLog('End date before start date, correcting', {
                  original_start: processedTaskData.start_date,
                  original_end: processedTaskData.end_date,
                  corrected_end: processedTaskData.start_date
              });
              processedTaskData.end_date = processedTaskData.start_date;
          }
      }

      console.log('🔍 Dashboard: Checking for conflicts');
      const conflict = checkForConflict(processedTaskData);
      if (conflict) {
        console.log('⚠️ Dashboard: Conflict detected, showing modal');
        setConflictData({ newTask: processedTaskData, ...conflict });
        setShowConflictModal(true);
        return Promise.resolve(); // Return resolved promise, not rejection
      }

      console.log('💾 Dashboard: No conflicts, proceeding to save task');
      
      // Save the task and get the final version from the API
      const savedTask = await saveTask(processedTaskData);
      console.log('✅ Dashboard: Task saved successfully', { savedTask: savedTask ? { id: savedTask.id, title: savedTask.title } : null });
      
      if (!savedTask) {
        console.log('❌ Dashboard: Save task returned null, rejecting');
        throw new Error('Task save failed - API returned null');
      }

      // Update the local state with the canonical saved task
      const currentTasksInHistory = history[historyIndex] || [];
      let newTasksList = taskData.id
        ? currentTasksInHistory.map(t => t.id === savedTask.id ? savedTask : t)
        : [...currentTasksInHistory, savedTask];

      console.log('🔄 Dashboard: Running cascading parent update');
      // Cascade parent updates first
      newTasksList = await runCascadingParentUpdate(savedTask, newTasksList);

      // Then, cascade dependency updates
      const currentSavedTask = newTasksList.find(t => t.id === savedTask.id) || savedTask;

      const projectForDependency = projects.find(p => p.id === currentSavedTask.project_id);
      const projectSettingsForDependency = {
          hoursPerDay: getHoursPerDay(projectForDependency),
          isWorkingDay: (date) => isWorkingDay(date, projectForDependency),
      };
      
      console.log('🔗 Dashboard: Running dependency cascade');
      const dependencyUpdates = await recalculateLinkedTaskDates(currentSavedTask, newTasksList, projectSettingsForDependency);

      if (dependencyUpdates.length > 0) {
          console.log('🔗 Dashboard: Applying dependency updates', { count: dependencyUpdates.length });
          await handleBulkUpdate(dependencyUpdates);
          // Refresh local state with dependency updates
          const dependencyUpdatesMap = new Map(dependencyUpdates.map(u => [u.id, u.data]));
          newTasksList = newTasksList.map(t => dependencyUpdatesMap.has(t.id) ? { ...t, ...dependencyUpdatesMap.get(t.id) } : t);
      }

      // Final state update with all changes
      console.log('📊 Dashboard: Updating tasks and recording history');
      safeUpdateTasksAndRecordHistory(newTasksList); // Changed to safeUpdateTasksAndRecordHistory

      // CRUCIAL: Always close the task form after successful save
      console.log('🎯 Dashboard: Closing task form and clearing selection');
      setShowTaskForm(false);
      setSelectedTask(null);
      setShowConflictModal(false);

      // Dispatch events for other components
      if (!taskData.id) {
        // New task created
        // NEW: Expand parent to show the new subtask
        if (savedTask.parent_task_id) {
            setExpandedTasks(prev => new Set(prev).add(savedTask.parent_task_id));
        }
        console.log('📢 Dashboard: Dispatching taskCreated event');
        setTimeout(() => {
          window.dispatchEvent(new CustomEvent("taskCreated", {
            detail: {
              newTask: savedTask,
            }
          }));
        }, 100);
      } else {
        // Existing task updated
        console.log('📢 Dashboard: Dispatching refreshTaskView event');
        setTimeout(() => {
          window.dispatchEvent(new CustomEvent("refreshTaskView", {
            detail: { reason: "taskUpdated" }
          }));
        }, 100);
      }

      console.log('✅ Dashboard: handleTaskSubmit - SUCCESS');
      customLog('handleTaskSubmit end');
      return Promise.resolve(savedTask); // Explicitly return a resolved promise
      
    } catch (error) {
      console.error('❌ Dashboard: Error in handleTaskSubmit:', {
        error,
        message: error?.message || 'No message',
        stack: error?.stack || 'No stack',
        fullError: JSON.stringify(error, Object.getOwnPropertyNames(error))
      });
      customLog('handleTaskSubmit error', { error: error.message });
      
      // Even on error, we should close the form to prevent getting stuck
      console.log('🎯 Dashboard: Closing task form due to error');
      setShowTaskForm(false);
      setSelectedTask(null);
      
      // Re-throw the error so the TaskForm can handle it properly
      throw error;
    }
  };

  // Enhanced debounced task update with immediate UI updates and proper cancellation
  const debouncedTaskUpdate = useCallback(
    debounceWithCancel(async (taskData) => {
      // Add comprehensive validation at the start
      if (!taskData) {
        console.error('debouncedTaskUpdate: taskData is null/undefined');
        customLog('debouncedTaskUpdate: taskData is null/undefined', { taskData });
        return;
      }

      if (!taskData.id) {
        console.error('debouncedTaskUpdate: taskData.id is null/undefined', taskData);
        customLog('debouncedTaskUpdate: taskData.id is null/undefined', { taskData });
        return;
      }

      console.log('🔄 debouncedTaskUpdate: Processing task update', {
        taskId: taskData.id,
        title: taskData.title,
        editedField: taskData.__editedField,
        assigned_to: taskData.assigned_to
      });

      customLog('debouncedTaskUpdate executing with:', taskData);

      setUpdatingTasks(prev => new Set(prev.add(taskData.id))); // Add visual feedback

      try {
        let processedTaskData = { ...taskData };

        // IMMEDIATE UI UPDATE: Update the task in the UI first for responsiveness
        const currentTasksInHistory = history[historyIndex] || [];
        
        // Validate current tasks in history
        const validCurrentTasks = currentTasksInHistory.filter(t => {
          if (!t) {
            console.warn('debouncedTaskUpdate: Found null task in history');
            return false;
          }
          if (!t.id) {
            console.warn('debouncedTaskUpdate: Found task without ID in history:', t);
            return false;
          }
          return true;
        });

        const immediateUpdatedTasks = validCurrentTasks.map(t => 
          t.id === processedTaskData.id ? { ...t, ...processedTaskData } : t
        );
        
        safeUpdateTasksAndRecordHistory(immediateUpdatedTasks);
        console.log('✅ debouncedTaskUpdate: Applied immediate UI update for task:', processedTaskData.id);

        // Save to API to get the canonical task data
        const savedTask = await saveTask(processedTaskData);
        if (!savedTask) throw new Error("Task save failed, API returned null.");
        
        console.log('✅ debouncedTaskUpdate: Task saved successfully via API', {
          savedTaskId: savedTask.id,
          savedTaskTitle: savedTask.title,
          savedTaskAssignment: savedTask.assigned_to
        });

        // Create base task list with the API response (canonical data)
        let baseTasks = immediateUpdatedTasks.map(t => t.id === savedTask.id ? savedTask : t);

        // Run the cascading update logic for parents with validation
        try {
          baseTasks = await runCascadingParentUpdate(savedTask, baseTasks);
        } catch (error) {
          console.error('Error in runCascadingParentUpdate:', error);
          customLog('Error in runCascadingParentUpdate', { error: error.message, savedTask });
        }

        // Final state update
        safeUpdateTasksAndRecordHistory(baseTasks);
        console.log('✅ debouncedTaskUpdate: Final state updated with', { tasksCount: baseTasks.length });

      } catch (error) {
        console.error("❌ debouncedTaskUpdate: Error updating task:", error);
        customLog("debouncedTaskUpdate: Error updating task:", { error: error.message, taskData });
        
        // On any error, reload from the database to ensure consistency
        console.log('🔄 debouncedTaskUpdate: Reloading data due to error');
        await loadData();
      } finally {
        setUpdatingTasks(prev => {
          const newSet = new Set(prev);
          newSet.delete(taskData.id);
          return newSet;
        });
      }
    }, 500), // 500ms debounce
    [tasks, history, historyIndex, resources, projects, safeUpdateTasksAndRecordHistory, workingDays, hoursPerDay, saveTask, loadData, runCascadingParentUpdate]
  );

  // Update the ref when the debounced function changes
  useEffect(() => {
    debouncedUpdateRef.current = debouncedTaskUpdate;
  }, [debouncedTaskUpdate]);

  const handleTaskUpdate = (taskData) => {
    console.log('🎯 Dashboard: handleTaskUpdate called from GanttChart', {
      taskData,
      taskId: taskData?.id,
      editedField: taskData?.__editedField,
      hasId: !!taskData?.id,
      isObject: typeof taskData === 'object'
    });
    
    try {
      // Comprehensive validation
      if (!taskData) {
        throw new Error('handleTaskUpdate: taskData is null/undefined');
      }
      
      if (!taskData.id) {
        throw new Error(`handleTaskUpdate: taskData.id is null/undefined. TaskData: ${JSON.stringify(taskData)}`);
      }
      
      if (typeof taskData.id !== 'string') {
        throw new Error(`handleTaskUpdate: taskData.id is not a string. Type: ${typeof taskData.id}, Value: ${taskData.id}`);
      }

      // Validate tasks array
      if (!Array.isArray(tasks)) {
        throw new Error(`handleTaskUpdate: tasks is not an array. Type: ${typeof tasks}`);
      }

      // Find the task with enhanced error checking
      const existingTask = tasks.find(t => {
        if (!t) {
          console.warn('Found null/undefined task in tasks array');
          return false;
        }
        if (!t.id) {
          console.warn('Found task without id:', t);
          return false;
        }
        return t.id === taskData.id;
      });

      if (!existingTask) {
        const availableIds = tasks.filter(t => t && t.id).map(t => t.id);
        throw new Error(`handleTaskUpdate: Task ${taskData.id} not found. Available IDs: ${availableIds.join(', ')}`);
      }
      
      console.log('✅ Dashboard: Task found, processing update', {
        taskId: existingTask.id,
        taskTitle: existingTask.title,
        updateFields: Object.keys(taskData).filter(k => k !== 'id')
      });
      
      customLog('handleTaskUpdate called from GanttChart with:', taskData);
      
      // CRITICAL FIX: Create a proper merge that preserves all existing task properties
      const mergedTaskData = {
        ...existingTask, // Start with ALL existing properties
        ...taskData,     // Only override with the specific changes
        // Ensure critical fields are never lost
        id: existingTask.id,
        title: taskData.title !== undefined ? taskData.title : existingTask.title,
        parent_task_id: taskData.parent_task_id !== undefined ? taskData.parent_task_id : existingTask.parent_task_id,
        sort_order: taskData.sort_order !== undefined ? taskData.sort_order : existingTask.sort_order,
        project_id: taskData.project_id !== undefined ? taskData.project_id : existingTask.project_id,
      };

      console.log('🔄 Dashboard: Merged task data', {
        original: {
          id: existingTask.id,
          title: existingTask.title,
          parent_task_id: existingTask.parent_task_id,
          assigned_to: existingTask.assigned_to
        },
        updates: taskData,
        merged: {
          id: mergedTaskData.id,
          title: mergedTaskData.title,
          parent_task_id: mergedTaskData.parent_task_id,
          assigned_to: mergedTaskData.assigned_to
        }
      });
      
      // Cancel any pending debounced update
      if (debouncedUpdateRef.current && typeof debouncedUpdateRef.current.cancel === 'function') {
        debouncedUpdateRef.current.cancel();
        customLog('Cancelled previous debounced update');
      }
      
      // Set the __editedField flag
      if (taskData.duration_days !== undefined || taskData.duration_hours !== undefined) {
        mergedTaskData.__editedField = 'duration_days';
      } else if (taskData.start_date !== undefined) {
        mergedTaskData.__editedField = 'start_date';
      } else if (taskData.end_date !== undefined) {
        mergedTaskData.__editedField = 'end_date';
      } else if (taskData.assigned_to !== undefined) {
        mergedTaskData.__editedField = 'assigned_to';
      }
      
      console.log('🚀 Dashboard: Calling debouncedTaskUpdate with merged data', {
        taskId: mergedTaskData.id,
        editedField: mergedTaskData.__editedField
      });
      
      if (typeof debouncedTaskUpdate !== 'function') {
        throw new Error('debouncedTaskUpdate is not a function');
      }
      
      debouncedTaskUpdate(mergedTaskData);
      console.log('✅ Dashboard: debouncedTaskUpdate called successfully');
      
    } catch (error) {
      console.error('❌ Dashboard: Error in handleTaskUpdate:', {
        error,
        message: error?.message || 'No message',
        stack: error?.stack || 'No stack',
        taskData
      });
      
      customLog('handleTaskUpdate: Error occurred', {
        error: error.message,
        taskId: taskData?.id || 'unknown',
        stack: error.stack
      });
      
      // Set error state to show user-friendly error
      setHasError(true);
      setErrorDetails({
        message: `Error updating task: ${error.message}`,
        stack: error.stack,
        timestamp: new Date().toISOString(),
        context: 'handleTaskUpdate',
        taskData
      });
    }
  };

  const handleConflictResolved = async (resolvedTaskData) => {
    const savedTask = await saveTask(resolvedTaskData);
    if (!savedTask) return; // Stop if saving failed

    const currentTasksInHistory = history[historyIndex] || [];
    const newTasks = currentTasksInHistory.map(t => t.id === savedTask.id ? savedTask : t);

    // NEW: Use the new cascading update function
    const updatedTasksAfterParentCascade = await runCascadingParentUpdate(savedTask, newTasks);

    // Then, cascade dependency updates
    const currentSavedTask = updatedTasksAfterParentCascade.find(t => t.id === savedTask.id) || savedTask;
    const projectForDependency = projects.find(p => p.id === currentSavedTask.project_id);
    const projectSettingsForDependency = {
        hoursPerDay: getHoursPerDay(projectForDependency),
        isWorkingDay: (date) => isWorkingDay(date, projectForDependency),
    };
    const dependencyUpdates = await recalculateLinkedTaskDates(currentSavedTask, updatedTasksAfterParentCascade, projectSettingsForDependency);

    let finalTasksState = updatedTasksAfterParentCascade;
    if (dependencyUpdates.length > 0) {
        await handleBulkUpdate(dependencyUpdates);
        const dependencyUpdatesMap = new Map(dependencyUpdates.map(u => [u.id, u.data]));
        finalTasksState = updatedTasksAfterParentCascade.map(t => dependencyUpdatesMap.has(t.id) ? { ...t, ...dependencyUpdatesMap.get(t.id) } : t);
    }
    
    safeUpdateTasksAndRecordHistory(finalTasksState); // Changed to safeUpdateTasksAndRecordHistory
    setShowConflictModal(false);
  };

  const handleTaskCancel = () => {
    setShowTaskForm(false);
    setSelectedTask(null);
  };

  const handleProjectChange = (projectId) => {
    setSelectedProject(projectId === "all" ? null : projectId);
  };

  const handleAutoSave = async (taskData) => {
    // This can be used for localStorage drafts or other non-API saving
  };

  const handleDeleteTask = async (taskId) => {
    customLog('handleDeleteTask start', { taskId });
    // Validate taskId before proceeding to prevent /undefined API calls
    if (!taskId) {
      console.error("Invalid task ID for deletion:", taskId);
      customLog("Error: Invalid task ID for deletion", { taskId });
      return;
    }

    const taskToDelete = tasks.find(t => t.id === taskId);
    if (!taskToDelete) return;
    const parentId = taskToDelete.parent_task_id;

    const allTasksCopy = [...tasks];
    const toDelete = new Set([taskId]);

    const findChildren = (parentId) => {
      allTasksCopy
        .filter(t => t.parent_task_id === parentId)
        .forEach(child => {
          // Ensure child.id is valid before adding to the delete set
          if (child && child.id) {
            toDelete.add(child.id);
            findChildren(child.id);
          }
        });
    };
    findChildren(taskId);

    // Optimistic UI Update and record history
    const newTasksAfterDeletion = tasks.filter(t => !toDelete.has(t.id));
    safeUpdateTasksAndRecordHistory(newTasksAfterDeletion); // Changed to safeUpdateTasksAndRecordHistory

    try {
      // Filter out any undefined or invalid IDs just in case
      const validIds = Array.from(toDelete).filter(id => id);

      if (validIds.length > 0) {
        // Delete tasks with delays to avoid rate limiting
        for (let i = 0; i < validIds.length; i++) {
          await Task.delete(validIds[i]);
          if (i < validIds.length - 1) {
            await new Promise(resolve => setTimeout(resolve, 250));
          }
        }
      }

      // After deletion, recalculate the parent of the deleted task
      if (parentId) {
        const parentTask = newTasksAfterDeletion.find(t => t.id === parentId);
        if (parentTask) {
          await runCascadingParentUpdate(parentTask, newTasksAfterDeletion);
        }
      }

      window.dispatchEvent(new CustomEvent("taskDeleted", { detail: { taskId } }));
    } catch (error) {
      console.error("Error deleting tasks:", error);
      customLog("Error deleting tasks", { error: error.message, taskId });
      if (error.response?.status === 429) {
        // No alert needed, rate limited
      }
      loadData(); // Rollback on error
    }
    customLog('handleDeleteTask end');
  };

  const handleDuplicateTask = async (taskId) => {
    customLog('handleDuplicateTask start', { taskId });
    const taskToDuplicate = tasks.find(t => t.id === taskId);
    if (!taskToDuplicate) return;

    let newTasksAccumulator = [...tasks]; // Create a mutable copy of current tasks

    // Recursive function to duplicate a task and its children, preserving links
    const duplicateRecursively = async (originalTaskId, newParentId, currentTasksAcc, taskIdMapping = new Map()) => {
      const originalTask = tasks.filter(t => t.id === originalTaskId)[0]; // Find from original tasks state
      if (!originalTask) return null;

      // Find siblings to determine new sort order and generate a unique name
      // Filter against `currentTasksAcc` to get correct max sort order in new context
      const siblingsInNewContext = currentTasksAcc.filter(t => t.parent_task_id === newParentId);
      const maxSortOrder = Math.max(-1, ...siblingsInNewContext.map(s => s.sort_order || 0)); // Use -1 to handle empty list

      let copyNumber = 1;
      let newTitle;
      do {
        newTitle = `${originalTask.title} (Copy ${copyNumber})`;
        copyNumber++;
      } while (newTasksAccumulator.some(s => s.title === newTitle)); // Check against the entire accumulator to avoid naming conflicts

      const newTaskData = {
        ...originalTask,
        parent_task_id: newParentId,
        title: newTitle,
        sort_order: maxSortOrder + 1,
        // Clear fields that should be unique or regenerated
        predecessor_links: [], // Will be set later based on mapping
        successor_links: [], // Will be set later based on mapping
      };

      // Remove fields that should be unique or regenerated
      delete newTaskData.id;
      delete newTaskData.created_date;
      delete newTaskData.updated_date;

      const newDuplicatedTask = await Task.create(newTaskData);
      currentTasksAcc.push(newDuplicatedTask);

      // Store the mapping between old and new task IDs
      taskIdMapping.set(originalTaskId, newDuplicatedTask.id);

      // Duplicate children recursively
      const children = tasks.filter(t => t.parent_task_id === originalTaskId); // Use 'tasks' (current state) for original children
      for (let i = 0; i < children.length; i++) {
        if (i > 0) {
          await new Promise(resolve => setTimeout(resolve, 250));
        }
        await duplicateRecursively(children[i].id, newDuplicatedTask.id, currentTasksAcc, taskIdMapping);
      }

      return newDuplicatedTask;
    };

    try {
      const taskIdMapping = new Map();
      await duplicateRecursively(taskId, taskToDuplicate.parent_task_id, newTasksAccumulator, taskIdMapping);

      // Now recreate the links within the duplicated task tree
      const linksToUpdate = [];

      for (const [originalTaskId, newTaskId] of taskIdMapping.entries()) {
        const originalTask = tasks.filter(t => t.id === originalTaskId)[0];
        if (!originalTask) continue;

        const newPredecessorLinks = [];
        const newSuccessorLinks = [];

        // Map predecessor links if they exist within the duplicated tree
        if (originalTask.predecessor_links) {
          originalTask.predecessor_links.forEach(predId => {
            if (taskIdMapping.has(predId)) {
              newPredecessorLinks.push(taskIdMapping.get(predId));
            }
          });
        }

        // Map successor links if they exist within the duplicated tree
        if (originalTask.successor_links) {
          originalTask.successor_links.forEach(succId => {
            if (taskIdMapping.has(succId)) {
              newSuccessorLinks.push(taskIdMapping.get(succId));
            }
          });
        }

        // Only update if there are links to set
        if (newPredecessorLinks.length > 0 || newSuccessorLinks.length > 0) {
          linksToUpdate.push({
            taskId: newTaskId,
            predecessor_links: newPredecessorLinks,
            successor_links: newSuccessorLinks
          });
        }
      }

      // Update all the links
      for (let i = 0; i < linksToUpdate.length; i++) {
        if (i > 0) {
          await new Promise(resolve => setTimeout(resolve, 250));
        }
        const { taskId, predecessor_links, successor_links } = linksToUpdate[i];
        await Task.update(taskId, { predecessor_links, successor_links });

        // Update the local state
        const taskIndex = newTasksAccumulator.findIndex(t => t.id === taskId);
        if (taskIndex !== -1) {
          newTasksAccumulator[taskIndex] = {
            ...newTasksAccumulator[taskIndex],
            predecessor_links,
            successor_links
          };
        }
      }

      // After duplicating and linking, run recalculations on the parent
      const parentTask = newTasksAccumulator.find(t => t.id === taskToDuplicate.parent_task_id);
      if (parentTask) {
        await runCascadingParentUpdate(parentTask, newTasksAccumulator);
      } else {
        // If it was a root task, we don't need to cascade. Just update state.
        safeUpdateTasksAndRecordHistory(newTasksAccumulator); // Changed to safeUpdateTasksAndRecordHistory
      }

      // After duplicating, expand the parent to make the new task visible
      if (taskToDuplicate.parent_task_id) {
        setExpandedTasks(prev => new Set(prev).add(taskToDuplicate.parent_task_id));
      }
    } catch (error) {
      console.error("Error duplicating task:", error);
      customLog("Error duplicating task", { error: error.message, taskId });
      if (error.response?.status === 429) {
        // Rate limit error - no alert needed
      }
      loadData(); // Revert on error
    }
    customLog('handleDuplicateTask end');
  };

  const handleOutdentTask = async (task) => {
    customLog('handleOutdentTask start', { task });
    if (!task.parent_task_id) return; // Cannot outdent root-level tasks

    const oldParentId = task.parent_task_id;
    const parentTask = tasks.find(t => t.id === oldParentId);
    const newParentId = parentTask?.parent_task_id || null; // Grandparent or root

    try {
      // Calculate new sort_order for the outdented task
      const currentNewSiblings = tasks.filter(t => t.parent_task_id === newParentId);
      const newSortOrder = currentNewSiblings.length; // Place at the end of the new sibling group

      const updatedTaskData = { parent_task_id: newParentId, sort_order: newSortOrder };
      const savedTask = await saveTask({ ...task, ...updatedTaskData });

      let intermediateTasks = tasks.map(t => {
        if (t.id === savedTask.id) {
          return savedTask;
        }
        // Re-adjust sort order of old siblings if needed (gap created)
        if (t.parent_task_id === oldParentId && t.sort_order > task.sort_order) {
          return {...t, sort_order: t.sort_order - 1};
        }
        return t;
      });

      // Recalculate for both parents
      const oldParent = intermediateTasks.find(t => t.id === oldParentId);
      if (oldParent) {
        intermediateTasks = await runCascadingParentUpdate(oldParent, intermediateTasks);
      }
      const newParent = intermediateTasks.find(t => t.id === newParentId);
      if (newParent) {
        intermediateTasks = await runCascadingParentUpdate(newParent, intermediateTasks);
      }

      logHierarchyChange(task, "Outdent", { old_parent_id: oldParentId, new_parent_id: newParentId, old_sort_order: task.sort_order, new_sort_order: newSortOrder });

      // Final state update
      safeUpdateTasksAndRecordHistory(intermediateTasks); // Changed to safeUpdateTasksAndRecordHistory

      // FIXED: Use the new refresh event
      setTimeout(() => {
        window.dispatchEvent(new CustomEvent("refreshTaskView", {
          detail: { reason: "outdentComplete" }
        }));
      }, 100);

    } catch (error) {
      console.error("Error outdenting task:", error);
      customLog("Error outdenting task", { error: error.message, task });
      if (error.response?.status === 429) {
        // No alert needed, rate limited
      }
      loadData(); // Revert on error
    }
    customLog('handleOutdentTask end');
  };

  const handleIndentTask = async (task) => {
    customLog('handleIndentTask start', { task });
    const siblingTasks = tasks
      .filter((t) => t.parent_task_id === task.parent_task_id)
      .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

    const currentIndex = siblingTasks.findIndex((t) => t.id === task.id);

    if (currentIndex > 0) { // Can only indent if there's a preceding sibling
      const newParent = siblingTasks[currentIndex - 1];
      const oldParentId = task.parent_task_id; // Current parent

      try {
        // Calculate new sort_order for the indented task
        const newParentChildren = tasks.filter(t => t.parent_task_id === newParent.id);
        const newSortOrder = newParentChildren.length; // Place at the end of the new children group

        const updatedTaskData = { parent_task_id: newParent.id, sort_order: newSortOrder };
        const savedTask = await saveTask({ ...task, ...updatedTaskData });

        let intermediateTasks = tasks.map(t => {
          if (t.id === savedTask.id) {
            return savedTask;
          }
          // Re-adjust sort order of old siblings (fill the gap)
          if (t.parent_task_id === oldParentId && t.sort_order > task.sort_order) {
            return {...t, sort_order: t.sort_order - 1};
          }
          return t;
        });

        // Recalculate for both parents after hierarchy change
        const oldParent = intermediateTasks.find(t => t.id === oldParentId);
        if(oldParent) {
            intermediateTasks = await runCascadingParentUpdate(oldParent, intermediateTasks);
        }
        const finalNewParent = intermediateTasks.find(t => t.id === newParent.id);
        if(finalNewParent) {
            intermediateTasks = await runCascadingParentUpdate(finalNewParent, intermediateTasks);
        }

        logHierarchyChange(task, "Indent", { old_parent_id: oldParentId, new_parent_id: newParent.id, old_sort_order: task.sort_order, new_sort_order: newSortOrder });

        if (!expandedTasks.has(newParent.id)) {
          setExpandedTasks(prev => new Set(prev).add(newParent.id));
        }

        // Final state update
        safeUpdateTasksAndRecordHistory(intermediateTasks); // Changed to safeUpdateTasksAndRecordHistory

        // FIXED: Use the new refresh event
        setTimeout(() => {
          window.dispatchEvent(new CustomEvent("refreshTaskView", {
            detail: { reason: "indentComplete" }
          }));
        }, 100);

      } catch (error) {
        console.error("Error indenting task:", error);
        customLog("Error indenting task", { error: error.message, task });
        if (error.response?.status === 429) {
          // No alert needed, rate limited
        }
        loadData(); // Revert on error
      }
    }
    customLog('handleIndentTask end');
  };

  const handleUnlinkAllDependencies = async (taskToUnlink) => {
    customLog('handleUnlinkAllDependencies start', { taskToUnlink });
    const updates = [];
    const taskMap = new Map(tasks.map(t => [t.id, t]));
    const updatesMap = new Map(); // To consolidate updates for optimistic UI

    // Find predecessors and update them
    if (taskToUnlink.predecessor_links?.length > 0) {
      taskToUnlink.predecessor_links.forEach(predId => {
        const predecessor = taskMap.get(predId);
        if (predecessor && predecessor.successor_links) {
          const newSuccessorLinks = predecessor.successor_links.filter(id => id !== taskToUnlink.id);
          updates.push({ id: predId, data: { successor_links: newSuccessorLinks } });
          updatesMap.set(predId, { ...(updatesMap.get(predId) || {}), successor_links: newSuccessorLinks });
        }
      });
    }

    // Find successors and update them
    if (taskToUnlink.successor_links?.length > 0) {
      taskToUnlink.successor_links.forEach(succId => {
        const successor = taskMap.get(succId);
        if (successor && successor.predecessor_links) {
          const newPredecessorLinks = successor.predecessor_links.filter(id => id !== taskToUnlink.id);
          updates.push({ id: succId, data: { predecessor_links: newPredecessorLinks } });
          updatesMap.set(succId, { ...(updatesMap.get(succId) || {}), predecessor_links: newPredecessorLinks });
        }
      });
    }

    // Update the task itself to have no links
    updates.push({ id: taskToUnlink.id, data: { predecessor_links: [], successor_links: [] } });
    updatesMap.set(taskToUnlink.id, { ...(updatesMap.get(taskToUnlink.id) || {}), predecessor_links: [], successor_links: [] });

    // Apply updates optimistically for UI, then save to API
    const optimisticTasks = tasks.map(t => {
        const updateData = updatesMap.get(t.id);
        return updateData ? { ...t, ...updateData } : t;
    });

    await handleBulkUpdate(updates);
    safeUpdateTasksAndRecordHistory(optimisticTasks); // Changed to safeUpdateTasksAndRecordHistory
    customLog('handleUnlinkAllDependencies end');
  };

  const handleTaskReparent = async (taskId, newParentId) => {
    customLog('handleTaskReparent start', { taskId, newParentId });
    const taskMap = new Map(tasks.map(t => [t.id, { ...t }]));
    const movedTask = taskMap.get(taskId);

    if (!movedTask || movedTask.parent_task_id === newParentId) {
      return; // No change needed
    }

    if (newParentId) {
      let parentIdToCheck = newParentId;
      while (parentIdToCheck) {
        if (parentIdToCheck === taskId) {
          console.warn("Attempted to drop task into its own descendant.");
          customLog("Warning: Attempted to drop task into its own descendant.", { taskId, newParentId });
          return;
        }
        const parentTask = taskMap.get(parentIdToCheck);
        parentIdToCheck = parentTask ? parentTask.parent_task_id : null;
      }
    }

    const oldParentId = movedTask.parent_task_id;
    const updates = [];

    // Recalculate sort orders for old siblings
    const oldSiblings = tasks.filter(t => t.parent_task_id === oldParentId && t.id !== taskId)
      .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

    oldSiblings.forEach((task, index) => {
      if (task.sort_order !== index) {
        updates.push({ id: task.id, data: { sort_order: index } });
      }
    });

    // Determine sort order for the reparented task in its new group
    const newSiblings = tasks.filter(t => t.parent_task_id === newParentId)
      .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

    // Add the update for the moved task itself
    updates.push({ id: taskId, data: { parent_task_id: newParentId, sort_order: newSiblings.length } }); // Place at end

    logHierarchyChange(movedTask, "Reparent", { old_parent_id: oldParentId, new_parent_id: newParentId, old_sort_order: movedTask.sort_order, new_sort_order: newSiblings.length });

    const finalUpdatesMap = new Map();
    updates.forEach(update => {
        const existing = finalUpdatesMap.get(update.id) || { data: {} };
        finalUpdatesMap.set(update.id, { id: update.id, data: { ...existing.data, ...update.data } });
    });
    const bulkUpdatesToSend = Array.from(finalUpdatesMap.values());

    await handleBulkUpdate(bulkUpdatesToSend); // Apply direct changes to API

    let currentTasksState = tasks.map(t => { // Create local state reflecting initial bulk changes
        const update = finalUpdatesMap.get(t.id);
        return update ? { ...t, ...update.data } : t;
    });

    // Cascade updates for parents
    const oldParent = currentTasksState.find(t => t.id === oldParentId);
    if(oldParent) {
        customLog('handleTaskReparent: Cascading for old parent', { oldParentId });
        currentTasksState = await runCascadingParentUpdate(oldParent, currentTasksState);
    }

    const newParent = currentTasksState.find(t => t.id === newParentId);
    if(newParent && oldParentId !== newParentId) { // Only if new parent is different or existed
        customLog('handleTaskReparent: Cascading for new parent', { newParentId });
        currentTasksState = await runCascadingParentUpdate(newParent, currentTasksState);
    }

    // Explicitly update UI with the final state after all cascades, as per outline structure.
    safeUpdateTasksAndRecordHistory(currentTasksState); // Changed to safeUpdateTasksAndRecordHistory
    customLog('handleTaskReparent end');
  };

  const handleTaskReorder = async (result) => {
    customLog('handleTaskReorder start', { result });
    const { source, destination, draggableId } = result;

    if (!destination) {
      return; // Dropped outside a valid target
    }

    if (source.droppableId === destination.droppableId && source.index === destination.index) {
      return; // No change in position
    }

    const taskMap = new Map(tasks.map(t => [t.id, { ...t }]));
    const movedTask = taskMap.get(draggableId);
    if (!movedTask) return;

    // Prevent dropping a task into one of its own descendants
    let parentIdToCheck = destination.droppableId === 'root' ? null : destination.droppableId;
    while (parentIdToCheck) {
        if (parentIdToCheck === draggableId) {
            customLog("Cannot drop a task into its own descendant.");
            // Optional: show an alert to the user
            return;
        }
        const parentTask = taskMap.get(parentIdToCheck);
        parentIdToCheck = parentTask ? parentTask.parent_task_id : null;
    }

    const updates = [];
    const sourceParentId = source.droppableId === 'root' ? null : source.droppableId;
    const destParentId = destination.droppableId === 'root' ? null : destination.droppableId;

    // Case 1: Reordering within the same parent
    if (sourceParentId === destParentId) {
        const siblings = tasks
            .filter(t => t.parent_task_id === sourceParentId)
            .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

        const [movedItem] = siblings.splice(source.index, 1);
        siblings.splice(destination.index, 0, movedItem);

        siblings.forEach((task, index) => {
            if (task.sort_order !== index) {
                updates.push({ id: task.id, data: { sort_order: index } });
            }
        });
    } else { // Case 2: Moving to a different parent (reparenting)
        // Update sort order for the old sibling group
        const oldSiblings = tasks
            .filter(t => t.parent_task_id === sourceParentId && t.id !== draggableId)
            .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

        oldSiblings.forEach((task, index) => {
            if (task.sort_order !== index) {
                updates.push({ id: task.id, data: { sort_order: index } });
            }
        });

        // Update the moved task and its new sibling group
        const newSiblings = tasks
            .filter(t => t.parent_task_id === destParentId)
            .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

        // Note: movedTask is from the original `tasks` array.
        newSiblings.splice(destination.index, 0, movedTask);

        newSiblings.forEach((task, index) => {
            if (task.id === draggableId) {
                // This is the moved task
                updates.push({ id: draggableId, data: { parent_task_id: destParentId, sort_order: index } });
            } else {
                // This is an existing sibling in the new group
                if (task.sort_order !== index) {
                    updates.push({ id: task.id, data: { sort_order: index } });
                }
            }
        });
    }

    if (updates.length > 0) {
        // Consolidate updates to ensure each task is updated only once
        const finalUpdatesMap = new Map();
        updates.forEach(update => {
            const existing = finalUpdatesMap.get(update.id) || { data: {} };
            finalUpdatesMap.set(update.id, { id: update.id, data: { ...existing.data, ...update.data } });
        });
        const bulkUpdatesToSend = Array.from(finalUpdatesMap.values());

        try {
            await handleBulkUpdate(bulkUpdatesToSend);

            let currentTasksState = tasks.map(t => { // Create local state reflecting initial bulk changes
                const update = finalUpdatesMap.get(t.id);
                return update ? { ...t, ...update.data } : t;
            });
            // Update history only once for the initial reorder/reparent
            safeUpdateTasksAndRecordHistory(currentTasksState); // Changed to safeUpdateTasksAndRecordHistory

            logHierarchyChange(movedTask, 'Reorder/Reparent', {
                old_parent_id: sourceParentId,
                new_parent_id: destParentId,
                old_sort_order: source.index,
                new_sort_order: destination.index,
            });

            // Cascade updates for parents
            const sourceParent = currentTasksState.find(t => t.id === sourceParentId);
            if(sourceParent) {
                customLog('handleTaskReorder: Cascading for source parent', { sourceParentId });
                currentTasksState = await runCascadingParentUpdate(sourceParent, currentTasksState);
            }

            const destParent = currentTasksState.find(t => t.id === destParentId);
            if(destParent && sourceParentId !== destParentId) { // Only if new parent is different or existed
                customLog('handleTaskReorder: Cascading for new parent', { destParentId });
                currentTasksState = await runCascadingParentUpdate(destParent, currentTasksState);
            }

            // Expand the new parent if it was a reparent action
            if (destParentId && !expandedTasks.has(destParentId)) {
                setExpandedTasks(prev => new Set(prev).add(destParentId));
            }

            // Show success feedback
            const toastDiv = document.createElement('div');
            toastDiv.textContent = 'Task order updated successfully';
            toastDiv.className = 'fixed top-4 right-4 bg-green-500 text-white px-4 py-2 rounded shadow-lg z-50';
            document.body.appendChild(toastDiv);
            setTimeout(() => document.body.removeChild(toastDiv), 2000);
        } catch (error) {
            console.error("Error reordering/reparenting task:", error);
            customLog("Error reordering/reparenting task", { error: error.message, result });
            loadData(); // Revert on error
        }
    }
  };

  const handleToggleConflictCheckMode = () => {
    setIsConflictCheckMode(prev => !prev);
    setSelectedResourcesForCheck(new Set());
    if (isConflictCheckMode) {
        customLog("Conflict Check Mode: OFF");
    } else {
        customLog("Conflict Check Mode: ON");
    }
  };

  const handleSelectResourceForCheck = useCallback((resourceId) => {
    if (!isConflictCheckMode) return;

    setSelectedResourcesForCheck(prev => {
        const newSet = new Set(prev);
        if (newSet.has(resourceId)) {
            newSet.delete(resourceId);
            customLog("Resource deselected for conflict check", { resourceId });
        } else {
            newSet.add(resourceId);
            customLog("Resource selected for conflict check", { resourceId });
        }
        return newSet;
    }); // Fixed trailing parenthesis
  }, [isConflictCheckMode]);

  const findNextAvailableSlotForTask = useCallback(async (taskToSchedule, preferredStartDate = new Date()) => {
    customLog('findNextAvailableSlotForTask start', { taskToSchedule: {id: taskToSchedule?.id, title: taskToSchedule?.title}, preferredStartDate: format(preferredStartDate, 'yyyy-MM-dd') });
    // If no resource, or no duration, or not a valid task, return null
    if (!taskToSchedule || !taskToSchedule.id || !taskToSchedule.assigned_to || ((taskToSchedule.duration_days || 0) === 0 && (taskToSchedule.duration_hours || 0) === 0)) {
        customLog('findNextAvailableSlotForTask: Invalid input or no resource/duration. Returning null.', { taskToSchedule });
        return null;
    }

    // Find the ultimate parent task to use its start date as the minimum search date
    let ultimateParent = taskToSchedule;
    const visitedParents = new Set();
    while (ultimateParent.parent_task_id && !visitedParents.has(ultimateParent.id)) {
      visitedParents.add(ultimateParent.id);
      const parentTask = tasks.find(t => t.id === ultimateParent.parent_task_id);
      if (parentTask) {
        ultimateParent = parentTask;
      } else {
        break;
      }
    }

    const resourceId = taskToSchedule.assigned_to;
    const project = projects.find(p => p.id === taskToSchedule.project_id);
    const projectSettings = {
        hoursPerDay: getHoursPerDay(project),
        isWorkingDay: (date) => isWorkingDay(date, project),
    };
    const resourceHourlyCapacity = projectSettings.hoursPerDay;
    const totalTaskHours = (taskToSchedule.duration_days * resourceHourlyCapacity) + (taskToSchedule.duration_hours || 0);

    // Use ultimate parent's start date as minimum, but not earlier than preferred date
    let earliestPotentialStartDate = preferredStartDate;
    if (ultimateParent.start_date) {
      const ultimateParentStartDate = parseISO(ultimateParent.start_date);
      if (isValid(ultimateParentStartDate) && ultimateParentStartDate > earliestPotentialStartDate) {
        earliestPotentialStartDate = ultimateParentStartDate;
      }
    }

    customLog('DEBUG: Ultimate parent constraint', {
      taskTitle: taskToSchedule.title,
      ultimateParentTitle: ultimateParent.title,
      ultimateParentStartDate: ultimateParent.start_date,
      earliestPotentialStartDate: format(earliestPotentialStartDate, 'yyyy-MM-dd')
    });

    // Get all non-ongoing, non-cancelled/completed tasks for this resource, excluding the task we are trying to schedule
    const resourceSchedule = tasks.filter(t =>
        t.assigned_to === resourceId &&
        t.id !== taskToSchedule.id && // Exclude the task itself if it's being rescheduled
        !t.is_ongoing &&
        !["completed", "cancelled"].includes(t.status) &&
        t.start_date && t.end_date
    ).map(t => ({
        ...t,
        start_date_obj: parseISO(t.start_date),
        end_date_obj: parseISO(t.end_date)
    })).sort((a, b) => a.start_date_obj.getTime() - b.start_date_obj.getTime());

    // DEBUG: Log the tasks that are taking up slots for this resource
    customLog('DEBUG: Tasks occupying resource schedule', {
        resourceId,
        resourceName: resources.find(r => r.id === resourceId)?.name || 'N/A',
        scheduledTasks: resourceSchedule.map(t => ({
            title: t.title,
            startDate: t.start_date,
            endDate: t.end_date,
            durationDays: t.duration_days,
            durationHours: t.duration_hours,
            totalHours: (t.duration_days * resourceHourlyCapacity) + (t.duration_hours || 0)
        }))
    });

    
    // Account for predecessors
    if (taskToSchedule.predecessor_links && taskToSchedule.predecessor_links.length > 0) {
        const predEndDates = taskToSchedule.predecessor_links.map(id => {
            const pred = tasks.find(t => t.id === id);
            return pred && (pred.actual_end_date || pred.end_date) ? parseISO(pred.actual_end_date || pred.end_date) : null;
        }).filter(Boolean);
        
        if (predEndDates.length > 0) {
            const latestPredEndDate = new Date(Math.max.apply(null, predEndDates.map(d => d.getTime())));
            // FIX: Start checking FROM the predecessor's end date, not the day after.
            if (latestPredEndDate > earliestPotentialStartDate) {
                earliestPotentialStartDate = latestPredEndDate;
            }
        }
        
        customLog('DEBUG: Predecessor constraints', {
            predecessorLinks: taskToSchedule.predecessor_links,
            predecessorEndDates: predEndDates.map(d => format(d, 'yyyy-MM-dd')),
            earliestStartDueToPrereqs: format(earliestPotentialStartDate, 'yyyy-MM-dd')
        });
    }

    // Ensure earliestPotentialStartDate is a working day
    while (!isWorkingDay(earliestPotentialStartDate, project)) {
      earliestPotentialStartDate = addDays(earliestPotentialStartDate, 1);
    }
    
    let currentSearchDate = new Date(earliestPotentialStartDate);
    const MAX_SEARCH_ATTEMPTS = 365 * 2;

    for (let i = 0; i < MAX_SEARCH_ATTEMPTS; i++) {
        while (!isWorkingDay(currentSearchDate, project)) {
            currentSearchDate = addDays(currentSearchDate, 1);
        }

        // Calculate total hours already allocated on this day for this resource
        let hoursAllocatedOnDay = 0;
        const currentDateStr = format(currentSearchDate, 'yyyy-MM-dd');
        
        for (const scheduledTask of resourceSchedule) {
            if (currentSearchDate >= scheduledTask.start_date_obj && currentSearchDate <= scheduledTask.end_date_obj) {
                // Task overlaps with current date, add its daily allocation
                const taskTotalHours = (scheduledTask.duration_days * resourceHourlyCapacity) + (scheduledTask.duration_hours || 0);
                
                // Calculate working days span for the scheduled task
                let workingDaysSpan = 0;
                let tempDate = new Date(scheduledTask.start_date_obj);
                while (tempDate <= scheduledTask.end_date_obj) {
                    if (isWorkingDay(tempDate, project)) {
                        workingDaysSpan++;
                    }
                    tempDate = addDays(tempDate, 1);
                }
                
                const dailyAllocation = workingDaysSpan > 0 ? (taskTotalHours / workingDaysSpan) : 0;
                hoursAllocatedOnDay += dailyAllocation;
            }
        }
        
        customLog('DEBUG: Daily capacity check', {
            checkDate: currentDateStr,
            hoursAllocated: hoursAllocatedOnDay,
            taskHours: totalTaskHours,
            totalIfAdded: hoursAllocatedOnDay + totalTaskHours,
            capacity: resourceHourlyCapacity,
            hasCapacity: (hoursAllocatedOnDay + totalTaskHours) <= resourceHourlyCapacity
        });

        // Check if there's enough capacity for the new task
        if ((hoursAllocatedOnDay + totalTaskHours) <= resourceHourlyCapacity) {
            customLog('findNextAvailableSlotForTask found slot', { 
                taskToSchedule: taskToSchedule.title, 
                slot: format(currentSearchDate, "yyyy-MM-dd"),
                totalSearchAttempts: i + 1,
                hoursAllocated: hoursAllocatedOnDay,
                taskHours: totalTaskHours,
                capacity: resourceHourlyCapacity
            });
            return currentSearchDate;
        }

        // Not enough capacity, try next day
        currentSearchDate = addDays(currentSearchDate, 1);
    }

    console.warn(`Could not find an available slot for task ${taskToSchedule.title} (ID: ${taskToSchedule.id}) within ${MAX_SEARCH_ATTEMPTS} days.`);
    customLog('findNextAvailableSlotForTask no slot found', { taskToSchedule: taskToSchedule.title, attempts: MAX_SEARCH_ATTEMPTS });
    return null;
  }, [tasks, projects, isWorkingDay, getHoursPerDay, resources]);

  const runConflictCheck = useCallback(async () => {
    customLog('runConflictCheck started');
    if (!isConflictCheckMode || selectedResourcesForCheck.size === 0) {
        customLog('runConflictCheck: Not in conflict check mode or no resources selected.');
        return;
    }

    const resourceIds = Array.from(selectedResourcesForCheck);
    await logGeneric("Conflict Check", { resources: resourceIds, mode: "manual" });

    // Filter tasks for selected resources, excluding ongoing/completed/cancelled tasks, and sort by start date
    const relevantTasks = tasks.filter(t =>
        resourceIds.includes(t.assigned_to) &&
        !['completed', 'cancelled'].includes(t.status) &&
        t.start_date && t.end_date &&
        !t.is_ongoing
    ).sort((a,b) => parseISO(a.start_date).getTime() - parseISO(b.start_date).getTime());

    if (relevantTasks.length === 0) {
        setConflictCheckResults({ conflicts: [], suggestions: {} }); // Set empty results to open modal for "no tasks" message
        setIsConflictResultsModalOpen(true);
        customLog('runConflictCheck: No tasks for selected resources.');
        return;
    }

    const conflicts = [];
    const resourceHourlyCapacity = getHoursPerDay(null);

    // Calculate daily total hours for each resource
    const dailyResourceHours = {}; // { 'YYYY-MM-DD': { resourceId: totalHoursAllocated } }

    relevantTasks.forEach(task => {
        const taskStartDate = parseISO(task.start_date);
        const taskEndDate = parseISO(task.end_date);
        if (!isValid(taskStartDate) || !isValid(taskEndDate)) return;

        const totalTaskHours = (task.duration_days * resourceHourlyCapacity) + (task.duration_hours || 0);

        let workingDaysSpan = 0;
        let tempDate = new Date(taskStartDate);
        while (tempDate.getTime() <= taskEndDate.getTime()) {
            if (isWorkingDay(tempDate, null)) {
                workingDaysSpan++;
            }
            tempDate = addDays(tempDate, 1);
        }

        const dailyDistributedHours = workingDaysSpan > 0 ? (totalTaskHours / workingDaysSpan) : 0;

        // Distribute hours across working days
        let currentDate = new Date(taskStartDate);
        while (currentDate.getTime() <= taskEndDate.getTime()) {
            if (isWorkingDay(currentDate, null)) {
                const dateString = format(currentDate, 'yyyy-MM-dd');
                if (!dailyResourceHours[dateString]) dailyResourceHours[dateString] = {};
                if (!dailyResourceHours[dateString][task.assigned_to]) dailyResourceHours[dateString][task.assigned_to] = 0;

                dailyResourceHours[dateString][task.assigned_to] += dailyDistributedHours;
            }
            currentDate = addDays(currentDate, 1);
        }
    });

    // Identify conflicts based on daily over-allocation
    for (const dateString in dailyResourceHours) {
        for (const resourceId in dailyResourceHours[dateString]) {
            if (dailyResourceHours[dateString][resourceId] > resourceHourlyCapacity) {
                // Find tasks that contribute to this conflict on this day
                const tasksOnConflictingDay = relevantTasks.filter(t =>
                    t.assigned_to === resourceId &&
                    parseISO(t.start_date) <= parseISO(dateString) &&
                    parseISO(t.end_date) >= parseISO(dateString)
                );

                // Add a conflict entry. For simplicity, we just list all tasks involved.
                // The modal will display these tasks and allow suggestions for one of them.
                conflicts.push({
                    resourceId,
                    date: dateString,
                    overallocatedHours: dailyResourceHours[dateString][resourceId] - resourceHourlyCapacity,
                    tasksInvolved: tasksOnConflictingDay
                });
            }
        }
    }

    if (conflicts.length === 0) {
        setConflictCheckResults({ conflicts: [], suggestions: {} }); // Set empty results to open modal for "no conflicts" message
        setIsConflictResultsModalOpen(true);
        customLog('runConflictCheck: No conflicts found.');
        return;
    }

    customLog('runConflictCheck: Conflicts found', { conflicts: conflicts.map(c => ({...c, tasksInvolved: c.tasksInvolved.map(t=>t.id)})) });

    // For simplicity, we'll suggest new slots for the first task in each conflict's involved tasks list.
    const suggestions = {};
    const taskMap = new Map(tasks.map(t => [t.id, t]));

    for (const conflict of conflicts) {
        customLog('runConflictCheck: Processing conflict', { conflictDate: conflict.date, resourceId: conflict.resourceId });

        if (!conflict.tasksInvolved || conflict.tasksInvolved.length === 0) {
            customLog('runConflictCheck: Skipping conflict with no tasks involved. Skipping.', { conflict });
            continue;
        }

        const taskToSuggest = conflict.tasksInvolved[0];

        if (!taskToSuggest || !taskToSuggest.id) {
            customLog('runConflictCheck: Invalid task found in conflict.tasksInvolved[0]. Skipping.', { taskToSuggest, conflict });
            continue;
        }

        if (suggestions[taskToSuggest.id]) continue;

        const project = projects.find(p => p.id === taskToSuggest.project_id);

        let earliestPotentialStartDate = new Date(parseISO(conflict.date)); // Start searching from the conflicting day

        // Factor in predecessors of taskToSuggest
        if(taskToSuggest.predecessor_links?.length > 0) {
            const predEndDates = taskToSuggest.predecessor_links.map(id => {
                const pred = taskMap.get(id);
                // Use actual_end_date if available, otherwise end_date
                return pred && (pred.actual_end_date || pred.end_date) ? parseISO(pred.actual_end_date || pred.end_date) : null;
            }).filter(Boolean); // THIS LINE IS SYNTACTICALLY CORRECT.
            
            if (predEndDates.length > 0) {
                const latestPredEndDate = new Date(Math.max.apply(null, predEndDates.map(d => d.getTime())));
                let nextWorkingDayAfterPred = addDays(latestPredEndDate, 1);
                while (!isWorkingDay(nextWorkingDayAfterPred, project)) {
                  nextWorkingDayAfterPred = addDays(nextWorkingDayAfterPred, 1);
                }
                if (nextWorkingDayAfterPred > earliestPotentialStartDate) {
                    earliestPotentialStartDate = nextWorkingDayAfterPred;
                }
            }
        }

        // Call findNextAvailableSlotForTask to get suggestions
        const suggestedSlot = await findNextAvailableSlotForTask(taskToSuggest, earliestPotentialStartDate);
        if (suggestedSlot) {
            suggestions[taskToSuggest.id] = [format(suggestedSlot, "yyyy-MM-dd")];
        } else {
            suggestions[taskToSuggest.id] = ["No available slot found"];
        }
    }

    setConflictCheckResults({ conflicts, suggestions });
    setIsConflictResultsModalOpen(true);
    customLog('runConflictCheck finished', { conflicts, suggestions });
  }, [isConflictCheckMode, selectedResourcesForCheck, tasks, projects, getHoursPerDay, isWorkingDay, findNextAvailableSlotForTask]);

  // Keep the ref updated with the latest version of the function
  useEffect(() => {
    runConflictCheckRef.current = runConflictCheck;
  }, [runConflictCheck]);
  
  // Create a debounced version of the conflict check function
  const debouncedRunConflictCheck = useCallback(
    debounce(() => {
      if (runConflictCheckRef.current) {
        runConflictCheckRef.current();
      }
    }, 500),
    [debounce]
  );

  useEffect(() => {
    if (isConflictCheckMode && selectedResourcesForCheck.size > 0) {
      debouncedRunConflictCheck();
    } else if (!isConflictCheckMode) {
        setConflictCheckResults(null); // Clear results when mode is off
        setIsConflictResultsModalOpen(false);
    }
  }, [selectedResourcesForCheck, isConflictCheckMode, debouncedRunConflictCheck]);

  const handleApplySuggestion = async (task, newStartDate) => {
    customLog('handleApplySuggestion start', { task, newStartDate });
    const updatedTask = {
        ...task,
        start_date: newStartDate
    };

    // Ensure duration_days is valid for end date calculation
    const project = projects.find(p => p.id === task.project_id);
    const startDateObj = parseISO(newStartDate);
    const projectSettings = {
        hoursPerDay: getHoursPerDay(project),
        isWorkingDay: (date) => isWorkingDay(date, project),
    };

    if (isValid(startDateObj)) {
        const totalHoursForSuggestion = (updatedTask.duration_days * projectSettings.hoursPerDay) + (updatedTask.duration_hours || 0);
        if (totalHoursForSuggestion > 0) {
            const newEndDate = addWorkingHours(startDateObj, totalHoursForSuggestion, projectSettings);
            const finalEndDate = addHours(newEndDate, -0.01);
            updatedTask.end_date = format(finalEndDate, "yyyy-MM-dd");
        } else {
            // If no duration, set end_date equal to start_date
            updatedTask.end_date = newStartDate;
        }
    } else {
        console.warn("Invalid start date for suggestion application.");
        customLog("Warning: Invalid start date for suggestion application.", { task, newStartDate });
    }

    // Call the debounced update, which will handle saving and state management
    // This will also trigger cascade recalculation
    debouncedTaskUpdate(updatedTask);
    await logGeneric("Conflict Suggestion Applied", { task_id: task.id, task_title: task.title, newStartDate });
    setIsConflictResultsModalOpen(false);
    customLog('handleApplySuggestion end');
  };

  if (hasError) {
    return (
      <div className="min-h-screen bg-red-50 flex items-center justify-center p-6">
        <div className="bg-white rounded-lg shadow-xl p-8 max-w-2xl w-full">
          <div className="flex items-center mb-4">
            <div className="bg-red-100 p-2 rounded-full mr-4">
              <AlertCircle className="h-6 w-6 text-red-600" />
            </div>
            <h1 className="text-2xl font-bold text-red-800">Application Error</h1>
          </div>
          
          <div className="mb-6">
            <p className="text-gray-700 mb-2">
              An error occurred while processing your request:
            </p>
            <div className="bg-red-100 border border-red-300 rounded p-4">
              <p className="font-mono text-sm text-red-800">{errorDetails?.message}</p>
            </div>
          </div>

          <div className="flex gap-4">
            <Button 
              onClick={() => {
                setHasError(false);
                setErrorDetails(null);
                window.location.reload();
              }}
              variant="default"
            >
              Reload Application
            </Button>
            
            <Button 
              onClick={downloadLogsAsCSV}
              variant="outline"
            >
              Download Debug Logs
            </Button>
            
            <Button 
              onClick={() => {
                setHasError(false);
                setErrorDetails(null);
              }}
              variant="ghost"
            >
              Try to Continue
            </Button>
          </div>

          {errorDetails?.stack && (
            <details className="mt-6">
              <summary className="cursor-pointer text-sm text-gray-600 hover:text-gray-800">
                Show Technical Details
              </summary>
              <pre className="mt-2 text-xs bg-gray-100 p-4 rounded overflow-auto max-h-64">
                {errorDetails.stack}
              </pre>
            </details>
          )}
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="flex justify-between items-center">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-32" />
        </div>
        <Card>
          <CardHeader>
            <Skeleton className="h-6 w-32" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Array(5).fill(0).map((_,i) => (
                <div key={i} className="flex items-center gap-4">
                  <Skeleton className="h-12 w-80" />
                  <Skeleton className="h-8 flex-1" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (showTaskForm) {
    return (
      <div className="p-6">
        <TaskForm
          task={selectedTask}
          onSubmit={handleTaskSubmit}
          onCancel={handleTaskCancel}
          onDelete={handleDeleteTask}
          projects={projects}
          resources={resources}
          allTasks={tasks}
          isSubmitting={isSubmitting}
          onAutoSave={handleAutoSave}
          hoursPerDay={hoursPerDay}
        />
      </div>
    );
  }

    return (
    <div className="h-screen flex flex-col bg-slate-50">
      {/* your top‐bar UI (undo/redo, view toggles, etc) */}
      <ViewControls
        viewMode={viewMode}
        onViewModeChange={setViewMode}
        selectedProject={selectedProject}
        onProjectChange={handleProjectChange}
        projects={projects}
        onCreateTask={() => handleCreateTask()}
        onShowFilters={() => {}}
        onUndo={handleUndo}
        onRedo={handleRedo}
        canUndo={canUndo}
        canRedo={canRedo}
        isConflictCheckMode={isConflictCheckMode}
        onToggleConflictCheckMode={handleToggleConflictCheckMode}
        indentMode={indentMode}
        onToggleIndentMode={toggleIndentMode}
        onDownloadLogs={downloadLogsAsCSV}
        onRefreshLinkedTasks={handleRefreshAllLinkedTasks}
      />

      <div className="flex-1 overflow-hidden p-6 min-h-0">
        <GanttChart
          key={forceRenderKey}              // ← force full remount on indent toggle

          tasks={tasks}
          projects={projects}
          resources={resources}
          viewMode={viewMode}
          selectedProject={selectedProject}
          onTaskClick={handleEditTask}
          onCreateTask={handleCreateTask}
          onTaskDelete={handleDeleteTask}
          onTaskDuplicate={handleDuplicateTask}
          onTaskOutdent={handleOutdentTask}
          onTaskIndent={handleIndentTask}
          onTaskUpdate={handleTaskUpdate}
          onTaskReorder={handleTaskReorder}
          onTaskReparent={handleTaskReparent}
          onBulkTaskUpdate={handleBulkUpdate}
          onTaskUnlinkAll={handleUnlinkAllDependencies}
          expandedTasks={expandedTasks}
          onExpandedChange={setExpandedTasks}
          isConflictCheckMode={isConflictCheckMode}
          onSelectResourceForCheck={handleSelectResourceForCheck}
          selectedResourcesForCheck={selectedResourcesForCheck}
          updatingTasks={updatingTasks}
          indentMode={indentMode}            // ← pass the indent flag
          onToggleIndentMode={toggleIndentMode} // ← allow Gantt itself to toggle
          onFindNextAvailableSlot={findNextAvailableSlotForTask}
          onApplySuggestion={handleApplySuggestion}
          hoursPerDay={hoursPerDay}
        />
      </div>

      {/* Progress bar for background updates */}
      {updatingTasks.size > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 p-3 shadow-lg z-[1000]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-slate-700">
              Updating {updatingTasks.size} task{updatingTasks.size !== 1 ? 's' : ''}...
            </span>
            <span className="text-xs text-slate-500">
              Please wait while changes are saved
            </span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div className="bg-indigo-600 h-2 rounded-full animate-pulse" style={{ width: '60%' }}></div>
          </div>
        </div>
      )}

      {/* ResourceConflictModal and ConflictCheckResultsModal here */}
      <ResourceConflictModal
        isOpen={showConflictModal}
        onClose={() => setShowConflictModal(false)}
        conflictData={conflictData}
        onConflictResolved={handleConflictResolved}
      />
      <ConflictCheckResultsModal
        isOpen={isConflictResultsModalOpen}
        onClose={() => setIsConflictResultsModalOpen(false)}
        results={conflictCheckResults}
        tasks={tasks} // Pass tasks for task details
        resources={resources} // Pass resources for resource names
        onApplySuggestion={handleApplySuggestion}
        findNextAvailableSlotForTask={findNextAvailableSlotForTask}
      />
    </div>
  );
}
